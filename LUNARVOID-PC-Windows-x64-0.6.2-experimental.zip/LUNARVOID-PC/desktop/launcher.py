"""Portable Windows app host for the existing LUNARVOID website and UDP relay."""
from pathlib import Path
import ctypes
import hmac
import json
import os
import secrets
import subprocess
import sys
import threading
from http.server import ThreadingHTTPServer
from urllib.parse import urlsplit

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from relay.server import Controller, handler_for
from desktop.game_engine import GameEngineClient

PORT = 45321


class DesktopHost:
    def __init__(self, port=PORT):
        self.game = GameEngineClient(ROOT)
        self.controller = Controller(allow_lan=True, max_sessions=1)
        self.quit_requested = threading.Event()
        self.quit_token = secrets.token_hex(32)
        self.thread = None
        owner = self
        base = handler_for(self.controller)
        html = (ROOT / 'V15/dist/index.html').read_text(encoding='utf-8')
        controls = '''<script>
(() => {
  const button = document.createElement('button');
  button.className = 'secondary'; button.textContent = 'Exit PC app';
  button.title = 'Close this app and stop its local relay';
  button.addEventListener('click', async () => {
    button.disabled = true;
    try {
      const response = await fetch('/api/desktop/quit', {method:'POST',headers:{'X-Desktop-Token':'TOKEN'}});
      if (!response.ok) throw new Error();
      button.textContent = 'Closing…';
    } catch { button.disabled = false; button.textContent = 'Retry exit'; }
  });
  document.querySelector('.top').append(button);
})();
</script>'''.replace('TOKEN', self.quit_token)
        html = html.replace('</head>', '<meta name="lv-game-token" content="' + self.quit_token + '"></head>')
        self.html = html.replace('</body>', controls + '</body>').encode('utf-8')

        class Handler(base):
            def parse_request(self):
                if not super().parse_request():
                    return False
                expected = f'127.0.0.1:{self.server.server_port}'
                if self.headers.get('Host') != expected:
                    self.send_error(403, 'Open the local desktop app address.')
                    return False
                origin = self.headers.get('Origin')
                if origin and origin != f'http://{expected}':
                    self.send_error(403, 'Request origin does not match the desktop app.')
                    return False
                return True

            def end_headers(self):
                self.send_header('Content-Security-Policy', "default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src data: blob:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'")
                self.send_header('Referrer-Policy', 'no-referrer')
                super().end_headers()

            def do_GET(self):
                if urlsplit(self.path).path in ('/', '/index.html'):
                    self.send_response(200)
                    self.send_header('Content-Type', 'text/html; charset=utf-8')
                    self.send_header('Content-Length', str(len(owner.html)))
                    self.send_header('Cache-Control', 'no-store')
                    self.end_headers()
                    self.wfile.write(owner.html)
                else:
                    super().do_GET()

            def do_POST(self):
                if self.path == '/api/game/call':
                    if not hmac.compare_digest(self.headers.get('X-Desktop-Token', ''), owner.quit_token):
                        self.reply(403, {'error': 'Invalid game engine request.'})
                        return
                    try:
                        length = int(self.headers.get('Content-Length', '0'))
                        if not 0 < length <= 4096: raise ValueError()
                        request = json.loads(self.rfile.read(length))
                        if not isinstance(request, dict): raise ValueError()
                        # Desktop mode binds only to loopback in this release.
                        request['lan'] = False
                        if request.get('action') == 'start': owner.controller.close()
                        self.reply(200, owner.game.call(request))
                    except (ValueError, UnicodeError):
                        self.reply(400, {'error': 'Invalid game engine request.'})
                elif self.path == '/api/desktop/quit':
                    if not hmac.compare_digest(self.headers.get('X-Desktop-Token', ''), owner.quit_token):
                        self.reply(403, {'error': 'Invalid desktop request.'})
                        return
                    self.reply(200, {'state': 'closing'})
                    owner.quit_requested.set()
                else:
                    if self.path == '/api/relay': owner.game.call({'action': 'stop'})
                    super().do_POST()

        self.server = ThreadingHTTPServer(('127.0.0.1', port), Handler)
        # The launcher owns all sockets; never leave API/relay threads on exit.
        self.server.daemon_threads = True
        self.url = f'http://127.0.0.1:{self.server.server_port}/'

    def start(self):
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        return self

    def close(self):
        if self.thread is not None:
            self.server.shutdown()
            self.thread.join(timeout=3)
            self.thread = None
        self.server.server_close()
        self.controller.close()
        self.game.close()


def find_browser():
    for vendor, relative in [('Microsoft', 'Edge/Application/msedge.exe'), ('Google', 'Chrome/Application/chrome.exe')]:
        for variable in ('PROGRAMFILES(X86)', 'PROGRAMFILES', 'LOCALAPPDATA'):
            directory = os.environ.get(variable)
            if directory:
                candidate = Path(directory) / vendor / relative
                if candidate.is_file():
                    return candidate
    raise RuntimeError('Microsoft Edge or Google Chrome is required. Install or update one, then open LUNARVOID again.')


def run_app(browser, profile, port=PORT, popen=subprocess.Popen):
    profile.mkdir(parents=True, exist_ok=True)
    host = DesktopHost(port)
    process = None
    try:
        host.start()
        process = popen([str(browser), '--user-data-dir=' + str(profile), '--no-first-run',
                         '--no-default-browser-check', '--disable-background-mode',
                         '--new-window', '--app=' + host.url],
                        stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        while not host.quit_requested.wait(.2):
            if process.poll() is not None:
                break
    finally:
        host.close()
        if process is not None and process.poll() is None:
            process.terminate()
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait(timeout=5)


def main():
    try:
        if sys.argv[1:] == ['--serve']:
            # Development preview only; production launches with no arguments.
            host = DesktopHost().start()
            print(host.url, flush=True)
            try:
                host.quit_requested.wait()
            finally:
                host.close()
            return
        if os.name != 'nt':
            raise RuntimeError('This PC package is for Windows 10/11 (64-bit).')
        browser = find_browser()
        data_root = os.environ.get('LOCALAPPDATA')
        if not data_root:
            raise RuntimeError('Windows local app-data folder is unavailable.')
        run_app(browser, Path(data_root) / 'LunarVoidProxy' / 'BrowserProfile')
    except Exception as error:
        message = ('LUNARVOID could not open.\n\n'
                   + ('Another LUNARVOID app may already be open, or local port 45321 is in use. Close it and try again.'
                      if isinstance(error, OSError) and getattr(error, 'errno', None) in (98, 10048) else str(error)))
        if os.name == 'nt':
            ctypes.windll.user32.MessageBoxW(None, message, 'LUNARVOID PROXY', 0x10)
        else:
            print(message, file=sys.stderr)
        return 1
    return 0


if __name__ == '__main__':
    raise SystemExit(main())

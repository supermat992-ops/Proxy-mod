# LUNARVOID web interface

Edit `src/`, then run `python3 build.py` to regenerate `dist/index.html`. The HTML bundles CSS, JavaScript, Three.js, Steve's skin, and the landscape asset for Android/Quest local-file use.

For real server connections run the Python relay controller from the repository root, or use the Android app. Opening the HTML alone shows the interface and local features; it cannot create UDP sockets in a browser.

Settings has a locally saved nickname preference and fully available Profile, General, and Performance tabs. Applying a nickname on a server requires supported plugin integration and permission; this is not yet connected. Microsoft account linking was removed from this app.

Replay camera points can be added and removed with ×, including after reloading the page. Actual replay recording, playback, export, resource-pack installation, and in-game menus are pending.

See the root README for build, hosting, Android, protocol compatibility, and validation details.

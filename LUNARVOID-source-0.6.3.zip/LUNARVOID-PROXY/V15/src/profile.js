// Local profile: settings are available immediately, with no account linking.
const DEFAULT_USERNAME = 'Player';
const savedUsername = safeGet('lv-username', DEFAULT_USERNAME);
const usernameInput = $('#username');
const profileName = $('#profileName');
const usernameStatus = $('#usernameStatus');
const initialUsername = typeof savedUsername === 'string'
  ? savedUsername.trim().slice(0, 32) || DEFAULT_USERNAME
  : DEFAULT_USERNAME;

if (usernameInput) usernameInput.value = initialUsername;
if (profileName) profileName.textContent = initialUsername;

usernameInput?.addEventListener('input', () => {
  const username = usernameInput.value.trim() || DEFAULT_USERNAME;
  if (profileName) profileName.textContent = username;
  const saved = safeSet('lv-username', username);
  if (usernameStatus) usernameStatus.textContent = saved
    ? 'Saved on this device.'
    : 'Updated for this session. This browser could not save your nickname.';
});

$$('[data-st]').forEach(button => button.addEventListener('click', () => {
  $$('[data-st]').forEach(tab => tab.classList.toggle('active', tab === button));
  $$('.st').forEach(panel => panel.classList.toggle('active', panel.id === 'st-' + button.dataset.st));
}));

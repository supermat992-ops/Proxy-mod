// Companion UI only: do not enable modules before a gameplay engine exists.
const moduleGroups = {
  Combat: ['Reach','KillAura','TPAura','HitBox','Knockback','Knockback Delay','Backtrack','TriggerBot','AutoClicker / AFKClicker','DoubleClick','AutoTotem','AutoPotion','AutoCrystal','AntiCrystal','AutoCart','AutoWeb','AutoJumpReset','AutoCrit','AutoSwitch','MaceSwap'],
  Movement: ['Fly','Speed','Jesus','Spider','NoFall'],
  Visual: ['Xray','FreeLook','FreeCam','Tracers / BlockTracers','HoleESP','ChunkFinder','ArrayList','ArmorHUD / InventoryHUD','TargetHUD','Schematic','Player Outline'],
  Player: ['AutoEat','AutoArmor','FastPlace'],
  World: ['Nuke','Scaffold','FastBreak','AutoMine'],
  Misc: ['FakeRain','AntiVanish']
};
const oreDefaults = {Diamond:'#55e9e2',Emerald:'#36dc7a',Gold:'#f9d449',Iron:'#deb99b',Copper:'#df8e57',Redstone:'#ff4444',Lapis:'#4c71ff',Coal:'#a0a7b3','Ancient Debris':'#a87969','Nether Quartz':'#f4e9dd','Nether Gold':'#f9d449'};
const mineOres=['Coal','Copper','Diamond','Emerald','Gold','Iron','Lapis','Redstone'].flatMap(name=>[name+' Ore','Deepslate '+name+' Ore']).concat(['Nether Gold Ore','Nether Quartz Ore','Ancient Debris']);
const colorValue = (value, fallback) => typeof value === 'string' && /^#[0-9a-f]{6}$/i.test(value) ? value.toLowerCase() : fallback;
const storedClient = safeGet('lv-client-preferences', {});
const clientPreferences = {
  outline:colorValue(storedClient?.outline, '#13baff'),
  ores:Object.fromEntries(Object.entries(oreDefaults).map(([ore,color])=>[ore,colorValue(storedClient?.ores?.[ore],color)])),
  autoMineOres:Array.isArray(storedClient?.autoMineOres)?mineOres.filter(ore=>storedClient.autoMineOres.includes(ore)):[...mineOres],
  autoMineTarget:storedClient?.autoMineTarget==='ores'?'ores':'players'
};
const clientMenu = $('#clientMenu');
let moduleCategory = 'All';
const moduleSettingTargets = {Xray:'xraySettings','Player Outline':'outlineSettings',AutoMine:'autoMineSettings',Schematic:'schematicSettings'};
function saveClientPreferences(){
  $('#clientSaveStatus').textContent = safeSet('lv-client-preferences',clientPreferences)
    ? 'Preferences saved on this device. Gameplay modules remain unavailable.'
    : 'Updated for this session. This device could not save the preferences.';
}
function clientView(view){
  $$('.client-view').forEach(panel=>panel.hidden=panel.id!=='client-view-'+view);
  $$('.client-nav').forEach(button=>{
    const active=button.dataset.clientView===view;
    button.classList.toggle('active',active);
    if(active)button.setAttribute('aria-current','page');else button.removeAttribute('aria-current');
  });
  $('#clientMenuTitle').textContent={modules:'Modules',profile:'Profile',settings:'Settings',hud:'Edit HUD'}[view];
  $('#clientNickname').value=usernameInput.value;
  $('.client-main').scrollTop=0;
}
function openClientMenu(view='modules'){
  clientView(view);
  if(!clientMenu.open)clientMenu.showModal();
}
$('#openClientMenu').addEventListener('click',()=>openClientMenu());
$('#playClientMenu').addEventListener('click',()=>openClientMenu());
$('#settingsClientMenu').addEventListener('click',()=>openClientMenu('settings'));
$('#closeClientMenu').addEventListener('click',()=>clientMenu.close());
$('#clientModules').addEventListener('click',()=>clientView('modules'));
$$('[data-client-view]').forEach(button=>button.addEventListener('click',()=>clientView(button.dataset.clientView)));
$('#openReplayLibrary').addEventListener('click',()=>{clientMenu.close();go('replay');});
$('#clientNickname').addEventListener('input',event=>{
  usernameInput.value=event.target.value;
  usernameInput.dispatchEvent(new Event('input',{bubbles:true}));
  $('#clientSaveStatus').textContent=usernameStatus.textContent;
});
function renderModules(){
  const grid=$('#moduleGrid');grid.replaceChildren();
  const query=$('#moduleSearch').value.trim().toLowerCase();
  for(const [category,names] of Object.entries(moduleGroups)){
    if(moduleCategory!=='All'&&category!==moduleCategory)continue;
    for(const name of names){
      if(query&&!name.toLowerCase().includes(query))continue;
      const card=document.createElement('article');card.className='client-module';
      const icon=document.createElement('span');icon.className='client-module-icon';icon.setAttribute('aria-hidden','true');icon.textContent={Combat:'◇',Movement:'↗',Visual:'◎',Player:'♟',World:'▦',Misc:'⌘'}[category];
      const info=document.createElement('div');info.className='client-module-info';
      const title=document.createElement('h3');title.textContent=name;
      const state=document.createElement('small');state.textContent='Unavailable · /.'+name.split(' / ')[0].toLowerCase().replace(/[^a-z0-9]/g,'');
      info.append(title,state);
      const controls=document.createElement('div');controls.className='client-module-controls';
      if(moduleSettingTargets[name]){
        const settings=document.createElement('button');settings.className='client-gear';settings.textContent='⚙';settings.setAttribute('aria-label',name+' settings');
        settings.addEventListener('click',()=>{clientView('settings');const panel=document.getElementById(moduleSettingTargets[name]);panel.scrollIntoView({block:'nearest'});panel.querySelector('input:not([type=file]),select,button').focus({preventScroll:true});});
        controls.append(settings);
      }
      const toggle=document.createElement('button');toggle.className='client-module-toggle';toggle.disabled=true;toggle.textContent='Off';toggle.setAttribute('aria-label',name+' unavailable: gameplay engine required');
      controls.append(toggle);card.append(icon,info,controls);grid.append(card);
    }
  }
  const count=grid.childElementCount;
  $('#moduleCount').textContent=count+' modules · gameplay engine required';
  if(!count){const empty=document.createElement('p');empty.className='empty';empty.textContent='No modules match your search.';grid.append(empty);}
}
for(const category of ['All',...Object.keys(moduleGroups)]){
  const button=document.createElement('button');button.type='button';button.textContent=category;button.setAttribute('aria-pressed',String(category==='All'));
  button.addEventListener('click',()=>{moduleCategory=category;$('#moduleCategories').querySelectorAll('button').forEach(item=>item.setAttribute('aria-pressed',String(item===button)));renderModules();});
  $('#moduleCategories').append(button);
}
$('#moduleSearch').addEventListener('input',renderModules);
const outlineInput=$('#outlineColor');outlineInput.value=clientPreferences.outline;
function showOutline(){
  $('.client-player-preview').style.setProperty('--outline-color',clientPreferences.outline);
  $('#outlineColorLabel').textContent=clientPreferences.outline.toUpperCase();
}
outlineInput.addEventListener('input',()=>{clientPreferences.outline=colorValue(outlineInput.value,'#13baff');showOutline();saveClientPreferences();});
for(const [ore,color] of Object.entries(clientPreferences.ores)){
  const label=document.createElement('label');label.className='client-ore';
  const input=document.createElement('input');input.type='color';input.value=color;input.setAttribute('aria-label',ore+' ore color');
  const name=document.createElement('span');name.textContent=ore;
  input.addEventListener('input',()=>{clientPreferences.ores[ore]=colorValue(input.value,oreDefaults[ore]);saveClientPreferences();});
  label.append(input,name);$('#oreColors').append(label);
}
$('#autoMineTarget').value=clientPreferences.autoMineTarget;
$('#autoMineTarget').addEventListener('change',event=>{clientPreferences.autoMineTarget=event.target.value==='ores'?'ores':'players';saveClientPreferences();});
showOutline();renderModules();

function renderMineOres(){
  $('#mineOreList').replaceChildren();
  for(const ore of mineOres){
    const label=document.createElement('label');label.className='mine-ore';
    const input=document.createElement('input');input.type='checkbox';input.checked=clientPreferences.autoMineOres.includes(ore);
    input.addEventListener('change',()=>{clientPreferences.autoMineOres=mineOres.filter(name=>name===ore?input.checked:clientPreferences.autoMineOres.includes(name));saveClientPreferences();updateMineCount();});
    const text=document.createElement('span');text.textContent=ore;label.append(input,text);$('#mineOreList').append(label);
  }
  updateMineCount();
}
function updateMineCount(){$('#mineOreCount').textContent=clientPreferences.autoMineOres.length+' of '+mineOres.length+' ores selected';}
$('#mineAll').addEventListener('click',()=>{clientPreferences.autoMineOres=[...mineOres];saveClientPreferences();renderMineOres();});
$('#mineNone').addEventListener('click',()=>{clientPreferences.autoMineOres=[];saveClientPreferences();renderMineOres();});
renderMineOres();

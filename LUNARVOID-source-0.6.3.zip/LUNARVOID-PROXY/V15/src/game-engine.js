// One connection control; Microsoft sign-in and version selection live in Settings.
(() => {
  const host=document.createElement('section');host.className='panel game-account-panel';
  host.innerHTML=`<h2>Microsoft account</h2>
  <p>Sign in with the same account you use in Minecraft, then select a server in Play and press Start Proxy. LUNARVOID charges no linking fee. Your sign-in is encrypted on this device and restored when you reopen the app. Sign out to remove it. Microsoft may occasionally require you to sign in again.</p>
  <div class="game-actions"><button class="secondary" id="gameSignIn">Sign in with Microsoft</button><button class="secondary" id="gameSignOut">Sign out</button></div>
  <p id="gameAuth" role="status"></p><a id="gameLogin" href="https://www.microsoft.com/link" target="_blank" rel="noopener noreferrer" hidden>Open Microsoft sign-in ↗</a>
  <p id="gameAccountStatus" role="status"></p>`;
  document.querySelector('#gameVersionSelect').closest('.panel').before(host);
  let busy=false,timer,status={},firstStatus=true;
  const native=window.LunarVoidNative;
  const token=document.querySelector('meta[name="lv-game-token"]')?.content;
  const $g=id=>document.querySelector('#'+id);
  const versionSelect=$g('gameVersionSelect');
  versionSelect.value=['26.30','26.40','26.50'].includes(safeGet('lv-game-version','26.30'))?safeGet('lv-game-version','26.30'):'26.30';
  $g('playClientMenu').textContent='Preview client settings';
  async function call(request){
    if(native?.gameCall)return JSON.parse(native.gameCall(JSON.stringify(request)));
    if(!token)return {available:false,state:'stopped',error:'Use the Android or Windows app to connect. This website previews your settings.'};
    const response=await fetch('/api/game/call',{method:'POST',headers:{'Content-Type':'application/json','X-Desktop-Token':token},body:JSON.stringify(request)});
    if(!response.ok)throw Error('Could not reach the local game engine.');return response.json();
  }
  function render(){
    const active=['starting','listening','connecting','connected'].includes(status.state);
    gameProxyActive=active||busy;
    if(status.available)versionSelect.value=status.selectedVersion||(status.version||'1.26.30').replace(/^1\./,'');
    versionSelect.disabled=busy||active||['starting','pending'].includes(status.authState);
    $g('gameAuth').textContent=status.sessionWarning||status.authError||(status.authState==='pending'?`Enter code ${status.authCode} at Microsoft sign-in.`:status.signedIn?'Signed in. Open Play to connect.':status.authState==='starting'?'Requesting Microsoft sign-in code…':'Not signed in.');
    $g('gameLogin').hidden=status.authState!=='pending';
    $g('gameAccountStatus').textContent=status.available?`Bedrock ${versionSelect.value} selected.`:status.error||'Checking game engine…';
    $g('gameSignIn').disabled=busy||!status.available||active||['starting','pending'].includes(status.authState);
    $g('gameSignOut').disabled=busy||!status.available;
    const title={stopped:'Proxy stopped',starting:'Proxy starting…',listening:'Proxy ready — join Minecraft',connecting:'Joining destination…',connected:'Connected — emote menu ready'}[status.state]||'Proxy unavailable';
    for(const id of ['globalStatus','proxyTitle'])$g(id).textContent=title;
    for(const id of ['globalDot','proxyDot'])$g(id).classList.toggle('running',active);
    const hasEndpoint=active&&!!status.address&&Number.isInteger(status.port)&&status.port>0;
    $g('proxyEndpoint').hidden=!hasEndpoint;$g('copyEndpoint').hidden=!hasEndpoint;
    $g('proxyEndpoint').textContent=hasEndpoint?`IP: ${status.address} · Port: ${status.port}`:'';
    $g('toggleProxy').disabled=busy||!status.available;
    $g('toggleProxy').textContent=busy?'Please wait…':active?'Stop Proxy':status.signedIn?'Start Proxy':'Sign in in Settings';
    $g('proxyDescription').textContent=status.error||(status.state==='connected'?`Select and play an emote to open the menu, or enter /.menu in chat. Emotes received: ${status.emotes||0}.`:active?'Join the IP and port above in Minecraft. The menu becomes available after entering the server.':status.signedIn?'Select a server, then press Start Proxy.':'Sign in from Settings before connecting.');
    $g('relayAvailability').textContent='Emote menu and /.menu require joining through this connection. Gameplay modules remain unavailable. '+(native?'Same-device address: 127.0.0.1. LAN mode lets other devices on your Wi-Fi join.':'The Windows app listens on this PC.');
    lanModeInput.disabled=busy||active;
    if(active&&native)lanModeInput.checked=!!status.lan;
    $g('relayAccess').hidden=true;
  }
  async function update(action='status',extra={}){
    if(busy)return;busy=true;clearTimeout(timer);render();
    try{
      const request={action,...extra};
      if(action==='start'){
        const server=servers.find(s=>s.selected);
        if(!server)throw Error('Select a saved server first.');
        await stopLegacyRelay();
        request.host=server.ip;request.port=Number(server.port);request.lan=!!native&&lanModeInput.checked;
      }
      status={...status,...await call(request)};
      if(firstStatus&&status.available){
        firstStatus=false;
        if(status.state==='stopped')await stopLegacyRelay();
        const wanted=safeGet('lv-game-version','26.30');
        if(['26.30','26.40','26.50'].includes(wanted)&&wanted!==status.selectedVersion&&status.state==='stopped')
          status={...status,...await call({action:'selectVersion',version:wanted})};
      }
      if(action==='selectVersion'&&!status.error)safeSet('lv-game-version',status.selectedVersion||extra.version);
    }catch(error){status.error=error.message;}finally{busy=false;render();renderServers();if(status.available)timer=setTimeout(()=>update(),2000);}
  }
  gameProxyController={render,endpoint:()=>`${status.address}:${status.port}`,toggle:async()=>{
    if(busy)return;
    if(['starting','listening','connecting','connected'].includes(status.state))return update('stop');
    if(!status.signedIn){go('settings');host.scrollIntoView({block:'center'});return;}
    return update('start');
  }};
  for(const [id,action] of [['gameSignIn','signin'],['gameSignOut','signout']])$g(id).addEventListener('click',()=>update(action));
  $g('gameLogin').addEventListener('click',event=>{if(native?.openGameSignIn){event.preventDefault();native.openGameSignIn();}});
  versionSelect.addEventListener('change',()=>{if(native?.gameCall||token)update('selectVersion',{version:versionSelect.value});else{safeSet('lv-game-version',versionSelect.value);render();}});
  update();
})();

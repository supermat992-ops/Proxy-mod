// Bounded NBT reader for local build previews. No scripts or resource packs execute.
const StructureReader=(()=>{
  const MAX_BLOCKS=100000,MAX_BYTES=16*1024*1024;
  function nbt(bytes,little){
    const view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);
    let offset=0,nodes=0;
    const need=n=>{if(!Number.isSafeInteger(n)||n<0||offset+n>view.byteLength)throw Error('Truncated or invalid NBT data.');};
    function number(method,n){need(n);const value=view[method](offset,little);offset+=n;return value;}
    const byte=()=>number('getUint8',1),int=()=>number('getInt32',4);
    function count(){const n=int();if(n<0||n>1000000)throw Error('NBT collection is too large.');return n;}
    function string(){const n=number('getUint16',2);need(n);const value=new TextDecoder('utf-8',{fatal:true}).decode(bytes.subarray(offset,offset+n));offset+=n;return value;}
    function payload(type,depth){
      if(depth>48||++nodes>1000000)throw Error('NBT nesting or item limit exceeded.');
      switch(type){
        case 1:return number('getInt8',1);
        case 2:return number('getInt16',2);
        case 3:return int();
        case 4:return number('getBigInt64',8);
        case 5:return number('getFloat32',4);
        case 6:return number('getFloat64',8);
        case 7:{const n=count();need(n);const result=bytes.slice(offset,offset+n);offset+=n;return result;}
        case 8:return string();
        case 9:{const subtype=byte(),n=count();if(subtype===0&&n!==0)throw Error('Invalid NBT list.');const list=[];for(let i=0;i<n;i++)list.push(payload(subtype,depth+1));return list;}
        case 10:{const object=Object.create(null);let kind;while((kind=byte())!==0){const name=string();if(Object.hasOwn(object,name))throw Error('Duplicate NBT field.');object[name]=payload(kind,depth+1);}return object;}
        case 11:{const n=count();need(n*4);return Array.from({length:n},int);}
        case 12:{const n=count();need(n*8);return Array.from({length:n},()=>number('getBigInt64',8));}
        default:throw Error('Unsupported NBT tag.');
      }
    }
    if(byte()!==10)throw Error('The file must contain a named NBT compound.');
    string();const result=payload(10,0);
    if(offset!==bytes.length)throw Error('Unexpected data after the structure.');
    return result;
  }
  const air=name=>['minecraft:air','minecraft:cave_air','minecraft:void_air','minecraft:structure_void'].includes(name);
  function dimensions(size){
    if(!Array.isArray(size)||size.length!==3||!size.every(n=>Number.isInteger(n)&&n>0&&n<=512)||size.reduce((a,b)=>a*b,1)>MAX_BLOCKS)throw Error('Build dimensions exceed the 100,000-block preview limit.');
    return size.reduce((a,b)=>a*b,1);
  }
  function names(palette,key){
    if(!Array.isArray(palette)||palette.length<1||palette.length>MAX_BLOCKS)throw Error('Missing or invalid block palette.');
    return palette.map(item=>{const name=item?.[key];if(typeof name!=='string'||name.length>256)throw Error('Invalid block name.');return name;});
  }
  function bedrock(root){
    const size=root.size,volume=dimensions(size),palette=names(root.structure?.palette?.default?.block_palette,'name');
    const indices=root.structure?.block_indices?.[0];
    if(!Array.isArray(indices)||indices.length!==volume)throw Error('Invalid Bedrock block indices.');
    const blocks=[];
    indices.forEach((id,i)=>{
      if(id===-1)return;
      if(!Number.isInteger(id)||id<0||id>=palette.length)throw Error('Block palette index is out of range.');
      if(!air(palette[id]))blocks.push([Math.floor(i/(size[1]*size[2])),Math.floor(i/size[2])%size[1],i%size[2],palette[id]]);
    });
    return {size,blocks,format:'Bedrock structure'};
  }
  function litematic(root){
    const regions=root.Regions;
    if(!regions||typeof regions!=='object'||Array.isArray(regions)||Object.keys(regions).length>128)throw Error('Missing or excessive Litematica regions.');
    const blocks=[],min=[Infinity,Infinity,Infinity],max=[-Infinity,-Infinity,-Infinity];let total=0;
    for(const region of Object.values(regions)){
      const signed=['x','y','z'].map(axis=>region.Size?.[axis]);
      const size=signed.map(Math.abs),volume=dimensions(size);total+=volume;
      if(total>MAX_BLOCKS)throw Error('Combined regions exceed 100,000 blocks.');
      const origin=['x','y','z'].map((axis,i)=>{
        const p=region.Position?.[axis];if(!Number.isInteger(p)||Math.abs(p)>1000000)throw Error('Invalid region position.');
        return p+(signed[i]<0?signed[i]+1:0);
      });
      const palette=names(region.BlockStatePalette,'Name'),states=region.BlockStates;
      const bits=Math.max(2,Math.ceil(Math.log2(palette.length))),mask=(1n<<BigInt(bits))-1n;
      if(!Array.isArray(states)||states.length<Math.ceil(volume*bits/64)||states.some(n=>typeof n!=='bigint'))throw Error('Invalid packed Litematica states.');
      for(let i=0;i<3;i++){min[i]=Math.min(min[i],origin[i]);max[i]=Math.max(max[i],origin[i]+size[i]);}
      for(let i=0;i<volume;i++){
        const bit=i*bits,word=Math.floor(bit/64),shift=bit%64;
        let value=BigInt.asUintN(64,states[word])>>BigInt(shift);
        if(shift+bits>64)value|=BigInt.asUintN(64,states[word+1])<<BigInt(64-shift);
        const id=Number(value&mask);if(id>=palette.length)throw Error('Packed block index is out of range.');
        if(!air(palette[id]))blocks.push([origin[0]+i%size[0],origin[1]+Math.floor(i/(size[0]*size[2])),origin[2]+Math.floor(i/size[0])%size[2],palette[id]]);
      }
    }
    if(total===0)throw Error('No build regions found.');
    return {size:max.map((n,i)=>n-min[i]),blocks:blocks.map(b=>[b[0]-min[0],b[1]-min[1],b[2]-min[2],b[3]]),format:'Litematica'};
  }
  async function read(data,filename){
    let bytes=new Uint8Array(data);
    if(bytes.length>8*1024*1024)throw Error('Choose a build smaller than 8 MB.');
    const lower=filename.toLowerCase();if(!/\.(mcstructure|litematic)$/.test(lower))throw Error('Choose a .mcstructure or .litematic file.');
    if(bytes[0]===31&&bytes[1]===139){
      if(typeof DecompressionStream==='undefined')throw Error('Update your browser or Android WebView to open compressed builds.');
      const reader=new Blob([bytes]).stream().pipeThrough(new DecompressionStream('gzip')).getReader();
      const chunks=[];let length=0;
      try{while(true){const {value,done}=await reader.read();if(done)break;length+=value.length;if(length>MAX_BYTES)throw Error('Decompressed build exceeds 16 MB.');chunks.push(value);}}
      catch(error){await reader.cancel().catch(()=>{});throw error;}
      bytes=new Uint8Array(length);let at=0;for(const chunk of chunks){bytes.set(chunk,at);at+=chunk.length;}
    }
    if(bytes.length>MAX_BYTES)throw Error('Build is too large.');
    const result=lower.endsWith('.mcstructure')?bedrock(nbt(bytes,true)):litematic(nbt(bytes,false));
    if(!result.blocks.length)throw Error('This build contains no visible blocks.');
    return result;
  }
  return {read};
})();
if(typeof module!=='undefined'&&module.exports)module.exports=StructureReader;


(() => {
'use strict';
const $ = s => document.querySelector(s), $$ = s => [...document.querySelectorAll(s)];
const safeGet = (k, fallback) => { try { const v=localStorage.getItem(k); return v===null?fallback:JSON.parse(v); } catch { return fallback; } };
let appPreferences;
let gameProxyActive=false, gameProxyController=null;
const safeSet = (k,v) => { try { localStorage.setItem(k,JSON.stringify(v)); return true; } catch { return false; } };
let servers=safeGet('lv-servers',[]); if(!Array.isArray(servers)) servers=[];
let keyframes=safeGet('lv-keyframes',[]), points=safeGet('lv-points',[{name:'Point 1',detail:'Start point'}]), timer;
if(!Array.isArray(keyframes))keyframes=[];
if(!Array.isArray(points))points=[];
function toast(t){if(appPreferences?.notifications===false)return;const e=$('#toast');if(!e)return;e.textContent=t;e.classList.add('show');clearTimeout(timer);timer=setTimeout(()=>e.classList.remove('show'),2600)}
function go(p){$$('.page').forEach(x=>x.classList.toggle('active',x.id==='page-'+p));$$('.nav').forEach(x=>x.classList.toggle('active',x.dataset.page===p));if(p==='play')renderServers();if(p==='player')drawPlayer();try{window.scrollTo({top:0,behavior:document.body.classList.contains('reduced')?'auto':'smooth'})}catch{}}
$$('.nav').forEach(b=>b.addEventListener('click',()=>go(b.dataset.page)));$$('[data-go]').forEach(b=>b.addEventListener('click',()=>go(b.dataset.go)));$('#homePlay')?.addEventListener('click',()=>go('play'));
function renderServers(){const l=$('#serverList'),total=$('#serverTotal');if(!l)return;if(total)total.textContent=servers.length+' saved';l.replaceChildren();if(!servers.length){const e=document.createElement('div');e.className='empty';e.textContent='No servers yet. Add one to get started.';l.append(e);return}servers.forEach((s,i)=>{const r=document.createElement('div');r.className='server';const icon=document.createElement('span');icon.className='servericon';icon.textContent='◇';const meta=document.createElement('div');meta.className='servermeta';const name=document.createElement('b');name.textContent=s.name||'Server';const addr=document.createElement('small');addr.textContent=(s.ip||'')+':'+(s.port||19132);meta.append(name,addr);const sel=document.createElement('button');sel.className='secondary connect';sel.textContent=s.selected?'Selected':'Select';sel.disabled=proxyBusyOrRunning();sel.addEventListener('click',()=>{if(proxyBusyOrRunning())return;servers=servers.map((x,j)=>({...x,selected:j===i}));persist();toast('Server selected. Press Start Proxy to create a connection.')});const del=document.createElement('button');del.className='secondary delete';del.textContent='×';del.disabled=proxyBusyOrRunning();del.setAttribute('aria-label','Remove '+(s.name||'server'));del.addEventListener('click',()=>{if(proxyBusyOrRunning())return;const was=servers[i]?.selected;servers.splice(i,1);if(was&&servers[0])servers[0].selected=true;persist();toast('Server removed.')});r.append(icon,meta,sel,del);l.append(r)})}
function persist(){safeSet('lv-servers',servers);renderServers()}
$('#serverForm')?.addEventListener('submit',e=>{e.preventDefault();const name=$('#serverName')?.value.trim(),ip=$('#serverIp')?.value.trim(),port=Number($('#serverPort')?.value);if(!name||!ip||ip.length>253||!/^[A-Za-z0-9.\-]+$/.test(ip)||!Number.isInteger(port)||port<1||port>65535){toast('Check the server name, address, and port.');return}if(servers.some(s=>String(s.ip).toLowerCase()===ip.toLowerCase()&&s.port===port)){toast('That server is already saved.');return}servers.push({name,ip,port,selected:servers.length===0});persist();e.target.reset();if($('#serverPort'))$('#serverPort').value=19132;toast('Server saved in this browser.')});
/*@@CONNECTION@@*/
$$('[data-pt]').forEach(b=>b.addEventListener('click',()=>{$$('[data-pt]').forEach(x=>x.classList.toggle('active',x===b));$$('.pt').forEach(x=>x.classList.toggle('active',x.id==='pt-'+b.dataset.pt))}));
// PS-style UI tones: one hover tone only when an element first becomes blue/hovered; no sound on tiny pointer movements.
let audioCtx=null;function tone(kind){if(appPreferences?.sounds===false)return;try{audioCtx ||= new (window.AudioContext||window.webkitAudioContext)();if(audioCtx.state==='suspended')audioCtx.resume();const osc=audioCtx.createOscillator(),gain=audioCtx.createGain();osc.type='sine';osc.frequency.value=kind==='select'?740:520;gain.gain.setValueAtTime(kind==='select'?0.075:0.055,audioCtx.currentTime);gain.gain.exponentialRampToValueAtTime(0.0001,audioCtx.currentTime+(kind==='select'?0.12:0.075));osc.connect(gain);gain.connect(audioCtx.destination);osc.start();osc.stop(audioCtx.currentTime+(kind==='select'?0.12:0.075))}catch{}}
$$('button,.upload,[role="button"]').forEach(el=>{el.addEventListener('pointerenter',()=>{if(el.matches(':hover')&&(el.classList.contains('primary')||el.classList.contains('active')||el.matches(':hover'))){if(!el.dataset.lvHovered){el.dataset.lvHovered='1';tone('hover')}}});el.addEventListener('pointerleave',()=>{delete el.dataset.lvHovered});el.addEventListener('click',()=>tone('select'))});
/*@@PREFERENCES@@*/
/*@@PLAYER3D@@*/
$('#packUpload')?.addEventListener('change',e=>{const f=e.target.files?.[0];if(!f)return;if(!f.name.toLowerCase().endsWith('.mcpack')){toast('Resource packs must be .mcpack files.');e.target.value='';return}const l=$('#packList');if(l){const d=document.createElement('div');d.className='packtile';const icon=document.createElement('span');icon.textContent='▦';const b=document.createElement('b');b.textContent=f.name;const sm=document.createElement('small');sm.textContent='Selected locally; not installed';const rm=document.createElement('button');rm.className='secondary';rm.textContent='Remove';rm.addEventListener('click',()=>{d.remove();toast('Resource pack removed from the list.')});d.append(icon,b,sm,rm);l.append(d)}toast('MCpack selected. Minecraft installation is not connected.')});
/*@@PROFILE@@*/
/*@@CLIENT_MENU@@*/
/*@@STRUCTURE@@*/
function renderKeys(){const l=$('#keyframes');if(!l)return;l.replaceChildren();if(!keyframes.length){const e=document.createElement('div');e.className='empty';e.textContent='Add a keyframe to start a camera path.';l.append(e);return}keyframes.forEach((k,i)=>{const r=document.createElement('div');r.className='keyrow';const a=document.createElement('span');a.textContent='◉';const b=document.createElement('strong');b.textContent=k.name;const sm=document.createElement('small');sm.textContent=k.time;const del=document.createElement('button');del.textContent='×';del.className='secondary';del.addEventListener('click',()=>{keyframes.splice(i,1);safeSet('lv-keyframes',keyframes);renderKeys()});r.append(a,b,sm,del);l.append(r)})}
$('#addKeyframe')?.addEventListener('click',()=>{const t=Number($('#timeline')?.value||0);keyframes.push({name:'Keyframe '+(keyframes.length+1),time:String(Math.floor(t/60)).padStart(2,'0')+':'+String(t%60).padStart(2,'0')});safeSet('lv-keyframes',keyframes);renderKeys();toast('Keyframe saved.')});function renderPoints(){
  const list=$('#points');if(!list)return;list.replaceChildren();
  if(!points.length){const empty=document.createElement('div');empty.className='empty';empty.textContent='Add a point to start a camera path.';list.append(empty);return;}
  points.forEach((point,index)=>{
    const row=document.createElement('div');row.className='pointrow';
    const name=document.createElement('strong');name.textContent=point.name;
    const detail=document.createElement('small');detail.textContent=point.detail;
    const remove=document.createElement('button');remove.type='button';remove.className='secondary';remove.textContent='×';
    remove.setAttribute('aria-label','Remove '+point.name);
    remove.addEventListener('click',()=>{points.splice(index,1);safeSet('lv-points',points);renderPoints();toast('Camera path point removed.');});
    row.append(name,detail,remove);list.append(row);
  });
}
$('#addPoint')?.addEventListener('click',()=>{
  const next=points.reduce((max,point)=>Math.max(max,Number(/^Point (\d+)$/.exec(point.name)?.[1]||0)),0)+1;
  points.push({name:'Point '+next,detail:'Camera path point'});safeSet('lv-points',points);renderPoints();toast('Camera path point saved.');
});
$('#timeline')?.addEventListener('input',e=>{const t=Number(e.target.value);if($('#time'))$('#time').textContent=String(Math.floor(t/60)).padStart(2,'0')+':'+String(t%60).padStart(2,'0')+' / 02:04'});$('#speed')?.addEventListener('input',e=>{if($('#speedLabel'))$('#speedLabel').textContent=Number(e.target.value).toFixed(1)+'×'});$('#previewPlay')?.addEventListener('click',()=>toast('Replay playback needs a replay engine.'));$$('[data-tool]').forEach(b=>b.addEventListener('click',()=>{toast(b.dataset.tool+' selected in editor preview.');$$('[data-tool]').forEach(x=>x.classList.toggle('active',x===b))}));['newReplay','saveReplay','trim','filters','export'].forEach(id=>$('#'+id)?.addEventListener('click',()=>toast('This feature needs the replay engine.')));
renderServers();updateProxy();renderKeys();renderPoints();drawPlayer();
/*@@GAME_ENGINE@@*/
})();


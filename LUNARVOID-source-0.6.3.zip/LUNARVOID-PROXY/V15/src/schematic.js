// Imported builds stay on this device. Rendering is a companion preview only.
let buildData=null,buildAngle=.6,buildLoadGeneration=0;
let buildWriteQueue=Promise.resolve();
function changeBuildStore(mode,value,generation){
  const work=buildWriteQueue.catch(()=>{}).then(()=>generation===buildLoadGeneration?buildStore(mode,value):undefined);
  buildWriteQueue=work;return work;
}
const buildColor=colorValue(safeGet('lv-build-color','#13baff'),'#13baff');
$('#buildOutlineColor').value=buildColor;
function buildStore(mode,value){
  return new Promise((resolve,reject)=>{
    let abandoned=false;
    const request=indexedDB.open('lunarvoid-builds',1);
    request.onupgradeneeded=()=>request.result.createObjectStore('builds');
    request.onerror=()=>reject(request.error);
    request.onblocked=()=>{abandoned=true;reject(Error('Build storage is busy. Close other LUNARVOID tabs.'));};
    request.onsuccess=()=>{
      const db=request.result;if(abandoned){db.close();return;}let result;
      const transaction=db.transaction('builds',mode==='read'?'readonly':'readwrite');
      const store=transaction.objectStore('builds');
      const op=mode==='read'?store.get('current'):mode==='delete'?store.delete('current'):store.put(value,'current');
      op.onsuccess=()=>{result=op.result;};
      transaction.oncomplete=()=>{db.close();resolve(result);};
      transaction.onabort=transaction.onerror=()=>{db.close();reject(transaction.error||Error('Could not save build.'));};
    };
  });
}
function renderBuild(){
  if(!buildData)return;
  $('#buildPreview').hidden=false;drawBuild();
}
function drawBuild(){
  if(!buildData||!clientMenu.open||$('#client-view-settings').hidden)return;
  const canvas=$('#buildCanvas'),width=$('#buildPreview').clientWidth,height=$('#buildPreview').clientHeight;
  if(!width||!height)return;
  const context=canvas.getContext('2d');
  if(!context){$('#buildStatus').textContent='This browser cannot draw a build preview.';return;}
  const ratio=Math.min(devicePixelRatio||1,1.5);canvas.width=Math.round(width*ratio);canvas.height=Math.round(height*ratio);
  context.scale(ratio,ratio);context.clearRect(0,0,width,height);
  const center=buildData.size.map(n=>n/2),cos=Math.cos(buildAngle),sin=Math.sin(buildAngle);
  const project=(x,y,z)=>{x-=center[0];y-=center[1];z-=center[2];return [x*cos-z*sin,(x*sin+z*cos)*.5-y*.85];};
  const corners=Array.from({length:8},(_,i)=>project((i&1)?buildData.size[0]:0,(i&2)?buildData.size[1]:0,(i&4)?buildData.size[2]:0));
  const min=[Math.min(...corners.map(v=>v[0])),Math.min(...corners.map(v=>v[1]))],max=[Math.max(...corners.map(v=>v[0])),Math.max(...corners.map(v=>v[1]))];
  const scale=Math.min((width-32)/Math.max(1,max[0]-min[0]),(height-32)/Math.max(1,max[1]-min[1]));
  const edges=[[0,1],[0,2],[0,4],[1,3],[1,5],[2,3],[2,6],[3,7],[4,5],[4,6],[5,7],[6,7]];
  context.strokeStyle=$('#buildOutlineColor').value;context.lineWidth=1;context.globalAlpha=.7;context.beginPath();
  for(const block of buildData.blocks.slice(0,12000))for(const [a,b] of edges){
    for(const [j,corner] of [a,b].entries()){
      const point=project(block[0]+(corner&1),block[1]+((corner>>1)&1),block[2]+((corner>>2)&1));
      const x=width/2+(point[0]-(min[0]+max[0])/2)*scale,y=height/2+(point[1]-(min[1]+max[1])/2)*scale;
      if(j===0)context.moveTo(x,y);else context.lineTo(x,y);
    }
  }
  context.stroke();
}
function describeBuild(name){$('#buildStatus').textContent=name+' · '+buildData.format+' · '+buildData.size.join(' × ')+' · '+buildData.blocks.length.toLocaleString()+' blocks'+(buildData.blocks.length>12000?' (first 12,000 previewed)':'');}
$('#buildUpload').addEventListener('change',async event=>{
  const file=event.target.files?.[0];if(!file)return;event.target.value='';
  const generation=++buildLoadGeneration;$('#buildStatus').textContent='Reading build…';
  try{
    if(file.size>8*1024*1024)throw Error('Choose a build smaller than 8 MB.');
    const bytes=await file.arrayBuffer(),parsed=await StructureReader.read(bytes,file.name);
    if(generation!==buildLoadGeneration)return;
    buildData=parsed;describeBuild(file.name);renderBuild();
    try{await changeBuildStore('write',{name:file.name,bytes},generation);if(generation===buildLoadGeneration)$('#buildStatus').textContent+=' · Saved on this device.';}
    catch{if(generation===buildLoadGeneration)$('#buildStatus').textContent+=' · Preview only: device storage unavailable.';}
  }catch(error){if(generation===buildLoadGeneration)$('#buildStatus').textContent='Build not loaded: '+error.message;}
});
$('#clearBuild').addEventListener('click',async()=>{
  const generation=++buildLoadGeneration;buildData=null;$('#buildPreview').hidden=true;
  $('#buildStatus').textContent='No build uploaded.';
  try{await changeBuildStore('delete',undefined,generation);}catch{$('#buildStatus').textContent='Preview cleared. Device storage could not be cleared; the saved build may return after reload.';}
});
$('#buildOutlineColor').addEventListener('input',()=>{if(!safeSet('lv-build-color',$('#buildOutlineColor').value))$('#buildStatus').textContent+=' Color could not be saved.';drawBuild();});
$('#rotateBuildLeft').addEventListener('click',()=>{buildAngle-=.3;drawBuild();});
$('#rotateBuildRight').addEventListener('click',()=>{buildAngle+=.3;drawBuild();});
new ResizeObserver(drawBuild).observe($('#buildPreview'));
(async()=>{
  const generation=buildLoadGeneration;
  try{
    const saved=await buildStore('read');if(!saved||generation!==buildLoadGeneration)return;
    const parsed=await StructureReader.read(saved.bytes,saved.name);if(generation!==buildLoadGeneration)return;
    buildData=parsed;describeBuild(saved.name);renderBuild();
  }catch{if(generation===buildLoadGeneration)$('#buildStatus').textContent='No saved build could be restored. You can upload a build for this session.';}
})();

// The Android bridge and hosted controller implement the same relay status shape.
const nativeRelay = window.LunarVoidNative;
let relaySession = null, relayStatus = {state:'stopped'}, relayBusy = false, relayTimer, relayGeneration = 0;
let relayAvailable = !!nativeRelay;
const lanModeInput = $('#lanMode');
if(nativeRelay){
  $('#androidConnection').hidden=false;
  lanModeInput.checked=safeGet('lv-lan-mode',false)===true;
  lanModeInput.addEventListener('change',()=>safeSet('lv-lan-mode',lanModeInput.checked));
}
try { relaySession = JSON.parse(sessionStorage.getItem('lv-relay-session') || 'null'); } catch {}
if (!relaySession || typeof relaySession.id !== 'string' || typeof relaySession.token !== 'string') relaySession = null;
function rememberRelay(session) {
  relaySession = session;
  try { if(session) sessionStorage.setItem('lv-relay-session', JSON.stringify(session)); else sessionStorage.removeItem('lv-relay-session'); } catch {}
}
function proxyBusyOrRunning() { return gameProxyActive || relayBusy || ['running','starting','waiting','unknown'].includes(relayStatus.state); }
function updateProxy() {
  if(gameProxyController){gameProxyController.render();return;}
  const state=relayStatus.state;
  lanModeInput.disabled=proxyBusyOrRunning();
  if(nativeRelay&&state==='running')lanModeInput.checked=relayStatus.lan===true;
  const active=state==='running';
  const titles={running:'Proxy started',starting:'Proxy starting…',waiting:'Waiting for Wi-Fi',unknown:'Proxy status unavailable',stopped:'Proxy stopped'};
  const title=titles[state]||'Proxy stopped';
  $('#globalStatus').textContent=title;$('#proxyTitle').textContent=title;
  $('#globalDot').classList.toggle('running',active);$('#proxyDot').classList.toggle('running',active);
  const endpoint=$('#proxyEndpoint');
  const hasEndpoint=!!relayStatus.address&&Number.isInteger(relayStatus.port)&&relayStatus.port>0&&state!=='stopped';
  endpoint.hidden=!hasEndpoint;
  endpoint.textContent=hasEndpoint?`IP: ${relayStatus.address} · Port: ${relayStatus.port}`:'';
  $('#copyEndpoint').hidden=!hasEndpoint;
  if(nativeRelay){
    $('#relayAvailability').textContent=relayStatus.lan&&hasEndpoint
      ? 'Same Wi-Fi: use the address above or look for LUNARVOID under Minecraft LAN Games. On this Android device, use 127.0.0.1 with the same port. The foreground relay continues when you close the app window. Force-stop, shutdown or battery restrictions can stop it.'
      : 'Android relay: use 127.0.0.1 on this device. Enable same-Wi-Fi mode before starting to connect another device.';
  }
  const button=$('#toggleProxy');button.disabled=gameProxyActive||relayBusy||state==='starting';
  button.textContent=relayBusy?'Please wait…':proxyBusyOrRunning()?'Stop Proxy':'Start Proxy';
  $('#proxyDescription').textContent=relayStatus.error||(active
    ? relayStatus.packetsReceived>0?'Server packets received. Join using the address and port shown.':'Relay listening. Waiting for game traffic; server login is not confirmed yet.'
    :state==='waiting'?'Waiting for Wi-Fi. Keep Wi-Fi enabled; the relay will reconnect.':state==='starting'?'Opening a UDP relay to your selected server…':state==='unknown'?'Could not check the relay. Retry stopping it or restore your connection.':'Select a server, then press Start Proxy.');
}
async function relayRequest(path, options={}) {
  const controller=new AbortController();const timeout=setTimeout(()=>controller.abort(),15000);
  try {
    const response=await fetch(path,{...options,signal:controller.signal,cache:'no-store'});
    let data;try{data=await response.json();}catch{throw new Error('This website needs the LUNARVOID relay host. Open the hosted app or use the Android app.');}
    if(!response.ok){const error=new Error(data.error||'The relay request failed.');error.status=response.status;throw error;}
    return data;
  } finally {clearTimeout(timeout);}
}
function scheduleRelayCheck(){clearTimeout(relayTimer);if(nativeRelay||relaySession)relayTimer=setTimeout(checkRelay,2000);}
async function checkRelay(){
  if(relayBusy){scheduleRelayCheck();return;}
  const generation=relayGeneration;
  try{
    const status=nativeRelay?JSON.parse(nativeRelay.status()):relaySession
      ?await relayRequest('/api/relay/'+encodeURIComponent(relaySession.id),{headers:{Authorization:'Bearer '+relaySession.token}}):{state:'stopped'};
    if(generation!==relayGeneration)return;
    relayStatus=status;
    if(status.state==='stopped')rememberRelay(null);
  }catch(error){
    if(generation!==relayGeneration)return;
    if(error.status===404){rememberRelay(null);relayStatus={state:'stopped',error:error.message};}
    else if(relaySession||nativeRelay)relayStatus={...relayStatus,state:'unknown',error:'Unable to check the relay. Check your connection.'};
  }
  updateProxy();renderServers();scheduleRelayCheck();
}
$('#toggleProxy').addEventListener('click',async()=>{
  if(gameProxyController){await gameProxyController.toggle();return;}
  if(relayBusy)return;
  const stopping=proxyBusyOrRunning();
  const selected=servers.find(server=>server.selected);
  if(!stopping&&!selected){toast('Add and select a server first.');return;}
  if(!stopping&&!relayAvailable){toast('Open the hosted LUNARVOID website or Android app to start a relay.');return;}
  ++relayGeneration;relayBusy=true;clearTimeout(relayTimer);updateProxy();renderServers();
  try{
    if(stopping){
      if(nativeRelay){const result=JSON.parse(nativeRelay.stopProxy());if(result.error)throw new Error(result.error);}
      else if(relaySession){try{await relayRequest('/api/relay/'+encodeURIComponent(relaySession.id),{method:'DELETE',headers:{Authorization:'Bearer '+relaySession.token}});}catch(error){if(error.status!==404)throw error;}}
      rememberRelay(null);relayStatus={state:'stopped'};toast('Proxy stopped.');
    }else{
      if(nativeRelay){relayStatus=JSON.parse(nativeRelay.startProxy(selected.ip,selected.port,lanModeInput.checked));if(relayStatus.error)throw new Error(relayStatus.error);}
      else{
        const result=await relayRequest('/api/relay',{method:'POST',headers:{'Content-Type':'application/json','X-Relay-Key':$('#relayKey').value},body:JSON.stringify({host:selected.ip,port:selected.port})});
        rememberRelay({id:result.id,token:result.token});relayStatus=result;
      }
      toast('Starting your relay. Connection details appear when it is ready.');
    }
  }catch(error){
    relayStatus={...relayStatus,state:stopping?'unknown':'stopped',error:error.name==='AbortError'?'The relay host timed out. Check your connection before retrying.':error.message};
    toast(relayStatus.error);
  }finally{relayBusy=false;updateProxy();renderServers();scheduleRelayCheck();}
});
$('#copyEndpoint').addEventListener('click',async()=>{
  const value=gameProxyController?gameProxyController.endpoint():`${relayStatus.address}:${relayStatus.port}`;
  try{
    if(navigator.clipboard?.writeText)await navigator.clipboard.writeText(value);
    else {const field=document.createElement('textarea');field.value=value;document.body.append(field);field.select();const copied=document.execCommand('copy');field.remove();if(!copied)throw new Error();}
    toast('Address and port copied.');
  }catch{toast('Copy the IP and port shown beside Proxy started.');}
});
async function initRelay(){
  if(nativeRelay){await checkRelay();return;}
  try{
    const config=await relayRequest('/api/config');relayAvailable=true;$('#relayAccess').hidden=!config.requiresKey;
    $('#relayAvailability').textContent=config.localOnly?'Local relay host: the shown address works on the computer running this website. Public access needs a configured relay host.':'Use the relay address in Minecraft. Closing this page does not immediately stop the relay; use Stop Proxy when finished.';
    if(relaySession)await checkRelay();
  }catch{$('#relayAvailability').textContent='Website preview: open this interface on a configured LUNARVOID relay host, or use the Android app, to create a game connection.';}
}
// Run after the enclosing app has initialized its controls.
setTimeout(initRelay,0);

async function stopLegacyRelay(){
  if(relayBusy)throw Error('Please wait for the previous connection to finish.');
  ++relayGeneration;clearTimeout(relayTimer);
  if(nativeRelay){const result=JSON.parse(nativeRelay.stopProxy());if(result.error)throw Error(result.error);}
  else if(relaySession){try{await relayRequest('/api/relay/'+encodeURIComponent(relaySession.id),{method:'DELETE',headers:{Authorization:'Bearer '+relaySession.token}});}catch(error){if(error.status!==404)throw error;}}
  rememberRelay(null);relayStatus={state:'stopped'};
}

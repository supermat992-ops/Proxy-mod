const preferenceDefaults={notifications:true,sounds:true,compact:false,reduced:false,effects:false,rotate:true,quality:'standard',showSkin3d:true};
const storedPreferences=safeGet('lv-app-preferences',{});
appPreferences=Object.fromEntries(Object.entries(preferenceDefaults).map(([key,value])=>[key,typeof storedPreferences?.[key]===typeof value?storedPreferences[key]:value]));
if(!['standard','low'].includes(appPreferences.quality))appPreferences.quality='standard';
function applyPreferences(){
  document.body.classList.toggle('compact',appPreferences.compact);
  document.body.classList.toggle('reduced',appPreferences.reduced);
  document.body.classList.toggle('low-effects',appPreferences.effects);
  $('#lighting').checked=!appPreferences.effects;
}
function saveAppPreferences(){
  $('#preferencesStatus').textContent=safeSet('lv-app-preferences',appPreferences)?'Preferences saved on this device.':'Updated for this session. This device could not save your preferences.';
  applyPreferences();
}
for(const [id,key] of Object.entries({notifications:'notifications',interfaceSounds:'sounds',compact:'compact',motion:'reduced',effects:'effects',rotatePreview:'rotate',showSkin3d:'showSkin3d'})){
  const input=$('#'+id);input.checked=appPreferences[key];
  input.addEventListener('change',()=>{appPreferences[key]=input.checked;saveAppPreferences();if(key==='showSkin3d')updateSkinView();});
}
$('#previewQuality').value=appPreferences.quality;
$('#previewQuality').addEventListener('change',e=>{appPreferences.quality=e.target.value;saveAppPreferences();if(GL)GL.setPixelRatio(appPreferences.quality==='low'?1:Math.min(devicePixelRatio||1,2));});
$('#lighting').addEventListener('change',e=>{appPreferences.effects=!e.target.checked;$('#effects').checked=appPreferences.effects;saveAppPreferences();});
applyPreferences();

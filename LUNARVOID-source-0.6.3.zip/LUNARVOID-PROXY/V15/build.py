#!/usr/bin/env python3
"""Builds dist/index.html: ONE self-contained file (needed because Quest/Android content:// URLs can't load sibling files)."""
import base64, pathlib, json, re
r = pathlib.Path(__file__).parent; s = r/'src'
version = json.loads((r.parent/'version.json').read_text())
assert re.fullmatch(r'[0-9]+\.[0-9]+\.[0-9]+(?:-[a-z0-9.-]+)?', version['name'])
assert isinstance(version['code'], int) and version['code'] > 0
rd = lambda p: (s/p).read_text(encoding='utf-8')
steve = base64.b64encode((s/'assets/steve.png').read_bytes()).decode()
js = rd('app.js').replace('/*@@CONNECTION@@*/', rd('connection.js')).replace('/*@@GAME_ENGINE@@*/', rd('game-engine.js')).replace('/*@@PROFILE@@*/', rd('profile.js')).replace('/*@@CLIENT_MENU@@*/', rd('client-menu.js')).replace('/*@@PREFERENCES@@*/', rd('preferences.js')).replace('/*@@STRUCTURE@@*/', rd('structure.js') + '\n' + rd('schematic.js')).replace('/*@@PLAYER3D@@*/', rd('player3d.js').replace('@@STEVE@@', steve))
svg = base64.b64encode((s/'assets/minecraft-landscape.svg').read_bytes()).decode()
html = rd('index.html').replace('@@CLIENT_MENU@@', rd('client-menu.html')).replace('@@CSS@@', (rd('styles.css') + '\n' + rd('client-menu.css')).replace("url('assets/minecraft-landscape.svg')", "url('data:image/svg+xml;base64,"+svg+"')")).replace('@@THREE@@', (s/'vendor/three.min.js').read_text(encoding='utf-8')).replace('@@JS@@', js)
html = html.replace('@@VERSION@@', version['name'])
(r/'dist').mkdir(exist_ok=True); (r/'dist/index.html').write_text(html, encoding='utf-8')
print('built dist/index.html', round(len(html)/1024), 'KB')

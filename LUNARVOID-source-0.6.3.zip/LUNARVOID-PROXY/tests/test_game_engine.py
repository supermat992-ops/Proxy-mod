"""Native process/API boundary checks; no real Microsoft credentials."""
import http.client
import json
from pathlib import Path
import unittest
from unittest.mock import patch
from desktop.game_engine import GameEngineClient
from desktop.launcher import DesktopHost

ROOT = Path(__file__).resolve().parents[1]
class GameEngineTests(unittest.TestCase):
    def test_switch_versions_restarts_engine_and_rejects_invalid(self):
        engine = GameEngineClient(ROOT)
        self.addCleanup(engine.close)
        initial = engine.call({'action': 'status'})
        self.assertEqual(initial['selectedVersion'], '26.30')
        self.assertEqual(initial['protocol'], 1001)
        previous = engine.process
        changed = engine.call({'action': 'selectVersion', 'version': '26.50'})
        self.assertEqual(changed['selectedVersion'], '26.50')
        self.assertEqual(changed['version'], '1.26.50')
        self.assertEqual(changed['protocol'], 2193)
        self.assertFalse(changed['signedIn'])
        self.assertIsNotNone(previous.poll())
        self.assertIn('error', engine.call({'action': 'selectVersion', 'version': '26.99'}))
        self.assertEqual(engine.version, '26.50')
        middle=engine.call({'action':'selectVersion','version':'26.40'})
        self.assertEqual(middle['protocol'],2168)
        self.assertEqual(middle['version'],'1.26.40')
        restored = engine.call({'action': 'selectVersion', 'version': '26.30'})
        self.assertEqual(restored['protocol'], 1001)
        self.assertFalse(restored['signedIn'])

    def test_switch_rejected_while_game_active(self):
        engine = GameEngineClient(ROOT)
        # Synthetic process response exercises the guard without an account/network.
        class Replies:
            def get(self, timeout):
                return '{"state":"connected","available":true}'
        class Process:
            class Input:
                def write(self, value): pass
                def flush(self): pass
            stdin = Input()
            def poll(self): return None
        engine.process, engine.replies = Process(), Replies()
        with patch.object(engine, 'close') as close:
            denied = engine.call({'action': 'selectVersion', 'version': '26.50'})
            self.assertIn('Stop game mode', denied['error'])
            self.assertEqual(engine.version, '26.30')
            close.assert_not_called()

    def test_process_status_auth_requirement_and_close(self):
        engine = GameEngineClient(ROOT)
        self.addCleanup(engine.close)
        status = engine.call({'action': 'status'})
        self.assertTrue(status['available'])
        self.assertEqual(status['version'], '1.26.30')
        self.assertFalse(status['signedIn'])
        denied = engine.call({'action': 'start', 'host': '127.0.0.1', 'port': 19133})
        self.assertEqual(denied['state'], 'stopped')
        self.assertIn('Sign in', denied['error'])
        process = engine.process
        engine.close()
        self.assertIsNotNone(process.poll())

    def test_desktop_game_api_requires_owner_token(self):
        host = DesktopHost(port=0).start()
        self.addCleanup(host.close)
        def post(body, token=None):
            connection = http.client.HTTPConnection('127.0.0.1', host.server.server_port)
            headers = {'Content-Type': 'application/json'}
            if token: headers['X-Desktop-Token'] = token
            connection.request('POST', '/api/game/call', body, headers)
            response = connection.getresponse()
            result = response.status, json.loads(response.read())
            connection.close()
            return result
        self.assertEqual(post('{"action":"status"}')[0], 403)
        self.assertEqual(post('not JSON', host.quit_token)[0], 400)
        code, data = post('{"action":"status"}', host.quit_token)
        self.assertEqual(code, 200)
        self.assertTrue(data['available'])
        self.assertNotIn('access_token', json.dumps(data))
        self.assertIn(b'lv-game-token', host.html)

import hashlib
import http.client
import tempfile
import threading
import unittest
import zipfile
from http.server import ThreadingHTTPServer
from pathlib import Path
from unittest.mock import patch
from relay import server


class SiteTests(unittest.TestCase):
    def test_packaged_navigation_downloads_and_path_restrictions(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            with zipfile.ZipFile(server.ROOT / 'release/LUNARVOID-PROXY-website.zip') as archive:
                archive.extractall(root)
            with patch.object(server, 'ROOT', root):
                host = ThreadingHTTPServer(('127.0.0.1', 0), server.handler_for(server.Controller()))
                thread = threading.Thread(target=host.serve_forever, daemon=True)
                thread.start()
                try:
                    for route, file, mime in [('/', 'index.html', 'text/html'),
                          ('/dashboard/', 'dashboard/index.html', 'text/html'),
                          ('/downloads/LUNARVOID-PC-Windows-x64.zip', 'downloads/LUNARVOID-PC-Windows-x64.zip', 'application/zip'),
                          ('/downloads/LUNARVOID-Android.apk', 'downloads/LUNARVOID-Android.apk', 'application/vnd.android.package-archive')]:
                        with self.subTest(route=route):
                            client = http.client.HTTPConnection(*host.server_address)
                            client.request('GET', route)
                            response = client.getresponse()
                            body = response.read()
                            self.assertEqual(response.status, 200)
                            self.assertTrue(response.getheader('Content-Type').startswith(mime))
                            self.assertEqual(hashlib.sha256(body).digest(), hashlib.sha256((root / file).read_bytes()).digest())
                            if route.startswith('/downloads/'):
                                self.assertIn('attachment;', response.getheader('Content-Disposition'))
                            client.close()
                    html = (root / 'index.html').read_text()
                    self.assertIn('https://discord.gg/BTwZVvmdE', html)
                    self.assertIn('href="dashboard/"', html)
                    self.assertNotIn('@@', html)
                    self.assertNotIn('App Store', html)
                    for route in ['/downloads/../README.txt', '/downloads/%2e%2e/README.txt', '/relay/server.py']:
                        client = http.client.HTTPConnection(*host.server_address)
                        client.request('GET', route)
                        response = client.getresponse()
                        self.assertEqual(response.status, 404)
                        response.read()
                        client.close()
                finally:
                    host.shutdown()
                    host.server_close()
                    thread.join()

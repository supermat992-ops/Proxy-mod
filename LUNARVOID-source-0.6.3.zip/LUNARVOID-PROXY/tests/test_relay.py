import http.client
import json
import socket
import threading
import time
import unittest
from http.server import ThreadingHTTPServer
from relay.server import Controller, Relay, handler_for, resolve_target


class UdpFixture:
    """Synthetic UDP endpoint. Binary payloads exercise forwarding, not Minecraft login."""
    def __init__(self):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.bind(('127.0.0.1', 0))
        self.sock.settimeout(.1)
        self.address = self.sock.getsockname()
        self.running = True
        self.thread = threading.Thread(target=self.run, daemon=True)
        self.thread.start()

    def run(self):
        while self.running:
            try:
                data, address = self.sock.recvfrom(65535)
                self.sock.sendto(b'REPLY:' + data, address)
            except socket.timeout:
                continue
            except OSError:
                break

    def close(self):
        self.running = False
        self.sock.close()
        self.thread.join(1)


class RelayTests(unittest.TestCase):
    def setUp(self):
        self.upstream = UdpFixture()
        self.addCleanup(self.upstream.close)

    def client(self):
        client = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        client.settimeout(1)
        self.addCleanup(client.close)
        return client

    def test_two_clients_receive_only_their_binary_packets(self):
        relay = Relay(self.upstream.address)
        self.addCleanup(relay.close)
        first, second = self.client(), self.client()
        first.sendto(bytes(range(256)) * 4, ('127.0.0.1', relay.port))
        second.sendto(b'other-client\x00\xff', ('127.0.0.1', relay.port))
        self.assertEqual(first.recv(65535), b'REPLY:' + bytes(range(256)) * 4)
        self.assertEqual(second.recv(65535), b'REPLY:other-client\x00\xff')
        deadline = time.monotonic() + 1
        while relay.received < 2 and time.monotonic() < deadline:
            time.sleep(.005)
        status = relay.snapshot('127.0.0.1')
        self.assertEqual(status['state'], 'running')
        self.assertEqual(status['packetsSent'], 2)
        self.assertEqual(status['packetsReceived'], 2)

    def test_stop_releases_listener_and_no_longer_forwards(self):
        relay = Relay(self.upstream.address)
        relay.close()
        self.assertFalse(relay.thread.is_alive())
        self.assertEqual(relay.snapshot('127.0.0.1')['state'], 'stopped')
        client = self.client()
        client.bind(('127.0.0.1', relay.port))

    def test_idle_expiry_reclaims_resources(self):
        relay = Relay(self.upstream.address, idle=.05)
        self.addCleanup(relay.close)
        relay.thread.join(1)
        self.assertFalse(relay.thread.is_alive())
        self.assertTrue(relay.stop_event.is_set())

    def test_rejects_a_relay_loop(self):
        controller = Controller(allow_lan=True, ports=(19140, 19155))
        self.addCleanup(controller.close)
        with self.assertRaises(ValueError):
            controller.start('127.0.0.1', 19140)
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as probe:
            probe.bind(('127.0.0.1', 0))
            port = probe.getsockname()[1]
        with self.assertRaises(ValueError):
            Relay(('127.0.0.1', port), ports=(port, port))

    def test_destination_validation(self):
        for host, port in [('127.0.0.1', 19132), ('localhost', 19132),
                           ('239.0.0.1', 19132), ('0.0.0.0', 19132),
                           ('https://example.org', 19132), ('example.org', True),
                           ('example.org', 0), ('example.org', 65536)]:
            with self.subTest(host=host, port=port), self.assertRaises(ValueError):
                resolve_target(host, port)
        self.assertEqual(resolve_target('127.0.0.1', 19132, True), ('127.0.0.1', 19132))

    def test_session_capacity_and_owner_token(self):
        controller = Controller(allow_lan=True, max_sessions=1)
        self.addCleanup(controller.close)
        session = controller.start(*self.upstream.address)
        with self.assertRaises(ValueError):
            controller.start(*self.upstream.address)
        self.assertIsNone(controller.get(session['id'], 'wrong-owner'))
        self.assertFalse(controller.stop(session['id'], 'wrong-owner'))
        self.assertTrue(controller.stop(session['id'], session['token']))
        self.assertEqual(controller.start(*self.upstream.address)['state'], 'running')


class HttpTests(unittest.TestCase):
    def setUp(self):
        self.upstream = UdpFixture()
        self.controller = Controller(allow_lan=True, access_key='synthetic-test-access-key')
        self.http = ThreadingHTTPServer(('127.0.0.1', 0), handler_for(self.controller))
        self.thread = threading.Thread(target=self.http.serve_forever, daemon=True)
        self.thread.start()
        self.addCleanup(self.cleanup)

    def cleanup(self):
        self.http.shutdown()
        self.http.server_close()
        self.thread.join(1)
        self.controller.close()
        self.upstream.close()

    def request(self, method, path, data=None, headers=None):
        connection = http.client.HTTPConnection(*self.http.server_address, timeout=2)
        self.addCleanup(connection.close)
        merged = {'Content-Type': 'application/json', **(headers or {})}
        connection.request(method, path, json.dumps(data) if data is not None else None, merged)
        response = connection.getresponse()
        return response.status, json.loads(response.read())

    def test_create_forward_restore_stop_and_auth(self):
        payload = {'host': self.upstream.address[0], 'port': self.upstream.address[1]}
        self.assertEqual(self.request('POST', '/api/relay', payload)[0], 401)
        key = {'X-Relay-Key': 'synthetic-test-access-key'}
        self.assertEqual(self.request('POST', '/api/relay', payload, {**key, 'Origin': 'https://other.test'})[0], 403)
        code, session = self.request('POST', '/api/relay', payload, key)
        self.assertEqual(code, 201)
        path = '/api/relay/' + session['id']
        owner = {'Authorization': 'Bearer ' + session['token']}
        self.assertEqual(self.request('GET', path)[0], 404)
        self.assertEqual(self.request('DELETE', path)[0], 404)
        client = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.addCleanup(client.close)
        client.settimeout(1)
        client.sendto(b'\x01RakNet-fixture', (session['address'], session['port']))
        self.assertEqual(client.recv(65535), b'REPLY:\x01RakNet-fixture')
        deadline = time.monotonic() + 1
        while self.controller.get(session['id'], session['token']).received < 1 and time.monotonic() < deadline:
            time.sleep(.005)
        self.assertEqual(self.request('GET', path, headers=owner)[1]['packetsReceived'], 1)
        self.assertEqual(self.request('DELETE', path, headers=owner)[0], 200)
        self.assertEqual(self.request('GET', path, headers=owner)[0], 404)

    def test_invalid_payload_and_missing_api_route(self):
        headers = {'X-Relay-Key': 'synthetic-test-access-key'}
        self.assertEqual(self.request('POST', '/api/relay', [], headers)[0], 400)
        self.assertEqual(self.request('POST', '/api/relay', {'host': '127.0.0.1', 'port': '19132'}, headers)[0], 400)
        self.assertEqual(self.request('GET', '/api/missing')[0], 404)
        self.assertTrue(self.request('GET', '/api/config')[1]['requiresKey'])


if __name__ == '__main__':
    unittest.main()

import http.client
import json
from pathlib import Path
import socket
import tempfile
import unittest
from urllib.parse import urlsplit
from unittest.mock import patch

from desktop.launcher import DesktopHost, find_browser, run_app


class DesktopTests(unittest.TestCase):
    def setUp(self):
        self.host = DesktopHost(0).start()
        self.port = self.host.server.server_port

    def tearDown(self):
        self.host.close()

    def request(self, method, path, body=None, headers=None):
        connection = http.client.HTTPConnection('127.0.0.1', self.port, timeout=3)
        connection.request(method, path, body, headers or {})
        response = connection.getresponse()
        result = response.status, response.read(), dict(response.getheaders())
        connection.close()
        return result

    def test_website_and_request_boundary(self):
        status, body, headers = self.request('GET', '/')
        self.assertEqual(status, 200)
        self.assertIn(b'Exit PC app', body)
        self.assertIn("frame-ancestors 'none'", headers['Content-Security-Policy'])
        self.assertEqual(self.request('GET', '/', headers={'Host':'attacker.example'})[0], 403)
        self.assertEqual(self.request('POST', '/api/relay', '{}', {'Content-Type':'application/json','Origin':'https://other.example'})[0],403)
        self.assertEqual(self.request('GET','/api/config')[0],200)

    def test_real_relay_and_shutdown_cleanup(self):
        with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as target, socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as client:
            target.bind(('127.0.0.1',0));target.settimeout(2);client.settimeout(2)
            status, data, _ = self.request('POST','/api/relay',json.dumps({'host':'127.0.0.1','port':target.getsockname()[1]}),{'Content-Type':'application/json'})
            self.assertEqual(status,201)
            session=json.loads(data)
            client.sendto(b'bedrock-fixture\x00\xff',('127.0.0.1',session['port']))
            payload,source=target.recvfrom(100);target.sendto(payload,source)
            self.assertEqual(client.recvfrom(100)[0],b'bedrock-fixture\x00\xff')
            self.assertEqual(self.request('GET','/api/relay/'+session['id'],headers={'Authorization':'Bearer wrong'})[0],404)
            self.host.close()
            with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as rebound:
                rebound.bind(('127.0.0.1',session['port']))

    def test_quit_requires_desktop_token(self):
        self.assertEqual(self.request('POST','/api/desktop/quit')[0],403)
        self.assertFalse(self.host.quit_requested.is_set())
        self.assertEqual(self.request('POST','/api/desktop/quit',headers={'X-Desktop-Token':self.host.quit_token})[0],200)
        self.assertTrue(self.host.quit_requested.is_set())

    def test_browser_exit_cleans_host(self):
        urls=[]
        class Browser:
            def poll(self):return 0
        def launch(arguments,**kwargs):
            urls.append(next(arg.removeprefix('--app=') for arg in arguments if arg.startswith('--app=')))
            self.assertTrue(any(arg.startswith('--user-data-dir=') for arg in arguments))
            return Browser()
        with tempfile.TemporaryDirectory() as tmp:
            run_app(Path('/synthetic/browser'),Path(tmp)/'Profile',port=0,popen=launch)
        port=urlsplit(urls[0]).port
        with socket.socket() as connection:
            self.assertNotEqual(connection.connect_ex(('127.0.0.1',port)),0)

    def test_browser_start_failure_closes_port(self):
        port=None
        def fail(arguments,**kwargs):
            nonlocal port
            port=urlsplit(next(arg.removeprefix('--app=') for arg in arguments if arg.startswith('--app='))).port
            raise OSError('synthetic browser launch failed')
        with tempfile.TemporaryDirectory() as tmp:
            with self.assertRaises(OSError):run_app(Path('/synthetic/browser'),Path(tmp),port=0,popen=fail)
        with socket.socket() as connection:
            self.assertNotEqual(connection.connect_ex(('127.0.0.1',port)),0)

    def test_exit_app_stops_browser_process(self):
        class Browser:
            stopped=False
            def poll(self):return 0 if self.stopped else None
            def terminate(self):self.stopped=True
            def wait(self,timeout):return 0
        browser=Browser()
        def launch(arguments,**kwargs):
            import re
            url=next(arg.removeprefix('--app=') for arg in arguments if arg.startswith('--app='))
            conn=http.client.HTTPConnection('127.0.0.1',urlsplit(url).port,timeout=3)
            conn.request('GET','/');html=conn.getresponse().read().decode()
            token=re.search(r"'X-Desktop-Token':'([a-f0-9]+)'",html).group(1)
            conn.request('POST','/api/desktop/quit',headers={'X-Desktop-Token':token})
            self.assertEqual(conn.getresponse().status,200);conn.close()
            return browser
        with tempfile.TemporaryDirectory() as tmp:
            run_app(Path('/synthetic/browser'),Path(tmp),port=0,popen=launch)
        self.assertTrue(browser.stopped)

    def test_browser_discovery_prefers_edge(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)
            edge=root/'Microsoft/Edge/Application/msedge.exe';edge.parent.mkdir(parents=True);edge.touch()
            chrome=root/'Google/Chrome/Application/chrome.exe';chrome.parent.mkdir(parents=True);chrome.touch()
            with patch.dict('os.environ',{'PROGRAMFILES':str(root)},clear=True):
                self.assertEqual(find_browser(),edge)
                edge.unlink();self.assertEqual(find_browser(),chrome)
                chrome.unlink()
                with self.assertRaises(RuntimeError):find_browser()


if __name__=='__main__':unittest.main()

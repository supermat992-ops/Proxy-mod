const {test}=require('node:test');
const assert=require('node:assert/strict');
const {gzipSync}=require('node:zlib');
const {mkdirSync,writeFileSync}=require('node:fs');
const {read}=require('../V15/src/structure.js');
// Fixture encoder deliberately independent of the production reader.
function encode(root,little){
 const number=(method,n,value)=>{const b=Buffer.alloc(n);b[method](value);return b;};
 const int=n=>number(little?'writeInt32LE':'writeInt32BE',4,n);
 const str=s=>{const text=Buffer.from(s);return Buffer.concat([number(little?'writeUInt16LE':'writeUInt16BE',2,text.length),text]);};
 function payload([kind,value]){
  if(kind===3)return int(value);
  if(kind===8)return str(value);
  if(kind===9)return Buffer.concat([Buffer.from([value.kind]),int(value.items.length),...value.items.map(v=>payload([value.kind,v]))]);
  if(kind===10)return Buffer.concat([...Object.entries(value).map(([key,tag])=>Buffer.concat([Buffer.from([tag[0]]),str(key),payload(tag)])),Buffer.from([0])]);
  if(kind===11)return Buffer.concat([int(value.length),...value.map(int)]);
  if(kind===12)return Buffer.concat([int(value.length),...value.map(n=>number(little?'writeBigInt64LE':'writeBigInt64BE',8,BigInt.asIntN(64,n)))]);
  throw Error('Fixture tag');
 }
 return Buffer.concat([Buffer.from([10]),str(''),payload([10,root])]);
}
const list=(kind,items)=>[9,{kind,items}];
function mc(indices=[1,0,-1,1,1,0],size=[2,1,3]){
 return encode({size:list(3,size),structure:[10,{block_indices:list(9,[{kind:3,items:indices},{kind:3,items:Array(indices.length).fill(-1)}]),palette:[10,{default:[10,{block_palette:list(10,[{name:[8,'minecraft:air']},{name:[8,'minecraft:diamond_block']}])}]}]}]},true);
}
function lit(){
 const ids=Array.from({length:23},(_,i)=>i%5),words=[0n,0n];
 ids.forEach((id,i)=>{const bit=i*3;words[Math.floor(bit/64)]|=BigInt(id)<<BigInt(bit%64);if(bit%64+3>64)words[Math.floor(bit/64)+1]|=BigInt(id)>>BigInt(64-bit%64);});
 const xyz=(x,y,z)=>[10,{x:[3,x],y:[3,y],z:[3,z]}];
 return gzipSync(encode({Version:[3,6],Regions:[10,{test:[10,{Size:xyz(-23,1,1),Position:xyz(22,0,0),BlockStatePalette:list(10,['air','stone','diamond_block','glass','dirt'].map(n=>({Name:[8,'minecraft:'+n]}))),BlockStates:[12,words]}]}]},false));
}
test('Bedrock little-endian palette/coordinates/air/missing blocks',async()=>{
 const build=await read(mc(),'tiny.mcstructure');assert.deepEqual(build.size,[2,1,3]);assert.deepEqual(build.blocks,[[0,0,0,'minecraft:diamond_block'],[1,0,0,'minecraft:diamond_block'],[1,0,1,'minecraft:diamond_block']]);
});
test('Gzipped Litematica negative region and packed state crossing64-bit boundary',async()=>{
 const build=await read(lit(),'tiny.litematic');assert.deepEqual(build.size,[23,1,1]);assert.equal(build.blocks.length,18);assert.deepEqual(build.blocks.find(b=>b[0]===21),[21,0,0,'minecraft:stone']);assert.deepEqual(build.blocks.find(b=>b[0]===22),[22,0,0,'minecraft:diamond_block']);
});
test('Reject truncated, trailing and unsupported files',async()=>{
 const fixture=mc();for(const end of [0,1,5,20,fixture.length-1])await assert.rejects(read(fixture.subarray(0,end),'bad.mcstructure'));
 await assert.rejects(read(Buffer.concat([fixture,Buffer.from([1])]),'bad.mcstructure'),/Unexpected data/);
 await assert.rejects(read(fixture,'bad.zip'),/Choose a/);
});
test('Reject bad palette index, wrong count, empty build and excessive volume',async()=>{
 await assert.rejects(read(mc([2,0,0,0,0,0]),'bad.mcstructure'),/out of range/);
 await assert.rejects(read(mc([1]),'bad.mcstructure'),/indices/);
 await assert.rejects(read(mc([0,0,0,0,0,0]),'bad.mcstructure'),/no visible/);
 await assert.rejects(read(mc([1],[512,512,512]),'bad.mcstructure'),/limit/);
});
test('Reject excessive nesting, input size and decompression expansion',async()=>{
 let nested={a:[3,1]};for(let i=0;i<55;i++)nested={a:[10,nested]};
 await assert.rejects(read(encode(nested,true),'bad.mcstructure'),/nesting/);
 await assert.rejects(read(new Uint8Array(8*1024*1024+1),'bad.mcstructure'),/8 MB/);
 await assert.rejects(read(gzipSync(Buffer.alloc(16*1024*1024+1)),'bad.litematic'),/16 MB/);
});
if(process.env.LV_FIXTURE_DIR){mkdirSync(process.env.LV_FIXTURE_DIR,{recursive:true});writeFileSync(process.env.LV_FIXTURE_DIR+'/tiny.mcstructure',mc());writeFileSync(process.env.LV_FIXTURE_DIR+'/tiny.litematic',lit());writeFileSync(process.env.LV_FIXTURE_DIR+'/bad.mcstructure',Buffer.from('invalid'));}

package com.lunarvoid.proxy;

import java.net.*;
import java.util.Arrays;

/** Runs on the JDK against the exact relay class packaged in the APK. */
public final class UdpRelayTest {
    public static void main(String[] args) throws Exception {
        try (DatagramSocket upstream = new DatagramSocket(0, InetAddress.getByName("127.0.0.1"));
             DatagramSocket first = new DatagramSocket(); DatagramSocket second = new DatagramSocket()) {
            upstream.setSoTimeout(1500); first.setSoTimeout(1500); second.setSoTimeout(1500);
            UdpRelay relay = new UdpRelay("127.0.0.1", upstream.getLocalPort());
            try {
                for (DatagramSocket client : new DatagramSocket[]{first, second}) {
                    byte[] data = new byte[1400]; Arrays.fill(data, (byte)(client.getLocalPort() % 255));
                    client.send(new DatagramPacket(data, data.length, InetAddress.getByName("127.0.0.1"), relay.port));
                    DatagramPacket arrived = new DatagramPacket(new byte[65535], 65535); upstream.receive(arrived);
                    if (!Arrays.equals(data, Arrays.copyOf(arrived.getData(), arrived.getLength()))) throw new AssertionError("Outbound data changed");
                    upstream.send(arrived);
                    DatagramPacket response = new DatagramPacket(new byte[65535], 65535); client.receive(response);
                    if (!Arrays.equals(data, Arrays.copyOf(response.getData(), response.getLength()))) throw new AssertionError("Wrong client response");
                }
                long deadline = System.nanoTime() + 1_000_000_000L;
                while (relay.received.get() < 2 && System.nanoTime() < deadline) Thread.sleep(5);
                if (!relay.isRunning() || relay.sent.get() != 2 || relay.received.get() != 2) throw new AssertionError("Status counters");
            } finally { relay.close(); }
            if (relay.isRunning()) throw new AssertionError("Stop failed");
            try (DatagramSocket rebound = new DatagramSocket(relay.port, InetAddress.getByName("127.0.0.1"))) {}
            UdpRelay idle = new UdpRelay("127.0.0.1", upstream.getLocalPort(), 50, 50);
            Thread.sleep(400);
            if (idle.isRunning()) throw new AssertionError("Idle expiry failed");
            idle.close();
            try { new UdpRelay("https://example.com", 19132); throw new AssertionError("Invalid hostname accepted"); }
            catch (java.io.IOException expected) {}
            System.out.println("PASS: native relay binary forwarding, separate clients, counters, stop/rebind, idle expiry, invalid host");
        }
    }
}

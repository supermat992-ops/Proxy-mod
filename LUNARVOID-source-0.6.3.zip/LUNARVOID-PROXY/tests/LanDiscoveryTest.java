package com.lunarvoid.proxy;

import java.net.*;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;

/** Fixtures cover unencrypted discovery only, never a real Minecraft login. */
public final class LanDiscoveryTest {
    private static final byte[] MAGIC = {0,(byte)255,(byte)255,0,(byte)254,(byte)254,(byte)254,(byte)254,
        (byte)253,(byte)253,(byte)253,(byte)253,0x12,0x34,0x56,0x78};
    private static byte[] pong(String text) {
        byte[] bytes=text.getBytes(StandardCharsets.UTF_8);
        return ByteBuffer.allocate(35+bytes.length).put((byte)0x1c).putLong(1234).putLong(9876)
            .put(MAGIC).putShort((short)bytes.length).put(bytes).array();
    }
    private static byte[] rewrite(byte[] bytes,int port) {
        ByteBuffer result=LanDiscovery.rewritePong(ByteBuffer.wrap(bytes),port);
        byte[] data=new byte[result.remaining()];result.get(data);return data;
    }
    public static void main(String[] args) throws Exception {
        String text="MCPE;Fixture world;999;26.30;1;10;9876;Lobby;Survival;1;20489;20490;";
        byte[] source=pong(text);
        byte[] result=rewrite(source,19132);
        if(!Arrays.equals(Arrays.copyOf(source,33),Arrays.copyOf(result,33)))throw new AssertionError("Ping correlation or server GUID changed");
        String[] fields=new String(result,35,result.length-35,StandardCharsets.UTF_8).split(";",-1);
        if(!fields[1].equals("LUNARVOID · Fixture world")||!fields[10].equals("19132")||!fields[11].equals("0"))throw new AssertionError("Discovery endpoint");
        if(!fields[2].equals("999")||!fields[3].equals("26.30"))throw new AssertionError("Changed destination version advertisement");
        if(Short.toUnsignedInt(ByteBuffer.wrap(result).getShort(33))!=result.length-35)throw new AssertionError("UTF8 byte length");
        for(byte[] malformed:new byte[][] {new byte[0],new byte[]{(byte)0xfe,1,2},Arrays.copyOf(source,source.length-1),pong("OTHER;a;b;c;d;e")})
            if(!Arrays.equals(malformed,rewrite(malformed,19132)))throw new AssertionError("Changed non-discovery/malformed packet");
        byte[] invalidMagic=source.clone();invalidMagic[17]=1;
        if(!Arrays.equals(invalidMagic,rewrite(invalidMagic,19132)))throw new AssertionError("Invalid magic accepted");
        byte[] invalidUtf8=source.clone();invalidUtf8[40]=(byte)255;
        if(!Arrays.equals(invalidUtf8,rewrite(invalidUtf8,19132)))throw new AssertionError("Invalid UTF8 accepted");
        byte[] tooLarge=pong("MCPE;"+"x".repeat(65460)+";999;26.30;1;10;");
        if(!Arrays.equals(tooLarge,rewrite(tooLarge,19132)))throw new AssertionError("Oversized discovery rewritten");

        try(DatagramSocket upstream=new DatagramSocket(0,InetAddress.getByName("127.0.0.1"));DatagramSocket client=new DatagramSocket()) {
            upstream.setSoTimeout(1500);client.setSoTimeout(1500);
            UdpRelay relay=new UdpRelay("127.0.0.1",upstream.getLocalPort(),true);
            try {
                if(relay.port!=19132)throw new AssertionError("Discovery port not 19132");
                byte[] ping=ByteBuffer.allocate(33).put((byte)1).putLong(1234).put(MAGIC).putLong(4567).array();
                client.send(new DatagramPacket(ping,ping.length,InetAddress.getByName("127.0.0.1"),relay.port));
                DatagramPacket packet=new DatagramPacket(new byte[65535],65535);upstream.receive(packet);
                if(!Arrays.equals(ping,Arrays.copyOf(packet.getData(),packet.getLength())))throw new AssertionError("Ping changed");
                upstream.send(new DatagramPacket(source,source.length,packet.getSocketAddress()));
                DatagramPacket reply=new DatagramPacket(new byte[65535],65535);client.receive(reply);
                if(reply.getPort()!=19132||!Arrays.equals(result,Arrays.copyOf(reply.getData(),reply.getLength())))throw new AssertionError("Pong relay");
                byte[] opaque={(byte)0xfe,0,7,(byte)255,22};
                client.send(new DatagramPacket(opaque,opaque.length,InetAddress.getByName("127.0.0.1"),relay.port));
                packet.setLength(65535);upstream.receive(packet);upstream.send(packet);
                reply.setLength(65535);client.receive(reply);
                if(!Arrays.equals(opaque,Arrays.copyOf(reply.getData(),reply.getLength())))throw new AssertionError("Opaque game traffic modified");
                // A real local broadcast exercises the 0.0.0.0 bind, not just loopback.
                client.setBroadcast(true);
                client.send(new DatagramPacket(ping,ping.length,InetAddress.getByName("255.255.255.255"),relay.port));
                packet.setLength(65535);upstream.receive(packet);
                upstream.send(new DatagramPacket(source,source.length,packet.getSocketAddress()));
                reply.setLength(65535);client.receive(reply);
                if(!Arrays.equals(result,Arrays.copyOf(reply.getData(),reply.getLength())))throw new AssertionError("Broadcast discovery roundtrip");
                try {new UdpRelay("127.0.0.1",upstream.getLocalPort(),true);throw new AssertionError("Busy LAN port accepted");}
                catch(java.io.IOException expected){if(!expected.getMessage().contains("already in use"))throw expected;}
            } finally {relay.close();}
            try(DatagramSocket rebound=new DatagramSocket(19132)){}
            try {new UdpRelay("127.0.0.1",19132,true);throw new AssertionError("Self loop accepted");}
            catch(java.io.IOException expected){}
        }
        // LAN ignores the app idle timeout while still expiring stale peers.
        try(DatagramSocket upstream=new DatagramSocket(0,InetAddress.getByName("127.0.0.1"));
            DatagramSocket client=new DatagramSocket();
            UdpRelay persistent=new UdpRelay("127.0.0.1",upstream.getLocalPort(),true,0,50,50)) {
            Thread.sleep(450);
            if(!persistent.isRunning())throw new AssertionError("LAN stopped on idle timeout");
            upstream.setSoTimeout(1500);client.setSoTimeout(1500);
            byte[] payload={3,5,7};client.send(new DatagramPacket(payload,payload.length,InetAddress.getByName("127.0.0.1"),persistent.port));
            DatagramPacket arrived=new DatagramPacket(new byte[100],100);upstream.receive(arrived);upstream.send(arrived);
            DatagramPacket reply=new DatagramPacket(new byte[100],100);client.receive(reply);
            if(!Arrays.equals(payload,Arrays.copyOf(reply.getData(),reply.getLength())))throw new AssertionError("Idle LAN did not accept new client");
            persistent.close();
            if(persistent.isRunning())throw new AssertionError("Persistent LAN could not stop");
            try(DatagramSocket rebound=new DatagramSocket(persistent.port)){}
        }
        System.out.println("PASS: LAN port, correlated discovery, endpoint/UTF8 rewrite, malformed and opaque packet preservation, busy port, stop/rebind, persistent LAN idle retention, self-loop guard");
    }
}

#!/usr/bin/env python3
"""Build a portable Windows website app with the official embedded Python runtime."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import struct
import subprocess
import urllib.request
import zipfile
import zlib

ROOT = Path(__file__).resolve().parents[1]
PYTHON_VERSION = '3.14.4'
PYTHON_SHA256 = 'cda80a9b1e75c0f1b4f9872ca1b417f0d19bce32facc811aea9180e70fad5fb9'


def write_icon(path):
    def chunk(kind, data):
        return struct.pack('>I', len(data)) + kind + data + struct.pack('>I', zlib.crc32(kind + data))
    rows = bytearray()
    for y in range(64):
        rows.append(0)
        for x in range(64):
            color = (5, 20, 40, 255)
            if 8 <= y <= 55 and 8 + (y-8)*.5 <= x <= 56 - (y-8)*.5:
                color = (25, 160, 255, 255) if x > 29 else (100, 222, 255, 255)
            rows.extend(color)
    png = b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', 64,64,8,6,0,0,0)) + chunk(b'IDAT', zlib.compress(rows)) + chunk(b'IEND', b'')
    path.write_bytes(struct.pack('<HHH',0,1,1) + struct.pack('<BBBBHHII',64,64,0,0,1,32,len(png),22) + png)


def main():
    version = json.loads((ROOT/'version.json').read_text())
    subprocess.run(['python3', 'V15/build.py'], cwd=ROOT, check=True)
    cache = Path(os.environ.get('RUNTIME_ROOT', str(Path.home()/'runtime'))) / 'desktop'
    cache.mkdir(parents=True, exist_ok=True)
    archive = cache / f'python-{PYTHON_VERSION}-embed-amd64.zip'
    if not archive.exists():
        temporary = archive.with_suffix('.download')
        urllib.request.urlretrieve(f'https://www.python.org/ftp/python/{PYTHON_VERSION}/{archive.name}', temporary)
        if hashlib.sha256(temporary.read_bytes()).hexdigest() != PYTHON_SHA256:
            temporary.unlink()
            raise SystemExit('Python runtime checksum mismatch.')
        temporary.replace(archive)
    if hashlib.sha256(archive.read_bytes()).hexdigest() != PYTHON_SHA256:
        raise SystemExit('Cached Python runtime checksum mismatch.')
    build = ROOT / 'desktop/build'
    shutil.rmtree(build, ignore_errors=True)
    bundle = build / 'LUNARVOID-PC'
    (bundle/'runtime').mkdir(parents=True)
    with zipfile.ZipFile(archive) as source:
        assert source.testzip() is None
        source.extractall(bundle/'runtime')
    for name in ['desktop/launcher.py','desktop/game_engine.py','engine/build/lunarvoid-engine30.exe','engine/build/lunarvoid-engine40.exe','engine/build/lunarvoid-engine50.exe','engine/THIRD_PARTY_NOTICES.txt','relay/server.py','V15/dist/index.html','version.json']:
        target = bundle/name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(ROOT/name, target)
    (bundle/'README.txt').write_text((ROOT/'desktop/README.txt').read_text().replace('@@VERSION@@', version['name']), encoding='utf-8')
    write_icon(build/'lunarvoid.ico')
    numeric = ','.join(version['name'].split('-')[0].split('.') + [str(version['code'])])
    resource = '''1 ICON "lunarvoid.ico"
1 VERSIONINFO
 FILEVERSION NUMERIC
 PRODUCTVERSION NUMERIC
 FILEOS 0x40004
 FILETYPE 1
BEGIN
 BLOCK "StringFileInfo"
 BEGIN
  BLOCK "040904b0"
  BEGIN
   VALUE "FileDescription", "LUNARVOID PROXY desktop launcher"
   VALUE "ProductName", "LUNARVOID PROXY"
   VALUE "FileVersion", "VERSION"
   VALUE "ProductVersion", "VERSION"
   VALUE "OriginalFilename", "LUNARVOID.exe"
  END
 END
 BLOCK "VarFileInfo"
 BEGIN
  VALUE "Translation", 0x409, 1200
 END
END
'''.replace('NUMERIC', numeric).replace('"VERSION"', '"'+version['name']+'"')
    (build/'launcher.rc').write_text(resource)
    subprocess.run(['x86_64-w64-mingw32-windres','launcher.rc','launcher.res.o'],cwd=build,check=True)
    subprocess.run(['x86_64-w64-mingw32-gcc','-O2','-s','-municode','-mwindows','-static','-static-libgcc',
                    str(ROOT/'desktop/launcher.c'),str(build/'launcher.res.o'),'-o',str(bundle/'LUNARVOID.exe')],check=True)
    files=sorted(p for p in bundle.rglob('*') if p.is_file())
    manifest={p.relative_to(bundle).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
    (bundle/'SHA256.json').write_text(json.dumps(manifest,indent=2)+'\n')
    output=ROOT/'release'/f'LUNARVOID-PC-Windows-x64-{version["name"]}.zip'
    output.parent.mkdir(exist_ok=True)
    with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED) as target:
        for path in sorted(p for p in bundle.rglob('*') if p.is_file()):
            target.write(path,path.relative_to(build).as_posix())
    with zipfile.ZipFile(output) as result:
        assert result.testzip() is None
        for name,digest in manifest.items():
            assert hashlib.sha256(result.read('LUNARVOID-PC/'+name)).hexdigest()==digest
        assert result.read('LUNARVOID-PC/V15/dist/index.html')==(ROOT/'V15/dist/index.html').read_bytes()
    if output.stat().st_size>25*1024*1024:
        raise SystemExit('Desktop bundle exceeds the download size limit.')
    print(f'Built and verified {output.name} ({output.stat().st_size/1024/1024:.1f} MiB).')


if __name__=='__main__':
    main()

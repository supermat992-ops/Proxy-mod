#!/usr/bin/env python3
"""Prepare local, unpublished source and debug-APK packages after building Android."""
from pathlib import Path
import hashlib
import json
import shutil
import zipfile
from build_site import build

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'release'
APK = ROOT / 'android/app/build/outputs/apk/debug/app-debug.apk'


def main():
    if not APK.is_file():
        raise SystemExit('Build the debug APK before packaging.')
    web = ROOT / 'V15/dist/index.html'
    with zipfile.ZipFile(APK) as archive:
        if archive.testzip() is not None or archive.read('assets/index.html') != web.read_bytes():
            raise SystemExit('The APK does not contain the current web build. Rebuild it first.')
    version = json.loads((ROOT / 'version.json').read_text())
    OUT.mkdir(exist_ok=True)
    shutil.copyfile(APK, OUT / 'LUNARVOID-PROXY-debug.apk')
    site = build()
    files = [ROOT / 'README.md', ROOT / '.gitignore', ROOT / 'version.json']
    for directory in ['V15', 'relay', 'android', 'tests', 'docs', 'deploy', 'tools', 'desktop', 'site', 'engine']:
        for path in (ROOT / directory).rglob('*'):
            if not path.is_file():
                continue
            if any(part in {'build', '.gradle', '__pycache__', 'jniLibs'} for part in path.relative_to(ROOT).parts):
                continue
            if path.name == 'local.properties' or path.suffix in {'.pyc', '.jks', '.keystore'}:
                continue
            files.append(path)
    with zipfile.ZipFile(OUT / 'LUNARVOID-PROXY-source.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(files):
            archive.write(path, 'LUNARVOID-PROXY/' + path.relative_to(ROOT).as_posix())
    with zipfile.ZipFile(ROOT / 'LUNARVOID_PROXY_V15 (1).zip', 'w', zipfile.ZIP_DEFLATED) as archive:
        for path in sorted((ROOT / 'V15').rglob('*')):
            if path.is_file():
                archive.write(path, path.relative_to(ROOT).as_posix())
    website_bytes = {path.relative_to(site).as_posix(): path.read_bytes()
                     for path in site.rglob('*') if path.is_file()}
    website_bytes.update({
        'V15/dist/index.html': web.read_bytes(),
        'relay/server.py': (ROOT / 'relay/server.py').read_bytes(),
        'site/build/index.html': (site / 'index.html').read_bytes(),
        'README.txt': (ROOT / 'docs/WEBSITE_README.txt').read_bytes().replace(b'@@VERSION@@', version['name'].encode()),
    })
    # Local server downloads use site/build; avoid duplicating binaries in the ZIP
    # by resolving the public downloads directory in the extracted layout.
    with zipfile.ZipFile(OUT / 'LUNARVOID-PROXY-website.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
        for name, data in website_bytes.items():
            archive.writestr(name, data)
    with zipfile.ZipFile(OUT / 'LUNARVOID-PROXY-website.zip') as archive:
        assert archive.testzip() is None
        assert set(archive.namelist()) == set(website_bytes)
        for name, data in website_bytes.items():
            assert archive.read(name) == data
    manifest = {path.name: hashlib.sha256(path.read_bytes()).hexdigest()
                for path in sorted(OUT.iterdir()) if path.suffix in {'.zip', '.apk'}}
    (OUT / 'SHA256.json').write_text(json.dumps(manifest, indent=2) + '\n')
    with zipfile.ZipFile(OUT / 'LUNARVOID-PROXY-source.zip') as archive:
        assert archive.testzip() is None
        assert len(archive.namelist()) == len(files)
        for path in files:
            assert archive.read('LUNARVOID-PROXY/' + path.relative_to(ROOT).as_posix()) == path.read_bytes()
    print('Prepared and verified unpublished source ZIP and debug APK in release/.')


if __name__ == '__main__':
    main()

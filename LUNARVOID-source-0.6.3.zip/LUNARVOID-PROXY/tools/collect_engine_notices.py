#!/usr/bin/env python3
"""Collect license notices for the exact Go module graph shipped in the engine."""
from pathlib import Path
import json
import subprocess
ROOT=Path(__file__).resolve().parents[1]
def main():
    result=''.join(subprocess.check_output(['mise','exec','go@1.26.1','--','go','list',*extra,'-deps','-json','./cmd/desktop'],cwd=ROOT/'engine',text=True) for extra in [[],['-modfile=go-26.40.mod'],['-modfile=go-26.50.mod']])
    decoder=json.JSONDecoder();modules_by_path={}
    while result.strip():
        item,end=decoder.raw_decode(result.lstrip());result=result.lstrip()[end:]
        if item.get('Module'): modules_by_path[(item['Module']['Path'],item['Module'].get('Version',''))]=item['Module']
    modules=list(modules_by_path.values())
    notices=['LUNARVOID Bedrock engine third-party notices\n']
    goroot=Path(subprocess.check_output(['mise','exec','go@1.26.1','--','go','env','GOROOT'],text=True).strip())
    notices.append('Go standard library\n'+(goroot/'LICENSE').read_text())
    for module in modules:
        if module.get('Main'):continue
        directory=module.get('Dir')
        if not directory:raise RuntimeError('Module not downloaded: '+module['Path'])
        licenses=sorted(p for p in Path(directory).iterdir() if p.is_file() and p.name.lower().startswith(('license','copying','notice','copyright')))
        if not licenses:raise RuntimeError('Missing license: '+module['Path'])
        notices.append('\n\n'+module['Path']+' '+module['Version']+'\n'+'\n'.join(p.read_text(errors='replace') for p in licenses))
    (ROOT/'engine/THIRD_PARTY_NOTICES.txt').write_text('\n'.join(notices))
    print('Collected notices for',len(modules)-1,'Go modules and standard library.')
if __name__=='__main__':main()

#!/usr/bin/env python3
"""Build a self-contained static download site with verified local artifacts."""
import json
import shutil
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def build():
    version = json.loads((ROOT / 'version.json').read_text())['name']
    pc = ROOT / f'release/LUNARVOID-PC-Windows-x64-{version}.zip'
    apk = ROOT / 'release/LUNARVOID-PROXY-debug.apk'
    dashboard = ROOT / 'V15/dist/index.html'
    for artifact, member in [(pc, 'LUNARVOID-PC/V15/dist/index.html'), (apk, 'assets/index.html')]:
        with zipfile.ZipFile(artifact) as archive:
            if archive.testzip() is not None or archive.read(member) != dashboard.read_bytes():
                raise ValueError(f'Rebuild stale or invalid artifact: {artifact.name}')
    dest = ROOT / 'site/build'
    dest.mkdir(parents=True, exist_ok=True)
    (dest / 'downloads').mkdir(exist_ok=True)
    (dest / 'dashboard').mkdir(exist_ok=True)
    html = (ROOT / 'site/index.html').read_text()
    for key, value in {'VERSION': version, 'PC_SIZE': f'{pc.stat().st_size / 1048576:.1f} MB',
                       'APK_SIZE': f'{apk.stat().st_size / 1024:.0f} KB'}.items():
        html = html.replace(f'@@{key}@@', value)
    (dest / 'index.html').write_text(html)
    shutil.copyfile(dashboard, dest / 'dashboard/index.html')
    shutil.copyfile(pc, dest / 'downloads/LUNARVOID-PC-Windows-x64.zip')
    shutil.copyfile(apk, dest / 'downloads/LUNARVOID-Android.apk')
    print('Built site/build with dashboard and verified Windows/Android downloads.')
    return dest

if __name__ == '__main__':
    build()

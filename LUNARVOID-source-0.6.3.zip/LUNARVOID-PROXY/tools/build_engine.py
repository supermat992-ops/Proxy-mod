#!/usr/bin/env python3
"""Build independent, pinned26.30/26.40/26.50 engines. This does not translate versions."""
import os
from pathlib import Path
import subprocess
ROOT=Path(__file__).resolve().parents[1]
def main():
    subprocess.run(['python3',str(ROOT/'tools/collect_engine_notices.py')],check=True)
    dest=ROOT/'engine/build';dest.mkdir(exist_ok=True)
    ndk=Path(os.environ.get('ANDROID_NDK_HOME',str(Path.home()/'runtime/android/sdk/ndk/27.2.12479018')))
    clang=ndk/'toolchains/llvm/prebuilt/linux-x86_64/bin/aarch64-linux-android26-clang'
    jni=ROOT/'android/app/src/main/jniLibs/arm64-v8a';jni.mkdir(parents=True,exist_ok=True)
    # Remove the superseded single-version library from the APK.
    for old in ['liblunarvoid.so','liblunarvoid.h']:
        (jni/old).unlink(missing_ok=True)
    for version in ['30','40','50']:
        mod=[] if version=='30' else [f'-modfile=go-26.{version}.mod']
        for env,args in [({'GOOS':'android','GOARCH':'arm64','CGO_ENABLED':'1','CC':str(clang),'CGO_CFLAGS':'-DLV_VERSION_'+version if version!='30' else ''},['-buildmode=c-shared','-o',str(jni/f'liblunarvoid{version}.so'),'./cmd/android']),({'GOOS':'windows','GOARCH':'amd64','CGO_ENABLED':'0'},['-o',str(dest/f'lunarvoid-engine{version}.exe'),'./cmd/desktop']),({'GOOS':'linux','GOARCH':'amd64','CGO_ENABLED':'0'},['-o',str(dest/f'lunarvoid-engine{version}'),'./cmd/desktop'])]:
            flags='-s -w -checklinkname=0'
            if env.get('GOOS')=='android':flags+=' -extldflags=-Wl,-z,max-page-size=16384'
            subprocess.run(['mise','exec','go@1.26.1','--','go','build',*mod,'-tags='+('lv'+version if version!='30' else ''),'-trimpath','-ldflags='+flags,*args],cwd=ROOT/'engine',env={**os.environ,**env},check=True)
        (jni/f'liblunarvoid{version}.h').unlink(missing_ok=True)
    print('Built26.30/26.40/26.50 engines for AndroidARM64 and Windows/Linux x64.')
if __name__=='__main__':main()

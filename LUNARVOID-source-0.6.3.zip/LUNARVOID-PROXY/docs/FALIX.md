# Falix hosting assessment

User clarification: Bedrock only, desired support for 26.30 and later updates, no owned custom domain, and one unused Falix game server. The user confirmed the Free plan and supplied voidproxy.falix.gg, Bedrock port 20489 and Java port 23196. The user reports Paper 26.3; Geyser/Bedrock bridging and allocation protocol details remain unconfirmed; no credentials or panel access have been supplied. No remote configuration has been changed.

## Verified from official Falix documentation

Read on 2026-10-21:

- [Supported games and applications](https://kb.falixnodes.net/falix/dashboard/setup/supported-software): free plans list Minecraft/Hytale; Python and other application runtimes require Premium.
- [Startup configuration](https://kb.falixnodes.net/falix/dashboard/setup/startup-configuration): editing the startup command and the multi-application image are Premium features.
- [Managing ports](https://kb.falixnodes.net/falix/dashboard/networking/extra-port): ports are allocated from a pool, subject to the server’s allocation limit. The default relay range 19140–19155 cannot be assumed to be assigned to this server.
- [Reverse proxy](https://kb.falixnodes.net/falix/dashboard/networking/reverse-proxy): the managed HTTP/HTTPS proxy is Premium. Its falix.org hostname option avoids purchasing a custom domain, but the reverse-proxy feature still requires Premium. This HTTP service does not carry Bedrock UDP traffic.
- [Subdomains and custom domains](https://kb.falixnodes.net/falix/dashboard/networking/subdomains): game-server subdomains are free. The documented `_minecraft._tcp` SRV example is for Java; Bedrock players must use the displayed UDP port explicitly. A free game hostname does not automatically host the website over HTTPS.

Provider documentation describes product capabilities, not the user's actual account entitlements. Confirm them in the panel before selecting software or giving a startup command.

## Pending panel details

The Free plan is confirmed. Ask for the Software or Startup page and, if necessary, the Network > Ports page. Screenshots are sufficient; do not request passwords or API keys. Confirm whether the assigned game port accepts UDP and whether a separately allocated port can serve the web controller behind HTTPS.

If Python is supported, adapt the controller to the actual assigned port(s). A single UDP allocation can be expressed as a range whose start and end are identical; that permits only one active relay session at a time. Never configure unassigned ports or assume a contiguous block. Extra non-contiguous ports would require an explicit allowed-port list in the controller before using them.

For managed panel hosting, do not use the generic systemd/Caddy VPS instructions unchanged. The panel supplies process startup, assigned ports, and (if enabled) its reverse proxy. Confirm the public Host header passed through the managed HTTPS proxy before changing the controller’s same-origin checks.

If the spare server is a free Minecraft-only instance, the current Python controller is not a confirmed supported deployment on it. The native Android relay remains independent of this host and can be tested without purchasing hosting. A permitted game-server plugin implementation would be separate work after confirming software, allocations and provider support; it has not been built.

## Compatibility and nicknames

26.30+ is the requested Bedrock compatibility target. The relay forwards bytes without parsing game versions, which avoids hard-coding a protocol number, but it does not translate protocols or guarantee future releases. A real client must log in to a destination supporting that client version; test each update before declaring support.

A nickname visible to other players on arbitrary servers is controlled by those servers and their plugins/permissions. Transparent forwarding does not grant nickname permission or change signed account identity. The app currently saves a preferred nickname locally. No universal automatic nickname behavior is implemented.

## Reachability check

A direct RakNet unconnected ping to voidproxy.falix.gg:20489 on 2026-10-21 resolved the hostname but received UDP connection refused from this sandbox. This does not establish whether the server is stopped, the port is incorrect, or network filtering is involved. No Bedrock version advertisement or player login was obtained. Java port 23196 was supplied for context and has not been probed.

The user chose APK-first local connections after clarifying Paper 26.3. No further Falix hosting setup is required for APK same-device or same-Wi-Fi relay modes.

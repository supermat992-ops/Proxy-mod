0.6.3 UPDATE — current behavior
Settings supports26.30(default),26.40 and26.50 matching engines. Saved sign-in is encrypted using Android Keystore-wrapped AES-GCM or Windows user DPAPI, restored on app reopen/version switch, refreshed when required, and removed by Sign out. Proxy connections do not restart automatically. Microsoft can require reauthentication. The browser never receives stored tokens. An explicit Minecraft UserBusy form cancellation now retries the home menu up to3 times; intentionally closing it does not reopen it. Real Quest/Windows testing is still required. This is not protocol translation: the destination must support the selected client protocol. Via-style26.30→26.40 translation is not implemented.

# Project status and continuation notes

## User requirements preserved

- Keep the existing blue GUI based on the supplied Quest screenshots.
- Do not send source code or downloads until the user asks for them. Prepare ZIP/APK files locally.
- Remove Microsoft linking and unlock all Settings tabs (implemented in the earlier change).
- Save a preferred nickname, eventually apply it through a server nickname plugin where permitted.
- Add × removal to replay camera-path points, matching keyframe removal.
- Prioritize real server connections: add/select a destination, press Start Proxy, display the actual listening address and port beside the status, and join it from Bedrock.
- Prepare an Android APK and responsive website for phone, iPad/tablet and PC.
- Requested website domain: https://LunarVoidProxy.com; user does not own it.
- Bedrock only. Requested compatibility target: 26.30 and subsequent updates; this is a target, not a verified version-support claim.
- User has one unused Falix server. Free plan confirmed; address voidproxy.falix.gg, Bedrock port 20489 and Java port 23196 supplied. User reports Paper 26.3; Bedrock bridging software and allocation details are not confirmed. The user chose APK-first connections, leaving Falix hosting for later.
- Nickname request is for arbitrary servers, not one known plugin. The server remains authoritative; universal remote nickname changes cannot be promised.
- In-game menus/mods come after working connections.
- Preserve a project handoff if the full requested behavior cannot yet be delivered.

## Implemented in this workspace

- Python HTTP controller and transparent IPv4 UDP relay, session ownership/access keys, bounded peers/sessions, stop/idle cleanup, and connection controls using its actual response.
- Android app using the same GUI and a native local UDP relay in a foreground service. Default mode binds loopback for Minecraft on the same Android device. Optional same-Wi-Fi mode binds UDP 19132, shows the Wi-Fi address and forwards/relabels Bedrock LAN discovery replies.
- Displayed listening endpoint, copy control, server-response status, web reload recovery, selected-server change protection during an active relay, and explicit error states.
- Camera-point removal and persisted deletion; responsive connection controls.
- Build scripts, tests, deployment templates and documentation.

## Pending external details and features

- User clarified no owned domain, Bedrock 26.30/26.50+ target, one spare Falix server, and nicknames on any server. Free Falix plan and ports are now supplied; user reports Paper 26.3; an online Bedrock endpoint and bridging configuration are still needed for a real login test. Hosting is deferred in favor of the APK.
- Official Falix documentation lists Python/application runtimes, custom startup commands, and HTTPS reverse proxy as Premium features. Free game subdomains are separate from website hosting. See FALIX.md; do not assume the spare game server can run the current Python backend.
- No public deployment or DNS change has occurred.
- No Minecraft client login or live gameplay has been verified. Synthetic UDP tests prove forwarding only.
- No automatic server nickname change. Transparent forwarding preserves encrypted game traffic; nickname commands require a supported integration and server permission.
- No universal Bedrock compatibility/protocol translation. Destination-supported versions are required.
- In-game menu, mods, replay recording/playback/export, and installing resource packs remain unimplemented.
- Debug APK packaging is separate from release signing, store publishing, iOS native packaging, and physical-device testing.

Validation details and exact working-tree hashes are recorded in the workspace's `workspace-context/validation-record.md` and manifests. Private signing material and access keys are deliberately excluded from the project.

## Validation summary

- Python relay suite: 8 tests passed with real local UDP sockets and HTTP session checks.
- Java relay harness passed against the same UdpRelay class used by the APK.
- Browser flow passed: add/select, real relay allocation, actual UDP fixture reply, reload recovery, stop, point deletion/persistence, and phone/tablet/desktop widths.
- Android debug APK compiled and lint completed. A reviewed warning remains for enabling JavaScript in the bundled-only WebView.
- Android device execution is blocked in this sandbox: /dev/kvm is unavailable, and the bounded API 35 software-emulator attempt did not finish booting. The test emulator was stopped.
- Minecraft login/gameplay, physical Android/Quest behavior and iOS Safari remain unverified.

Packages are staged under the ignored `release/` directory by `python3 tools/package.py`; they are held until the user requests delivery. The source ZIP excludes build caches, local SDK paths, credentials and signing keys.

## Connection-system attachment

The user supplied CONNECTION_REQUEST.txt as the desired architecture. CONNECTION_ARCHITECTURE.md records implementation and corrections. Added APK same-Wi-Fi connections and unencrypted LAN discovery forwarding. Authenticated RakNet/game-session termination, encrypted packet edits, remote menus/mods and seamless server switching remain separate unimplemented protocol-engine work. A browser/native-bridge simulation is not an Android device test. Full Bedrock 26.30/26.50+ support is still a target, not a verified claim.

## 0.4.0 companion menu / requested delivery

The blue menu opens from Home, Play or Settings inside the website/APK. It has Profile, Settings and Edit HUD sidebar entries, LUNARVOID branding and all 44 listed modules plus AutoMine. The module catalog can be filtered/searched; every activation control is disabled because no gameplay engine exists. The Xray, Player Outline and AutoMine settings buttons open central settings. Color previews/preferences and the mining target persist locally; profile input shares the existing nickname preference. Edit HUD remains a clearly labeled reserved view. Start/Stop Replay controls are disabled and explain that recording/sync are unavailable.

This is **not** an overlay inside Minecraft. No universal nickname, server modification, combat automation, ore discovery, editable replay recording or future-version compatibility has been implemented or verified by adding these controls. Neither a website nor transparent encrypted UDP forwarding provides those capabilities. The requested Bedrock26.30/26.50+ gameplay engine remains outstanding.

The user authorized delivery of the current APK and website. Outputs are preview builds, not a production release or a deployment at LunarVoidProxy.com. The APK uses the existing optional same-Wi-Fi relay/discovery implementation; Falix is unnecessary for that local mode. Physical device discovery and full Minecraft login still need testing.

## 0.5.0 preview

- Single release metadata source: version.json. Web About/menu labels and Android versionName/versionCode read it at build time; bump this file for each release.
- Removed the requested slogan. General/Performance preferences now persist and control app messages, sounds, spacing, transitions, glow, skin rotation and preview pixel density. These do not alter Minecraft settings.
- Skin view can display the original PNG instead of the3D model; unsupported WebGL falls back to PNG.
- AutoMine preferences include19 current vanilla ore variants:8 normal,8 deepslate, Nether gold/quartz and ancient debris. These are preferences only, not active automatic mining.
- Visual/Schematic accepts local Bedrock .mcstructure and gzip Litematica .litematic files. Bounded NBT reader:8MB input,16MB expanded,100,000 volume cells,128 regions,48 nesting levels. Wireframe preview shows at most12,000 non-air blocks, with rotation and color selection. Files persist in local IndexedDB; nothing uploads to a server. Bedrock secondary liquid layers, block properties/entity rendering, in-game holograms and world placement are not implemented. Other formats (.schem/.schematic/world ZIP) are not accepted. Tutorial was identified from YouTube metadata, not watched.
- In-game emote activation remains a planned unavailable capability. Transparent UDP forwarding cannot detect encrypted emotes or draw an in-game menu. Gameplay modules remain unavailable, including in Minecraft; no fake game-connected state enables them.
- LAN Android relay no longer expires on10-minute inactivity or8-hour lifetime. The foreground service survives normal activity closure, uses stopWithTask=false, START_STICKY and saved LAN destination for Android process restoration. It waits for Wi-Fi and reopens after address changes. Explicit Stop clears saved resume state. Timed wake lock is renewed while service is active; stale UDP peers still expire. Force-stop, shutdown, vendor restrictions or OS behavior can stop it. No guarantee of continuous operation or uninterrupted game sessions is made; Android device lifecycle testing remains outstanding.
- Public hosting blocked: no hosting connection; GitHub API reports no Pages site and connected bot has no push/admin permission. No deployment/short URL fabricated. The supplied Falix Free/Paper host is unchanged.
- User reports the previous APK works; this is not evidence of every gameplay feature or background condition working. New APK, downloadable website and conversation backup requested. Backup will contain accessible user/assistant messages and attachment references, with scope noted; no internal system/developer/tool reasoning.

## Windows PC app package

Portable Windows10/11 x64 app added using the existing website and Python relay. A small MinGW-compiled GUI executable starts bundled Python3.14.4, which launches Edge (Chrome fallback) in app mode with a separate profile and a loopback-only server. No Python install/admin setup needed. App host validates HTTP Host/Origin, applies CSP, and provides a token-protected Exit PC app control. Same-PC UDP connections only; existing relay idle/lifetime limits remain. No new in-game capabilities are implied.

Windows PE/ZIP and Linux-hosted HTTP/UDP/lifecycle tests are separate from actual Windows execution. No Windows host/Wine was available; real Windows launch, browser process lifetime and Minecraft gameplay remain unverified. Website/APK source content is unchanged.

## 0.6 experimental emote engine

Added a separate native Go engine for AndroidARM64 and Windows x64, pinned to
Bedrock1.26.30/protocol1001 using gophertunnelv1.57.1, plus an independent
1.26.50/protocol2193 engine usingv1.62.0 in0.6.1. Settings defaults to26.30;
switching engines signs out and requires game mode stopped. There is no version
translation. Opt-in Microsoft device-code
sign-in, separate encrypted client/upstream sessions, single-account XUID check,
emote detection, injected Profile/Settings/Edit HUD Minecraft forms and local
response handling are implemented. The original relay remains a separate mode.
The custom blue overlay and all gameplay modules/replays remain unavailable.
Local encrypted protocol fixtures do not establish real-client/authentication
compatibility. Native platform binaries and app builds are separate checks.


0.6.2 connection update: Sign in from Settings, then select a server in Play and press Start Proxy. The primary control now uses the native emote engine; the separate game-mode start/stop panel is removed. Starting stops any legacy forwarding-only relay first. Join the displayed endpoint, select and play an actual emote, or use /.menu. The connection description displays the received emote count. /.help and module aliases (for example /.xray, /.fly, /.automine) are local commands; module aliases report Unavailable because gameplay modules are unfinished. Other server commands pass through. Real-device verification remains pending.

# Connection architecture and the supplied design

The original user attachment is preserved in CONNECTION_REQUEST.txt. It describes an authenticated Bedrock protocol proxy, local discovery, packet modification, and server switching. It is a goal description; it does not establish implemented capabilities.

## Current APK connection flow

1. Add/select a destination Bedrock hostname and UDP port in the bundled GUI.
2. Choose same-device mode (default) or enable **Allow devices on the same Wi-Fi**.
3. Start Proxy opens a real local UDP listener. Same-device mode uses 127.0.0.1 and an available port. Same-Wi-Fi mode uses 0.0.0.0:19132 and displays the Android device's IPv4 Wi-Fi address; 0.0.0.0 is a bind address, not a join address.
4. Minecraft sends discovery pings or connects to that listener. Each client endpoint has a separate connected UDP socket to the destination.
5. The relay forwards the packets and replies. Minecraft performs its normal server login directly through the relay. The app does not request or store Xbox tokens in this forwarding mode.
6. In LAN mode only, valid unconnected pong advertisements are relabeled LUNARVOID and their advertised IPv4 port is changed to the local relay port. The destination's version/protocol/player counts, ping timestamp and GUID are preserved. IPv6 is not offered. Malformed packets and encrypted gameplay traffic are forwarded unchanged.
7. Stop closes the listener and upstream sockets. Wi-Fi address changes stop LAN mode; retry on the new network. Inactivity and maximum lifetime limits still apply.

A persistent Android foreground-service notification keeps controls available while Minecraft is open. LAN mode also holds a Wi-Fi multicast lock to allow discovery traffic through Android's Wi-Fi filtering. The connection-mode checkbox cannot change during starting/active/unknown sessions; stop before selecting a new target or mode.

## Corrections to the supplied notes

### LAN discovery

Bedrock clients normally send unconnected pings, often to a local broadcast address on UDP port 19132. A server replies with a correlated unconnected pong. Broadcasting unsolicited pongs alone does not guarantee a LAN listing. This implementation forwards a real ping and responds only after the destination returns its pong, so it does not fabricate an online destination or version.

A destination must be online for this discovery path. Some clients/consoles do not expose all LAN features; some routers block broadcasts or isolate Wi-Fi clients. Console, Quest and iOS behavior must be tested individually. Running an APK locally does not provide a public Internet address for people outside the LAN.

### Authentication and encrypted packet editing

Transparent forwarding does not need a second account sign-in: the game already performs its own authenticated connection. It also cannot inspect encrypted gameplay traffic. Adding read/modify/inject capabilities requires terminating separate RakNet and Bedrock sessions, compression/encryption handling, an authorized authentication flow, and versioned packet codecs. Merely opening two UDP sockets does not supply those features.

The user previously requested removing the app's Microsoft-linking UI. It remains removed. A future authenticated protocol engine would require an explicit design for how the user authorizes its upstream account session. It must not invent account tokens, bypass the destination's account checks, or promise universal nicknames where the server controls them.

### Switching destinations

The current relay requires Stop, select a new destination, Start, then reconnect in Minecraft. A Transfer packet asks a client to reconnect to another endpoint; a Disconnect packet closes the session. Neither automatically preserves a world/session. Seamless switching requires the full protocol engine plus correct world/player/session state handling and compatible destination authentication. Keeping one UDP socket open does not implement this.

### Bedrock 26.30 and future updates

The relay forwards bytes without hard-coding a Bedrock protocol version. It does not translate incompatible versions or establish that future releases will work. Test real client login and gameplay against compatible destination versions before claiming each update supported. The discovery fixture uses a synthetic 26.30 advertisement; it is not a real-client compatibility test.

## Verification boundary

JDK tests exercise actual local UDP forwarding, discovery round trips including a broadcast, exact advertisement bytes, malformed/opaque packet preservation, port conflicts, self-loop rejection and socket cleanup. Browser checks simulate the native bridge to verify GUI arguments and status. The APK is compiled, linted, signed for debugging and packaged. No working Android emulator is available in this sandbox; physical Android/Wi-Fi, router, console/Quest/iOS and Minecraft login checks remain outstanding.

# Emote guide assessment (initial0.5 design)

Update:0.6 adds a pinned protocol engine and standard Minecraft form menu.
See engine/README.md and docs/PROJECT_STATUS.md for the implementation and
verification limits. The custom client overlay described below remains absent.

The user's supplied guide is preserved unchanged in EMOTE_WHEEL_GUIDE.md.
It describes an input-driven emote selection wheel inside a client. The requested
feature is different: playing an existing Bedrock emote should open LUNARVOID's
Profile / Settings / Edit HUD menu.

## Integration boundaries

- Input listening and camera control require a hook in the Minecraft client.
  MainActivity receives input only for LUNARVOID's own Android activity/WebView.
  The Windows launcher likewise hosts a browser, not the Minecraft engine.
- Angular sector calculation is ordinary UI math. Implementing it in the
  companion would not receive Minecraft emotes or make a game menu appear.
- Rendering requires a Minecraft HUD integration or a supported game UI packet.
  The existing HTML dialog belongs to LUNARVOID's WebView/browser only.
- Dispatch requires version-specific Bedrock packet codecs and an authenticated,
  encrypted session implementation. The current UdpRelay and Python relay forward
  opaque datagrams; sending arbitrary JSON or plugin messages is not a valid
  implementation of Bedrock emote/form packets.

## Required implementation work

A protocol-aware approach needs separate client/upstream RakNet sessions,
login/authentication, compression, encryption and codecs for the target Bedrock
release. After detecting an actual Emote packet it would need to present a
supported game form and handle its response. A form is not the requested custom
blue HUD overlay. A custom HUD instead needs a compatible client integration
or a resource-pack UI design with an appropriate trigger; this guide supplies
neither. Server-side add-ons/plugins would require installation and support on
each destination and cannot provide this on arbitrary servers by themselves.

The0.6.1 downloads now bundle independent26.30 and26.50 protocol engines with
emote-triggered Minecraft forms. Synthetic encrypted protocol tests pass for
both. Real Microsoft login completion and Android/Quest menu rendering still
need testing; the custom blue overlay described by the guide is unfinished.
Settings selects a matching engine, without translating between versions.

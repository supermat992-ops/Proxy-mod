# Hosting LunarVoidProxy.com

## Required resources

1. Own/control `LunarVoidProxy.com` and its DNS.
2. A Linux VPS or server with a stable public IPv4 address, Python 3.10+, and incoming UDP. Static website hosting or an HTTP-only serverless platform cannot host the game relay.
3. Point the domain's A record to that host. A separate `play.LunarVoidProxy.com` A record can point to the same host for Minecraft connections. Do not use an HTTP-only CDN proxy for the `play` record. Do not add AAAA records until IPv6 is implemented and tested.
4. Permit TCP 80/443 for the website and UDP 19140–19155 for relays. The website's HTTPS port is separate from the game's UDP port.

## Install

Copy the source tree to `/opt/lunarvoid`, build with `python3 V15/build.py`, and run the supplied systemd unit as a dedicated unprivileged `lunarvoid` user. Install Caddy using its official platform instructions. Review paths and hostnames in `deploy/` for the actual host.

Set `LUNARVOID_ACCESS_KEY` in `/etc/lunarvoid/relay.env` to a random value of at least 24 characters. Use a root-owned environment file readable only by the service administrator. Do not put the key in source control, URLs, screenshots, or website bundles. Give it to the people allowed to start relays; they enter it in the website's relay access-key field. It does not lock Settings and has no connection to Microsoft or payment.

The service listens for HTTP on 127.0.0.1:3000 behind Caddy and UDP on 0.0.0.0:19140–19155. Caddy supplies HTTPS for the owned, correctly configured domain. The advertised address comes from `--public-host`; it must be reachable from the players' networks.

## Public verification

- Open `https://LunarVoidProxy.com` on a separate network and confirm valid HTTPS.
- Start a relay to an authorized Bedrock destination and check the shown IP/host and UDP port.
- From a real Bedrock client on another network, add the relay address/port and complete login. Confirm normal gameplay and stop behavior.
- Check each required Bedrock version separately. This application does not translate protocols.
- Verify iPhone/iPad browser behavior and joining from Minecraft. The web UI can control the host; it cannot run a local iOS UDP service.

## Service behavior

The controller currently supports up to 16 active relays per process with a matching 16-port range. Each relay has its own opaque owner token for reading/stopping the session. A page reload in the same browser tab restores that token from session storage. If browser storage is unavailable, closing the page loses control of the session; the host still expires it on idle timeout or the maximum eight-hour lifetime.

Destination addresses are resolved once and pinned to IPv4 sockets. Private/loopback destinations are blocked by default; `--allow-lan` is only for an operator who deliberately wants LAN access. Multicast and unspecified addresses are rejected. Keep this service restricted to trusted users; it is not a hardened multi-tenant public relay platform.

No domain has been purchased, DNS changed, VPS provisioned, or public service deployed by this task.

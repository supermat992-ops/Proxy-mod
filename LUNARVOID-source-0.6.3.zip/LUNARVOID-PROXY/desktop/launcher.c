#ifndef UNICODE
#define UNICODE
#endif
#ifndef _UNICODE
#define _UNICODE
#endif
#include <windows.h>
#include <wchar.h>
#include <stdio.h>

int WINAPI wWinMain(HINSTANCE instance, HINSTANCE previous, PWSTR command, int show) {
    wchar_t directory[32768], runtime[32768], script[32768], arguments[65536];
    DWORD length = GetModuleFileNameW(NULL, directory, 32768);
    if (!length || length >= 32768) return 1;
    wchar_t *slash = wcsrchr(directory, L'\\');
    if (!slash) return 1;
    *slash = L'\0';
    if (swprintf(runtime, 32768, L"%ls\\runtime\\pythonw.exe", directory) < 0 ||
        swprintf(script, 32768, L"%ls\\desktop\\launcher.py", directory) < 0 ||
        swprintf(arguments, 65536, L"\"%ls\" -I \"%ls\"", runtime, script) < 0) return 1;
    STARTUPINFOW startup = {0};
    PROCESS_INFORMATION process = {0};
    startup.cb = sizeof(startup);
    if (!CreateProcessW(runtime, arguments, NULL, NULL, FALSE, CREATE_NO_WINDOW, NULL, directory, &startup, &process)) {
        MessageBoxW(NULL, L"Extract the entire ZIP before opening LUNARVOID.exe. Keep the runtime, desktop, relay and V15 folders beside it.", L"LUNARVOID PROXY", MB_OK | MB_ICONERROR);
        return 1;
    }
    CloseHandle(process.hThread);
    CloseHandle(process.hProcess);
    return 0;
}

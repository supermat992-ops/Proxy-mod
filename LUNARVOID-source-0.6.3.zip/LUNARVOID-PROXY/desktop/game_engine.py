"""Private JSON pipe to the native Bedrock engine; never serves credentials."""
import json
import os
from pathlib import Path
import queue
import subprocess
import threading

class GameEngineClient:
    def __init__(self, root):
        suffix = '.exe' if os.name == 'nt' else ''
        self.directory = Path(root) / 'engine/build'
        self.suffix = suffix
        self.version = '26.30'
        self.executable = self.directory / ('lunarvoid-engine30' + suffix)
        self.lock = threading.RLock()
        self.process = None
        self.replies = None

    def _start(self):
        if not self.executable.is_file():
            return False
        self.process = subprocess.Popen([str(self.executable)], stdin=subprocess.PIPE,
            stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True, encoding='utf-8',
            creationflags=subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0)
        replies = self.replies = queue.Queue(maxsize=2)
        process = self.process
        def read():
            try:
                for line in iter(lambda: process.stdout.readline(65537), ''):
                    if len(line) > 65536:
                        break
                    replies.put_nowait(line)
            except (OSError, ValueError, queue.Full):
                pass
            finally:
                try: replies.put_nowait(None)
                except queue.Full: pass
        threading.Thread(target=read, daemon=True).start()
        return True

    def call(self, request):
        with self.lock:
            try:
                if request.get('action') == 'selectVersion':
                    version = request.get('version')
                    if version not in ('26.30', '26.40', '26.50'):
                        return {'error': 'Choose 26.30, 26.40 or 26.50.'}
                    current = self.call({'action': 'status'})
                    if current.get('state') != 'stopped':
                        return {**current, 'error': 'Stop game mode before changing versions.'}
                    if version != self.version:
                        self.close()
                        self.version = version
                        self.executable = self.directory / ('lunarvoid-engine' + version[-2:] + self.suffix)
                    request = {'action': 'status'}
                if self.process is None or self.process.poll() is not None:
                    self.close()
                    if not self._start():
                        return {'available': False, 'state': 'stopped', 'error': 'The Bedrock engine is not bundled. Rebuild the PC app.'}
                self.process.stdin.write(json.dumps(request, ensure_ascii=True) + '\n')
                self.process.stdin.flush()
                line = self.replies.get(timeout=35)
                if line is None: raise RuntimeError('Engine closed')
                data = json.loads(line)
                data['address'] = '127.0.0.1'
                data['selectedVersion'] = self.version
                data['supportedVersions'] = ['26.30', '26.40', '26.50']
                return data
            except (OSError, ValueError, RuntimeError, queue.Empty):
                self.close()
                return {'available': False, 'state': 'stopped', 'error': 'The game engine stopped. Retry, then sign in again.'}

    def close(self):
        with self.lock:
            process, self.process = self.process, None
            if process is not None:
                try:
                    process.stdin.close()
                    process.wait(timeout=3)
                except (OSError, subprocess.TimeoutExpired):
                    process.kill()
                    process.wait(timeout=3)
                finally:
                    process.stdout.close()

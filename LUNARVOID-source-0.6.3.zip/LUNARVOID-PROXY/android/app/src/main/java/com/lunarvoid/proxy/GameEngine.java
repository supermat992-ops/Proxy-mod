package com.lunarvoid.proxy;

import android.content.Context;
import org.json.JSONObject;

/** Shared Bedrock engine. Its saved session is encrypted with a Keystore-protected key. */
public final class GameEngine {
    private static volatile String selected = "26.30";
    private static String initialized;
    private static String storageError;
    static String call(String raw) {
        try { return "26.50".equals(selected) ? GameEngine50.callNative(raw) : "26.40".equals(selected) ? GameEngine40.callNative(raw) : GameEngine30.callNative(raw); }
        catch (UnsatisfiedLinkError | NoClassDefFoundError unavailable) {
            return "{\"available\":false,\"state\":\"stopped\",\"error\":\"Game mode requires ARM64 Android and its bundled native engine.\"}";
        }
    }
    static String status() {
        try {
            JSONObject status = new JSONObject(call("{\"action\":\"status\"}"));
            status.put("selectedVersion", selected);
            if (storageError != null) { status.put("sessionWarning", storageError); }
            status.put("supportedVersions", new org.json.JSONArray("[\"26.30\",\"26.40\",\"26.50\"]"));
            status.put("address", status.optBoolean("lan") ? RelayService.wifiAddress(GameService.context()) : "127.0.0.1");
            if (GameService.starting) status.put("state", "starting");
            if (GameService.failure != null) status.put("error", GameService.failure);
            return status.toString();
        } catch (Exception failure) { return "{\"error\":\"Could not read game engine status.\"}"; }
    }
    static String request(Context context, String raw) {
        try {
            if (raw == null || raw.length() > 4096) throw new IllegalArgumentException();
            initialize(context);
            JSONObject request = new JSONObject(raw);
            String action = request.optString("action");
            if ("selectVersion".equals(action)) {
                String version = request.optString("version");
                if (!"26.30".equals(version) && !"26.40".equals(version) && !"26.50".equals(version))
                    return "{\"error\":\"Choose 26.30, 26.40 or 26.50.\"}";
                String state = new JSONObject(call("{\"action\":\"status\"}")).optString("state");
                if (GameService.starting || !"stopped".equals(state))
                    return "{\"error\":\"Stop game mode before changing versions.\"}";
                if (!version.equals(selected)) {
                    GameService.stop(context);
                    call("{\"action\":\"suspend\"}");
                    selected = version;
                    initialized = null;
                    initialize(context);
                    GameService.failure = null;
                }
            } else if ("start".equals(action)) {
                JSONObject status = new JSONObject(call("{\"action\":\"status\"}"));
                if (!status.optBoolean("available") || !status.optBoolean("signedIn"))
                    return "{\"error\":\"Sign in first. Game mode requires ARM64 Android and a Microsoft session.\"}";
                if (request.optBoolean("lan") && RelayService.wifiAddress(context) == null)
                    return "{\"error\":\"Connect to Wi-Fi before starting LAN game mode.\"}";
                RelayService.stop(context);
                GameService.launch(context, raw);
            } else if ("stop".equals(action) || "signout".equals(action)) {
                GameService.stop(context);
                if ("signout".equals(action)) call(raw);
            } else if (!"status".equals(action)) call(raw);
            return status();
        } catch (Exception failure) { return "{\"error\":\"Could not process the game engine request.\"}"; }
    }
    private static synchronized void initialize(Context context) {
        if(selected.equals(initialized))return;
        storageError=null;
        try {
            String path=new java.io.File(context.getNoBackupFilesDir(),"session.bin").getAbsolutePath();
            String key=SessionKey.get(context);
            boolean ok="26.50".equals(selected)?GameEngine50.configureNative(path,key):"26.40".equals(selected)?GameEngine40.configureNative(path,key):GameEngine30.configureNative(path,key);
            if(!ok)throw new IllegalStateException();
        }catch(Exception | LinkageError failure){storageError="Protected sign-in storage is unavailable. This session will not survive an app restart.";}
        initialized=selected;
    }
    private GameEngine() {}
}

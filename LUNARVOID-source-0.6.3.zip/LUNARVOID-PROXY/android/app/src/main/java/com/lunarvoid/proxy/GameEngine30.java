package com.lunarvoid.proxy;
final class GameEngine30 {
 static {System.loadLibrary("lunarvoid30");}
 static native String callNative(String raw);
 static native boolean configureNative(String path,String key);
}

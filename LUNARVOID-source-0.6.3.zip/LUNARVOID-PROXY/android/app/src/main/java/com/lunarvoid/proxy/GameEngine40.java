package com.lunarvoid.proxy;
final class GameEngine40 {
 static {System.loadLibrary("lunarvoid40");}
 static native String callNative(String raw);
 static native boolean configureNative(String path,String key);
}

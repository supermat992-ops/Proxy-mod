package com.lunarvoid.proxy;

import java.nio.ByteBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;

/** Relabels a valid Bedrock unconnected pong without touching session traffic. */
final class LanDiscovery {
    private static final byte[] MAGIC = {
        0, (byte)255, (byte)255, 0, (byte)254, (byte)254, (byte)254, (byte)254,
        (byte)253, (byte)253, (byte)253, (byte)253, 0x12, 0x34, 0x56, 0x78
    };

    static ByteBuffer rewritePong(ByteBuffer packet, int port) {
        ByteBuffer input = packet.slice();
        if (input.remaining() < 35 || input.get(0) != 0x1c) return packet;
        for (int i = 0; i < MAGIC.length; i++) if (input.get(17 + i) != MAGIC[i]) return packet;
        int length = Short.toUnsignedInt(input.getShort(33));
        if (length != input.remaining() - 35) return packet;
        ByteBuffer text = input.duplicate(); text.position(35);
        String advertisement;
        try {
            advertisement = StandardCharsets.UTF_8.newDecoder()
                .onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPORT)
                .decode(text).toString();
        } catch (CharacterCodingException malformed) { return packet; }
        String[] fields = advertisement.split(";", -1);
        if (fields.length < 6 || !"MCPE".equals(fields[0])) return packet;
        fields[1] = "LUNARVOID · " + fields[1];
        // Older advertisements may omit ports; then the discovery UDP source port is used.
        if (fields.length > 10) fields[10] = Integer.toString(port);
        if (fields.length > 11) fields[11] = "0"; // This relay has no IPv6 listener.
        byte[] encoded = String.join(";", fields).getBytes(StandardCharsets.UTF_8);
        if (encoded.length > 65507 - 35) return packet;
        ByteBuffer result = ByteBuffer.allocate(35 + encoded.length);
        input.limit(33); result.put(input).putShort((short) encoded.length).put(encoded).flip();
        return result;
    }
}

package com.lunarvoid.proxy;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.LinkAddress;
import android.net.LinkProperties;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.wifi.WifiManager;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import org.json.JSONObject;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.net.Inet4Address;

public final class RelayService extends Service {
    private static final Object LOCK = new Object();
    private static UdpRelay relay;
    private static String state = "stopped", error;
    private static String address = "127.0.0.1";
    private static boolean lanMode;
    private static long generation;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private PowerManager.WakeLock wakeLock;
    private WifiManager.MulticastLock multicastLock;
    private long activeGeneration = -1;
    private String targetHost;
    private int targetPort;
    private int currentStartId;
    private boolean serviceLan;
    private long wakeRenewed;
    private static android.content.SharedPreferences saved(Context context) {
        return context.getSharedPreferences("lan-relay", MODE_PRIVATE);
    }
    private static void forget(Context context) { saved(context).edit().clear().commit(); }
    private final Runnable monitor = new Runnable() {
        @Override public void run() {
            synchronized (LOCK) {
                if (activeGeneration != generation) return;
                if (wakeLock != null && android.os.SystemClock.elapsedRealtime() - wakeRenewed > 300_000) {
                    wakeLock.acquire(600_000); wakeRenewed = android.os.SystemClock.elapsedRealtime();
                }
                String wifi = serviceLan ? wifiAddress(RelayService.this) : null;
                if (relay != null && serviceLan && !address.equals(wifi)) {
                    relay.close(); relay = null; state = "waiting";
                    error = "Waiting for Wi-Fi. The relay will reopen when Wi-Fi is available.";
                }
                if (relay != null && !relay.isRunning()) {
                    error = relay.getError(); relay = null; state = "stopped";
                    forget(RelayService.this); stopSelf(); return;
                }
                if (serviceLan && "waiting".equals(state) && wifi != null) {
                    address = wifi; state = "starting"; error = null;
                    openRelay(targetHost, targetPort, true, activeGeneration, currentStartId);
                }
            }
            handler.postDelayed(this, 2000);
        }
    };
    public static String status() {
        synchronized (LOCK) {
            JSONObject result = new JSONObject();
            try {
                result.put("state", relay != null && relay.isRunning() ? "running" : state);
                result.put("address", address);
                result.put("localAddress", "127.0.0.1");
                result.put("lan", lanMode);
                result.put("port", relay == null ? 0 : relay.port);
                result.put("packetsSent", relay == null ? 0 : relay.sent.get());
                result.put("packetsReceived", relay == null ? 0 : relay.received.get());
                if (error != null) result.put("error", error);
            } catch (org.json.JSONException ignored) {}
            return result.toString();
        }
    }
    static String wifiAddress(Context context) {
        if (context == null) return null;
        ConnectivityManager manager = context.getSystemService(ConnectivityManager.class);
        for (Network network : manager.getAllNetworks()) {
            NetworkCapabilities caps = manager.getNetworkCapabilities(network);
            if (caps == null || !caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) continue;
            LinkProperties links = manager.getLinkProperties(network);
            if (links == null) continue;
            for (LinkAddress link : links.getLinkAddresses()) {
                if (link.getAddress() instanceof Inet4Address && !link.getAddress().isLoopbackAddress())
                    return link.getAddress().getHostAddress();
            }
        }
        return null;
    }
    public static String start(Context context, String host, int port, boolean lan) {
        synchronized (LOCK) {
            if ("waiting".equals(state) || "starting".equals(state) || (relay != null && relay.isRunning())) return status();
            if (host == null || !host.matches("[A-Za-z0-9.-]{1,253}") || port < 1 || port > 65535) {
                state = "stopped"; error = "Check the server address and port."; return status();
            }
            String wifi = lan ? wifiAddress(context) : null;
            if (lan && wifi == null) {
                state = "stopped"; error = "Connect this Android device to Wi-Fi before enabling same-Wi-Fi mode.";
                return status();
            }
            lanMode = lan; address = lan ? wifi : "127.0.0.1";
            state = "starting"; error = null;
            long request = ++generation;
            try {
                context.startForegroundService(new Intent(context, RelayService.class)
                        .putExtra("host", host).putExtra("port", port).putExtra("generation", request).putExtra("lan", lan));
            } catch (RuntimeException failure) {
                state = "stopped"; error = "Android could not start the relay. Open the app and try again.";
            }
            return status();
        }
    }
    public static String stop(Context context) {
        synchronized (LOCK) {
            forget(context); shutdown(); error = null;
            context.stopService(new Intent(context, RelayService.class));
        }
        return status();
    }
    private static void shutdown() {
        synchronized (LOCK) {
            ++generation;
            if (relay != null) { relay.close(); relay = null; }
            state = "stopped";
        }
    }
    @Override public void onCreate() {
        super.onCreate();
        NotificationManager manager = getSystemService(NotificationManager.class);
        manager.createNotificationChannel(new NotificationChannel("relay", "Game relay", NotificationManager.IMPORTANCE_LOW));
        PendingIntent open = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent stop = PendingIntent.getService(this, 1, new Intent(this, RelayService.class).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification notification = new Notification.Builder(this, "relay").setSmallIcon(com.lunarvoid.proxy.R.drawable.ic_proxy)
                .setContentTitle("LUNARVOID relay").setContentText("Open LUNARVOID for your connection address and port.")
                .setOngoing(true).setContentIntent(open).addAction(new Notification.Action.Builder(null, "Stop", stop).build()).build();
        startForeground(1, notification);
        wakeLock = getSystemService(PowerManager.class).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "LUNARVOID:relay");
        wakeLock.setReferenceCounted(false);
        wakeLock.acquire(600_000);
        wakeRenewed = android.os.SystemClock.elapsedRealtime();
        handler.postDelayed(monitor, 2000);
    }
    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && "STOP".equals(intent.getAction())) {
            stop(this); return START_NOT_STICKY;
        }
        String host;
        int port;
        boolean lan;
        long request;
        if (intent == null) {
            android.content.SharedPreferences config = saved(this);
            if (!config.getBoolean("enabled", false)) { shutdown(); stopSelf(); return START_NOT_STICKY; }
            host = config.getString("host", ""); port = config.getInt("port", 0); lan = true;
            if (!host.matches("[A-Za-z0-9.-]{1,253}") || port < 1 || port > 65535) {
                forget(this); shutdown(); stopSelf(); return START_NOT_STICKY;
            }
            synchronized (LOCK) { request = ++generation; state = "starting"; lanMode = true; error = null; }
        } else {
            host = intent.getStringExtra("host"); port = intent.getIntExtra("port", 0);
            lan = intent.getBooleanExtra("lan", false); request = intent.getLongExtra("generation", -1);
        }
        synchronized (LOCK) {
            if (request != generation) { stopSelf(startId); return START_NOT_STICKY; }
            activeGeneration = request;
            currentStartId = startId;
            targetHost = host; targetPort = port; serviceLan = lan;
            if (lan) saved(this).edit().putBoolean("enabled", true).putString("host", host).putInt("port", port).commit();
            else forget(this);
        }
        if (lan) {
            try {
                if (multicastLock == null) {
                    WifiManager wifi = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                    multicastLock = wifi.createMulticastLock("LUNARVOID:discovery");
                    multicastLock.setReferenceCounted(false);
                }
                if (!multicastLock.isHeld()) multicastLock.acquire();
            } catch (RuntimeException unavailable) {
                synchronized (LOCK) { state = "stopped"; error = "Android could not enable Wi-Fi discovery. Use same-device mode or try again."; }
                forget(this); stopSelf(); return START_NOT_STICKY;
            }
        } else if (multicastLock != null && multicastLock.isHeld()) {
            multicastLock.release();
        }
        String wifi = lan ? wifiAddress(this) : null;
        if (lan && wifi == null) {
            synchronized (LOCK) { state = "waiting"; error = "Waiting for Wi-Fi. The relay will reopen when Wi-Fi is available."; }
        } else {
            synchronized (LOCK) { address = lan ? wifi : "127.0.0.1"; }
            openRelay(host, port, lan, request, startId);
        }
        return lan ? START_STICKY : START_NOT_STICKY;
    }
    private void openRelay(String host, int port, boolean lan, long request, int startId) {
        worker.execute(() -> {
            UdpRelay opened = null;
            try {
                opened = new UdpRelay(host, port, lan);
                synchronized (LOCK) {
                    if (request != generation) { opened.close(); return; }
                    if (relay != null) relay.close();
                    relay = opened; state = "running"; error = null;
                }
            } catch (Exception failure) {
                if (opened != null) opened.close();
                synchronized (LOCK) {
                    if (request != generation) return;
                    state = "stopped";
                    error = failure instanceof java.io.IOException ? failure.getMessage()
                        : "Could not start the relay. Check the server address and network.";
                    forget(this); stopSelf(startId);
                }
            }
        });
    }
    @Override public void onDestroy() {
        // An old service destruction must not cancel a newly queued Start request.
        synchronized (LOCK) { if (activeGeneration == generation) shutdown(); }
        handler.removeCallbacksAndMessages(null); worker.shutdownNow();
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        if (multicastLock != null && multicastLock.isHeld()) multicastLock.release();
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}

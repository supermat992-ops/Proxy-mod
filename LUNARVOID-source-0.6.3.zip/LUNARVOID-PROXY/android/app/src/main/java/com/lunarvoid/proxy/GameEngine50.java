package com.lunarvoid.proxy;
final class GameEngine50 {
 static {System.loadLibrary("lunarvoid50");}
 static native String callNative(String raw);
 static native boolean configureNative(String path,String key);
}

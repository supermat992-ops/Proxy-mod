package com.lunarvoid.proxy;

import java.io.Closeable;
import java.io.IOException;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.NetworkInterface;
import java.net.SocketAddress;
import java.net.BindException;
import java.nio.ByteBuffer;
import java.nio.channels.DatagramChannel;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;

/** Transparent UDP forwarding. Does not decrypt game packets or translate versions. */
public final class UdpRelay implements Closeable {
    private final DatagramChannel listener;
    private final Selector selector;
    private final InetSocketAddress target;
    private final Thread thread;
    private volatile boolean running = true;
    private volatile String error;
    public final AtomicLong sent = new AtomicLong();
    public final AtomicLong received = new AtomicLong();
    public final int port;
    private final long idleNanos;
    private final long peerIdleNanos;
    private final boolean lan;
    private static final class Peer {
        final DatagramChannel channel;
        long last;
        Peer(DatagramChannel channel, long last) { this.channel = channel; this.last = last; }
    }

    public UdpRelay(String host, int port) throws IOException {
        this(host, port, false);
    }
    public UdpRelay(String host, int port, boolean lan) throws IOException {
        this(host, port, lan, lan ? 19132 : 0, 600_000, 120_000);
    }
    UdpRelay(String host, int port, long idleMillis, long peerIdleMillis) throws IOException {
        this(host, port, false, 0, idleMillis, peerIdleMillis);
    }
    UdpRelay(String host, int port, boolean lan, int listenPort, long idleMillis, long peerIdleMillis) throws IOException {
        if (host == null || !host.matches("[A-Za-z0-9.-]{1,253}") || port < 1 || port > 65535)
            throw new IOException("Check the server hostname and port.");
        InetAddress chosen = null;
        for (InetAddress address : InetAddress.getAllByName(host)) {
            if (address instanceof Inet4Address && !address.isAnyLocalAddress() && !address.isMulticastAddress()
                    && !address.getHostAddress().equals("255.255.255.255")) { chosen = address; break; }
        }
        if (chosen == null) throw new IOException("No usable IPv4 address was found for this server.");
        target = new InetSocketAddress(chosen, port);
        this.lan = lan;
        idleNanos = idleMillis * 1_000_000L;
        peerIdleNanos = peerIdleMillis * 1_000_000L;
        selector = Selector.open();
        DatagramChannel opened = null;
        try {
            opened = DatagramChannel.open();
            opened.configureBlocking(false);
            opened.socket().bind(new InetSocketAddress(lan ? "0.0.0.0" : "127.0.0.1", listenPort));
            opened.register(selector, SelectionKey.OP_READ);
            listener = opened;
            this.port = listener.socket().getLocalPort();
            if (target.getPort() == this.port && (target.getAddress().isLoopbackAddress()
                    || NetworkInterface.getByInetAddress(target.getAddress()) != null))
                throw new IOException("The server cannot be this relay's own listening port.");
        } catch (IOException | RuntimeException failure) {
            if (opened != null) opened.close();
            selector.close();
            if (failure instanceof BindException && lan)
                throw new IOException("LAN port 19132 is already in use. Stop the other local server or turn off same-Wi-Fi mode.", failure);
            throw failure;
        }
        thread = new Thread(this::run, "lunarvoid-udp");
        thread.setDaemon(true);
        thread.start();
    }
    private void run() {
        Map<SocketAddress, Peer> peers = new HashMap<>();
        ByteBuffer buffer = ByteBuffer.allocate(65535);
        long created = System.nanoTime(), lastPacket = created;
        try {
            while (running) {
                long now = System.nanoTime();
                if (!lan && (now - lastPacket > idleNanos || now - created > 8L * 3600 * 1_000_000_000L)) break;
                selector.select(200);
                Iterator<SelectionKey> keys = selector.selectedKeys().iterator();
                while (keys.hasNext()) {
                    SelectionKey key = keys.next(); keys.remove();
                    if (!key.isValid()) continue;
                    buffer.clear();
                    if (key.channel() == listener) {
                        SocketAddress client = listener.receive(buffer);
                        if (client == null || buffer.position() == 0) continue;
                        InetAddress clientAddress = ((InetSocketAddress) client).getAddress();
                        if (lan && !clientAddress.isLoopbackAddress() && !clientAddress.isSiteLocalAddress()
                                && !clientAddress.isLinkLocalAddress()) continue;
                        Peer peer = peers.get(client);
                        if (peer == null) {
                            if (peers.size() >= 8) continue;
                            DatagramChannel upstream = DatagramChannel.open();
                            try {
                                upstream.configureBlocking(false); upstream.connect(target);
                                upstream.register(selector, SelectionKey.OP_READ, client);
                            } catch (IOException | RuntimeException failure) { upstream.close(); throw failure; }
                            peer = new Peer(upstream, now); peers.put(client, peer);
                        }
                        buffer.flip();
                        try { if (peer.channel.write(buffer) > 0) sent.incrementAndGet(); }
                        catch (java.net.PortUnreachableException ignored) { /* Wait for further game packets. */ }
                        peer.last = lastPacket = now;
                    } else {
                        SocketAddress client = (SocketAddress) key.attachment();
                        DatagramChannel upstream = (DatagramChannel) key.channel();
                        try {
                            if (upstream.read(buffer) <= 0) continue;
                            buffer.flip();
                            // Only the unencrypted LAN discovery advertisement is rewritten.
                            ByteBuffer reply = lan ? LanDiscovery.rewritePong(buffer, port) : buffer;
                            if (listener.send(reply, client) > 0) received.incrementAndGet();
                            peers.get(client).last = lastPacket = now;
                        } catch (java.net.PortUnreachableException ignored) { /* Server may be offline. */ }
                    }
                }
                Iterator<Peer> entries = peers.values().iterator();
                while (entries.hasNext()) {
                    Peer peer = entries.next();
                    if (now - peer.last > peerIdleNanos) { peer.channel.close(); entries.remove(); }
                }
            }
        } catch (IOException | RuntimeException failure) {
            if (running) error = "The relay stopped unexpectedly. Start it again.";
        } finally {
            running = false;
            for (Peer peer : peers.values()) try { peer.channel.close(); } catch (IOException ignored) {}
            try { listener.close(); selector.close(); } catch (IOException ignored) {}
        }
    }
    public boolean isRunning() { return running; }
    public String getError() { return error; }
    @Override public void close() {
        running = false; selector.wakeup();
        if (Thread.currentThread() != thread) {
            try { thread.join(1500); } catch (InterruptedException interrupted) { Thread.currentThread().interrupt(); }
        }
    }
}

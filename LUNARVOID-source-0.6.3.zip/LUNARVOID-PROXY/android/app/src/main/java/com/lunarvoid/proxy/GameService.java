package com.lunarvoid.proxy;

import android.app.*;
import android.content.*;
import android.net.wifi.WifiManager;
import android.os.*;
import org.json.JSONObject;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Foreground lifecycle for the opt-in protocol engine while Minecraft is open. */
public final class GameService extends Service {
    private static final Object LOCK = new Object();
    private static Context application;
    static volatile boolean starting;
    static volatile String failure;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private PowerManager.WakeLock wake;
    private WifiManager.MulticastLock multicast;
    private boolean destroyed;
    private static long generation;
    private long activeGeneration = -1;
    static Context context() { return application; }
    static void launch(Context context, String raw) {
        application = context.getApplicationContext();
        long request;
        synchronized (LOCK) { starting = true; failure = null; request = ++generation; }
        try { context.startForegroundService(new Intent(context, GameService.class).putExtra("request", raw).putExtra("generation", request)); }
        catch (RuntimeException unavailable) { starting = false; failure = "Android could not start game mode. Open the app and retry."; }
    }
    static void stop(Context context) {
        synchronized (LOCK) { ++generation; starting = false; GameEngine.call("{\"action\":\"stop\"}"); }
        context.stopService(new Intent(context, GameService.class));
    }
    @Override public void onCreate() {
        super.onCreate(); application = getApplicationContext();
        NotificationManager manager = getSystemService(NotificationManager.class);
        manager.createNotificationChannel(new NotificationChannel("game", "Bedrock game proxy", NotificationManager.IMPORTANCE_LOW));
        PendingIntent open = PendingIntent.getActivity(this, 20, new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent stop = PendingIntent.getService(this, 21, new Intent(this, GameService.class).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        startForeground(2, new Notification.Builder(this, "game").setSmallIcon(com.lunarvoid.proxy.R.drawable.ic_proxy)
            .setContentTitle("LUNARVOID game proxy").setContentText("Experimental emote menu · Open LUNARVOID for status.")
            .setOngoing(true).setContentIntent(open).addAction(new Notification.Action.Builder(null, "Stop", stop).build()).build());
        wake = getSystemService(PowerManager.class).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "LUNARVOID:game");
        wake.setReferenceCounted(false); wake.acquire(600_000);
        WifiManager wifi = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
        multicast = wifi.createMulticastLock("LUNARVOID:game"); multicast.setReferenceCounted(false); multicast.acquire();
        handler.postDelayed(monitor, 2000);
    }
    private final Runnable monitor = new Runnable() {
        public void run() {
            try {
                JSONObject status = new JSONObject(GameEngine.call("{\"action\":\"status\"}"));
                if (!starting && "stopped".equals(status.optString("state"))) { stopSelf(); return; }
                if (!wake.isHeld()) wake.acquire(600_000);
            } catch (Exception ignored) {}
            handler.postDelayed(this, 2000);
        }
    };
    @Override public int onStartCommand(Intent intent, int flags, int id) {
        if (intent == null || "STOP".equals(intent.getAction())) { stop(this); return START_NOT_STICKY; }
        String raw = intent.getStringExtra("request");
        long request = intent.getLongExtra("generation", -1);
        worker.execute(() -> {
            synchronized (LOCK) {
                if (destroyed || !starting || request != generation) return;
                activeGeneration = request;
                try { GameEngine.call(raw); }
                catch (RuntimeException failed) { failure = "The game engine stopped unexpectedly."; }
                finally { if (request == generation) starting = false; }
            }
        });
        // Reopening restores the encrypted account session; restarting a proxy still requires user action.
        return START_NOT_STICKY;
    }
    @Override public void onDestroy() {
        synchronized (LOCK) { destroyed = true; if (activeGeneration == generation) { starting = false; GameEngine.call("{\"action\":\"stop\"}"); } }
        handler.removeCallbacksAndMessages(null); worker.shutdownNow();
        if (wake != null && wake.isHeld()) wake.release();
        if (multicast != null && multicast.isHeld()) multicast.release();
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}

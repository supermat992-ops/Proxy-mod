package com.lunarvoid.proxy;

import android.content.Context;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.AtomicFile;
import java.io.File;
import java.io.FileOutputStream;
import java.security.KeyStore;
import java.security.SecureRandom;
import java.util.Arrays;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/** Random session encryption key wrapped with the non-exportable Android Keystore key. */
final class SessionKey {
    static synchronized String get(Context context) throws Exception {
        KeyStore store=KeyStore.getInstance("AndroidKeyStore");store.load(null);
        String alias="lunarvoid.session.v1";
        if(!store.containsAlias(alias)) {
            KeyGenerator generator=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");
            generator.init(new KeyGenParameterSpec.Builder(alias,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());
            generator.generateKey();
        }
        SecretKey wrapping=(SecretKey)store.getKey(alias,null);
        AtomicFile file=new AtomicFile(new File(context.getNoBackupFilesDir(),"session-key.bin"));
        Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");
        byte[] key;
        if(file.getBaseFile().exists()) {
            byte[] data=file.readFully();
            if(data.length<28||data.length>256)throw new IllegalStateException("Invalid stored key");
            cipher.init(Cipher.DECRYPT_MODE,wrapping,new GCMParameterSpec(128,Arrays.copyOfRange(data,0,12)));
            key=cipher.doFinal(Arrays.copyOfRange(data,12,data.length));
        }else{
            key=new byte[32];new SecureRandom().nextBytes(key);
            cipher.init(Cipher.ENCRYPT_MODE,wrapping);
            byte[] encrypted=cipher.doFinal(key);
            FileOutputStream out=file.startWrite();
            try{out.write(cipher.getIV());out.write(encrypted);file.finishWrite(out);}catch(Exception failure){file.failWrite(out);throw failure;}
        }
        if(key.length!=32)throw new IllegalStateException("Invalid key length");
        StringBuilder hex=new StringBuilder();for(byte b:key)hex.append(String.format(java.util.Locale.ROOT,"%02x",b&255));
        Arrays.fill(key,(byte)0);return hex.toString();
    }
    private SessionKey(){}
}

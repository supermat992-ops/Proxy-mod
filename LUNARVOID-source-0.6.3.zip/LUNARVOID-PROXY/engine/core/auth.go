package core

import (
	"context"
	"encoding/json"
	"errors"
	"github.com/sandertv/gophertunnel/minecraft/auth"
	"golang.org/x/oauth2"
	"io"
	"net/http"
	"net/url"
	"strings"
	"sync"
	"time"
)

// Status responses never include tokens. Native hosts configure protected storage.
type liveSource struct {
	mu               sync.Mutex
	token            *oauth2.Token
	ctx              context.Context
	save             func(*oauth2.Token) error
	persistenceError string
	revoked          bool
}

func (s *liveSource) Token() (*oauth2.Token, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.revoked {
		return nil, errors.New("Session signed out.")
	}
	if s.ctx.Err() != nil {
		return nil, s.ctx.Err()
	}
	if s.token.Valid() {
		return s.token, nil
	}
	var data tokenReply
	err := post(s.ctx, tokenURL, url.Values{"client_id": {auth.AndroidConfig.ClientID}, "scope": {scope}, "grant_type": {"refresh_token"}, "refresh_token": {s.token.RefreshToken}}, &data)
	if data.Error == "invalid_grant" {
		s.revoked = true
		if s.save != nil {
			_ = s.save(nil)
		}
	}
	if err != nil || data.Error != "" || data.AccessToken == "" {
		return nil, errors.New("Microsoft session expired. Sign in again.")
	}
	if data.RefreshToken == "" {
		data.RefreshToken = s.token.RefreshToken
	}
	s.token = data.token()
	s.persist()
	return s.token, nil
}

const tokenURL = "https://login.live.com/oauth20_token.srf"
const scope = "service::user.auth.xboxlive.com::MBI_SSL"

type tokenReply struct {
	AccessToken  string `json:"access_token"`
	RefreshToken string `json:"refresh_token"`
	TokenType    string `json:"token_type"`
	ExpiresIn    int    `json:"expires_in"`
	Error        string `json:"error"`
}

func (t tokenReply) token() *oauth2.Token {
	return &oauth2.Token{AccessToken: t.AccessToken, RefreshToken: t.RefreshToken, TokenType: t.TokenType, Expiry: time.Now().Add(time.Duration(t.ExpiresIn) * time.Second)}
}
func post(ctx context.Context, endpoint string, values url.Values, result any) error {
	request, err := http.NewRequestWithContext(ctx, http.MethodPost, endpoint, strings.NewReader(values.Encode()))
	if err != nil {
		return err
	}
	request.Header.Set("Content-Type", "application/x-www-form-urlencoded")
	response, err := (&http.Client{Timeout: 25 * time.Second}).Do(request)
	if err != nil {
		return errors.New("Authentication network request failed.")
	}
	defer response.Body.Close()
	if response.StatusCode >= 500 {
		return errors.New("Microsoft authentication is unavailable. Try again later.")
	}
	return json.NewDecoder(io.LimitReader(response.Body, 65536)).Decode(result)
}
func (e *Engine) signIn() {
	e.mu.Lock()
	if e.authCancel != nil {
		e.authCancel()
	}
	ctx, cancel := context.WithTimeout(context.Background(), 15*time.Minute)
	e.authCancel = cancel
	e.authGeneration++
	generation := e.authGeneration
	e.authState = "starting"
	e.authCode = ""
	e.authURL = ""
	e.authError = ""
	e.mu.Unlock()
	go func() {
		defer cancel()
		var device struct {
			DeviceCode      string `json:"device_code"`
			UserCode        string `json:"user_code"`
			VerificationURI string `json:"verification_uri"`
			Interval        int    `json:"interval"`
			ExpiresIn       int    `json:"expires_in"`
		}
		fail := func() {
			e.mu.Lock()
			defer e.mu.Unlock()
			if e.authGeneration == generation {
				e.authState = "error"
				e.authError = "Sign-in failed or expired. Try again."
				e.authCode = ""
				e.authURL = ""
			}
		}
		if post(ctx, "https://login.live.com/oauth20_connect.srf", url.Values{"client_id": {auth.AndroidConfig.ClientID}, "scope": {scope}, "response_type": {"device_code"}}, &device) != nil || device.DeviceCode == "" || device.UserCode == "" {
			fail()
			return
		}
		u, err := url.Parse(device.VerificationURI)
		if err != nil || u.Scheme != "https" || (u.Host != "microsoft.com" && u.Host != "www.microsoft.com" && u.Host != "login.live.com" && u.Host != "login.microsoftonline.com") {
			fail()
			return
		}
		e.mu.Lock()
		if e.authGeneration != generation {
			e.mu.Unlock()
			return
		}
		e.authCode = device.UserCode
		e.authURL = device.VerificationURI
		e.authState = "pending"
		e.mu.Unlock()
		interval := time.Duration(device.Interval) * time.Second
		if interval < time.Second {
			interval = 5 * time.Second
		}
		deadline := time.NewTimer(time.Duration(max(1, device.ExpiresIn)) * time.Second)
		defer deadline.Stop()
		for {
			timer := time.NewTimer(interval)
			select {
			case <-ctx.Done():
				timer.Stop()
				fail()
				return
			case <-deadline.C:
				timer.Stop()
				fail()
				return
			case <-timer.C:
			}
			var data tokenReply
			if post(ctx, tokenURL, url.Values{"client_id": {auth.AndroidConfig.ClientID}, "grant_type": {"urn:ietf:params:oauth:grant-type:device_code"}, "device_code": {device.DeviceCode}}, &data) != nil {
				fail()
				return
			}
			if data.Error == "authorization_pending" {
				continue
			}
			if data.Error == "slow_down" {
				interval += 5 * time.Second
				continue
			}
			if data.Error != "" || data.AccessToken == "" {
				fail()
				return
			}
			e.mu.Lock()
			if e.authGeneration == generation {
				tokenCtx, tokenCancel := context.WithCancel(context.Background())
				if e.tokenCancel != nil {
					e.tokenCancel()
				}
				e.tokenCancel = tokenCancel
				if old, ok := e.source.(*liveSource); ok {
					old.mu.Lock()
					old.revoked = true
					old.mu.Unlock()
				}
				source := &liveSource{ctx: tokenCtx, token: data.token(), save: e.saveSession}
				source.persist()
				e.source = source
				e.authState = "ready"
				e.authCode = ""
				e.authURL = ""
			}
			e.mu.Unlock()
			return
		}
	}()
}

func (s *liveSource) persist() {
	s.persistenceError = ""
	if s.save != nil && s.save(s.token) != nil {
		s.persistenceError = "Signed in for this session, but saving failed. Sign in again after closing the app."
	}
}

package core

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"github.com/sandertv/gophertunnel/minecraft"
	"github.com/sandertv/gophertunnel/minecraft/protocol"
	"github.com/sandertv/gophertunnel/minecraft/protocol/login"
	"golang.org/x/oauth2"
	"net"
	"net/http"
	"regexp"
	"sync"
	"time"
)

type Request struct {
	Action string `json:"action"`
	Host   string `json:"host"`
	Port   int    `json:"port"`
	LAN    bool   `json:"lan"`
}
type Engine struct {
	mu                                      sync.Mutex
	listener                                *minecraft.Listener
	cancel                                  context.CancelFunc
	state, problem                          string
	port                                    int
	lan                                     bool
	client, upstream                        *minecraft.Conn
	generation                              uint64
	source                                  oauth2.TokenSource
	tokenCancel, authCancel                 context.CancelFunc
	authGeneration                          uint64
	authState, authCode, authURL, authError string
	nickname                                string
	emotes                                  uint64
	store                                   sessionStore
	offlineTest                             bool // Only internal tests can enable offline identities.
}

func New() *Engine {
	e := &Engine{state: "stopped", authState: "idle"}
	e.configureStore(platformStore())
	return e
}
func (e *Engine) Call(raw string) string {
	var r Request
	if len(raw) > 4096 || json.Unmarshal([]byte(raw), &r) != nil {
		return `{"error":"Invalid engine request."}`
	}
	switch r.Action {
	case "status":
	case "signin":
		e.signIn()
	case "signout":
		e.clearSession(true)
	case "suspend":
		e.clearSession(false)
	case "start":
		if err := e.Start(r); err != nil {
			e.mu.Lock()
			e.problem = err.Error()
			e.mu.Unlock()
		}
	case "stop":
		e.Stop()
	default:
		return `{"error":"Unknown engine action."}`
	}
	return e.Status()
}
func (e *Engine) Status() string {
	e.mu.Lock()
	defer e.mu.Unlock()
	data := map[string]any{"available": true, "version": protocol.CurrentVersion, "protocol": protocol.CurrentProtocol, "state": e.state, "error": e.problem, "port": e.port, "lan": e.lan, "signedIn": e.source != nil, "authState": e.authState, "authCode": e.authCode, "authUrl": e.authURL, "authError": e.authError, "nickname": e.nickname, "emotes": e.emotes}
	if source, ok := e.source.(*liveSource); ok {
		source.mu.Lock()
		data["sessionWarning"] = source.persistenceError
		if source.revoked {
			data["signedIn"] = false
			data["authState"] = "error"
			data["authError"] = "Microsoft session expired. Sign in again."
		}
		source.mu.Unlock()
	}
	data["sessionStorageAvailable"] = e.store != nil
	encoded, _ := json.Marshal(data)
	return string(encoded)
}

var hostPattern = regexp.MustCompile(`^[A-Za-z0-9.-]{1,253}$`)

func (e *Engine) Start(r Request) error {
	if !hostPattern.MatchString(r.Host) || r.Port < 1 || r.Port > 65535 {
		return errors.New("Check the destination address and port.")
	}
	e.mu.Lock()
	if e.listener != nil || e.state == "starting" {
		e.mu.Unlock()
		return errors.New("Stop the current game proxy first.")
	}
	if e.source == nil && !e.offlineTest {
		e.mu.Unlock()
		return errors.New("Sign in with Microsoft for the experimental game proxy. There is no linking fee.")
	}
	e.generation++
	generation := e.generation
	e.state = "starting"
	source, offline := e.source, e.offlineTest
	e.mu.Unlock()
	failed := func(err error) error {
		e.mu.Lock()
		defer e.mu.Unlock()
		if generation == e.generation {
			e.state = "stopped"
		}
		return err
	}
	listen := "127.0.0.1:0"
	if r.LAN {
		listen = "0.0.0.0:19132"
	}
	cfg := minecraft.ListenConfig{HTTPClient: &http.Client{Timeout: 15 * time.Second}, AuthenticationDisabled: offline, MaximumPlayers: 1, StatusProvider: minecraft.NewStatusProvider("LUNARVOID", "Emote menu · "+protocol.CurrentVersion), Allow: func(addr net.Addr, _ login.IdentityData, _ login.ClientData) (string, bool) {
		ip := addr.(*net.UDPAddr).IP
		return "Local Wi-Fi clients only", ip.IsLoopback() || ip.IsPrivate() || ip.IsLinkLocalUnicast()
	}}
	listener, err := cfg.Listen("raknet", listen)
	if err != nil {
		return failed(errors.New("Could not open the game proxy. Check Wi-Fi, port 19132 and your connection."))
	}
	if r.Port == listener.Addr().(*net.UDPAddr).Port {
		addresses, _ := net.LookupIP(r.Host)
		for _, ip := range addresses {
			if ip.IsLoopback() || isLocalIP(ip) {
				listener.Close()
				return failed(errors.New("The destination cannot be this proxy's own address and port."))
			}
		}
	}
	e.mu.Lock()
	defer e.mu.Unlock()
	if generation != e.generation {
		listener.Close()
		return errors.New("Game proxy start was cancelled.")
	}
	ctx, cancel := context.WithCancel(context.Background())
	e.cancel = cancel
	e.listener = listener
	e.port = listener.Addr().(*net.UDPAddr).Port
	e.lan = r.LAN
	e.state = "listening"
	e.problem = ""
	e.emotes = 0
	go func() {
		for {
			conn, err := listener.Accept()
			if err != nil {
				return
			}
			go e.handle(ctx, conn.(*minecraft.Conn), listener, r, source, generation, offline)
		}
	}()
	return nil
}
func (e *Engine) Stop() {
	e.mu.Lock()
	e.generation++
	if e.cancel != nil {
		e.cancel()
	}
	listener, client, up := e.listener, e.client, e.upstream
	e.listener = nil
	e.client = nil
	e.upstream = nil
	e.port = 0
	e.state = "stopped"
	e.problem = ""
	e.mu.Unlock()
	if listener != nil {
		_ = listener.Close()
	}
	if client != nil {
		_ = client.Close()
	}
	if up != nil {
		_ = up.Close()
	}
}
func (e *Engine) handle(ctx context.Context, client *minecraft.Conn, listener *minecraft.Listener, r Request, source oauth2.TokenSource, generation uint64, offline bool) {
	e.mu.Lock()
	if generation != e.generation || e.client != nil {
		e.mu.Unlock()
		_ = listener.Disconnect(client, "Only one player can use this proxy.")
		return
	}
	e.client = client
	e.state = "connecting"
	e.mu.Unlock()
	var up *minecraft.Conn
	defer func() {
		_ = client.Close()
		if up != nil {
			_ = up.Close()
		}
		e.mu.Lock()
		if generation == e.generation {
			e.client = nil
			e.upstream = nil
			e.state = "listening"
		}
		e.mu.Unlock()
	}()
	fail := func(message string) {
		_ = listener.Disconnect(client, message)
		e.mu.Lock()
		if generation == e.generation {
			e.problem = message
		}
		e.mu.Unlock()
	}
	dialCtx, cancel := context.WithTimeout(ctx, 90*time.Second)
	defer cancel()
	dialer := minecraft.Dialer{HTTPClient: &http.Client{Timeout: 25 * time.Second}, TokenSource: source, ClientData: client.ClientData(), KeepXBLIdentityData: true}
	if offline {
		dialer.IdentityData = client.IdentityData()
	}
	var err error
	up, err = dialer.DialContext(dialCtx, "raknet", net.JoinHostPort(r.Host, fmt.Sprint(r.Port)))
	if err != nil {
		fail("Could not sign in to the destination. Check the server, game version and Microsoft session.")
		return
	}
	if len(up.ResourcePacks()) > 0 {
		fail("Servers requiring resource packs are not supported in experimental game mode yet.")
		return
	}
	if !offline && !sameOwner(client.IdentityData().XUID, up.IdentityData().XUID) {
		fail("Use the same Microsoft account in Minecraft and LUNARVOID.")
		return
	}
	e.mu.Lock()
	if generation != e.generation {
		e.mu.Unlock()
		return
	}
	e.upstream = up
	e.mu.Unlock()
	done := make(chan error, 2)
	go func() { done <- client.StartGameContext(dialCtx, up.GameData()) }()
	go func() { done <- up.DoSpawnContext(dialCtx) }()
	for range 2 {
		if <-done != nil {
			fail("Could not enter the destination world. Check both game versions.")
			return
		}
	}
	e.mu.Lock()
	if generation != e.generation {
		e.mu.Unlock()
		return
	}
	e.state = "connected"
	e.problem = ""
	e.mu.Unlock()
	menu := newMenu(client.WritePacket, func() string { e.mu.Lock(); defer e.mu.Unlock(); return e.nickname }, func(n string) { e.mu.Lock(); e.nickname = n; e.mu.Unlock() }, func() { e.mu.Lock(); e.emotes++; e.mu.Unlock() }, client.GameData().EntityRuntimeID)
	defer menu.Close()
	go func() {
		defer client.Close()
		defer up.Close()
		for {
			pk, err := up.ReadPacket()
			if err != nil {
				return
			}
			menu.Server(pk)
			if client.WritePacket(pk) != nil {
				return
			}
		}
	}()
	for {
		pk, err := client.ReadPacket()
		if err != nil {
			return
		}
		consumed, err := menu.Client(pk)
		if err != nil {
			return
		}
		if !consumed && up.WritePacket(pk) != nil {
			return
		}
	}
}

func isLocalIP(ip net.IP) bool {
	addresses, _ := net.InterfaceAddrs()
	for _, addr := range addresses {
		if block, ok := addr.(*net.IPNet); ok && block.IP.Equal(ip) {
			return true
		}
	}
	return false
}

func sameOwner(client, upstream string) bool {
	return client != "" && upstream != "" && client == upstream
}

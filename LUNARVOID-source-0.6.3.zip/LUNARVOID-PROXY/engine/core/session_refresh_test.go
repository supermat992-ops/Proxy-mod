package core

import (
	"context"
	"golang.org/x/oauth2"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

type tokenTransport func(*http.Request) (*http.Response, error)

func (f tokenTransport) RoundTrip(r *http.Request) (*http.Response, error) { return f(r) }
func TestRefreshRotationAndRevocationPersist(t *testing.T) {
	original := http.DefaultTransport
	defer func() { http.DefaultTransport = original }()
	path := filepath.Join(t.TempDir(), "session.bin")
	e := New()
	e.ConfigureEncryptedStore(path, make([]byte, 32))
	s := &liveSource{ctx: context.Background(), token: &oauth2.Token{AccessToken: "old-fixture", RefreshToken: "refresh-fixture", Expiry: time.Now().Add(-time.Hour)}, save: e.saveSession}
	http.DefaultTransport = tokenTransport(func(r *http.Request) (*http.Response, error) {
		r.ParseForm()
		if r.Form.Get("grant_type") != "refresh_token" || r.Form.Get("refresh_token") != "refresh-fixture" {
			t.Error("wrong refresh request")
		}
		return &http.Response{StatusCode: 200, Body: io.NopCloser(strings.NewReader(`{"access_token":"new-fixture","refresh_token":"rotated-fixture","expires_in":3600}`)), Header: make(http.Header)}, nil
	})
	if _, err := s.Token(); err != nil {
		t.Fatal(err)
	}
	restored := New()
	restored.ConfigureEncryptedStore(path, make([]byte, 32))
	if restored.source.(*liveSource).token.RefreshToken != "rotated-fixture" {
		t.Fatal("provider rotation not saved")
	}
	s.token.Expiry = time.Now().Add(-time.Hour)
	http.DefaultTransport = tokenTransport(func(r *http.Request) (*http.Response, error) {
		return &http.Response{StatusCode: 400, Body: io.NopCloser(strings.NewReader(`{"error":"invalid_grant"}`)), Header: make(http.Header)}, nil
	})
	if _, err := s.Token(); err == nil || !s.revoked {
		t.Fatal("revoked token still accepted")
	}
	if _, err := os.Stat(path); !os.IsNotExist(err) {
		t.Fatal("revoked saved token retained", err)
	}
}

//go:build windows

package core

import (
	"golang.org/x/sys/windows"
	"os"
	"path/filepath"
	"unsafe"
)

func protectWindows(b []byte, decrypt bool) ([]byte, error) {
	var input, output windows.DataBlob
	input.Size = uint32(len(b))
	if len(b) > 0 {
		input.Data = &b[0]
	}
	var err error
	if decrypt {
		err = windows.CryptUnprotectData(&input, nil, nil, 0, nil, windows.CRYPTPROTECT_UI_FORBIDDEN, &output)
	} else {
		err = windows.CryptProtectData(&input, nil, nil, 0, nil, windows.CRYPTPROTECT_UI_FORBIDDEN, &output)
	}
	if err != nil {
		return nil, err
	}
	defer windows.LocalFree(windows.Handle(unsafe.Pointer(output.Data)))
	return append([]byte(nil), unsafe.Slice(output.Data, int(output.Size))...), nil
}
func platformStore() sessionStore {
	dir, err := os.UserConfigDir()
	if err != nil {
		return nil
	}
	return &protectedFile{path: filepath.Join(dir, "LUNARVOID", "session.bin"), seal: func(b []byte) ([]byte, error) { return protectWindows(b, false) }, open: func(b []byte) ([]byte, error) { return protectWindows(b, true) }}
}

//go:build !windows

package core

func platformStore() sessionStore { return nil }

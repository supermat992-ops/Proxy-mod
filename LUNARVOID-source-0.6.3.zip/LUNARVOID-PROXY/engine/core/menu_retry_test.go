package core

import (
	"github.com/sandertv/gophertunnel/minecraft/protocol"
	"github.com/sandertv/gophertunnel/minecraft/protocol/packet"
	"testing"
	"time"
)

func TestBusyEmoteMenuRetriesButUserCloseDoesNot(t *testing.T) {
	sent := make(chan *packet.ModalFormRequest, 5)
	m := newMenu(func(p packet.Packet) error { sent <- p.(*packet.ModalFormRequest); return nil }, func() string { return "" }, func(string) {}, func() {}, 9)
	defer m.Close()
	m.retryDelay = 5 * time.Millisecond
	m.Client(&packet.Emote{EntityRuntimeID: 9})
	form := <-sent
	for range 3 {
		consumed, err := m.Client(&packet.ModalFormResponse{FormID: form.FormID, CancelReason: protocol.Option(uint8(packet.ModalFormCancelReasonUserBusy))})
		if !consumed || err != nil {
			t.Fatal(err)
		}
		select {
		case form = <-sent:
		case <-time.After(time.Second):
			t.Fatal("busy form not retried")
		}
	}
	m.Client(&packet.ModalFormResponse{FormID: form.FormID, CancelReason: protocol.Option(uint8(packet.ModalFormCancelReasonUserBusy))})
	select {
	case <-sent:
		t.Fatal("unbounded retry")
	case <-time.After(30 * time.Millisecond):
	}
	m.Client(&packet.CommandRequest{CommandLine: "/.menu"})
	form = <-sent
	m.Client(&packet.ModalFormResponse{FormID: form.FormID, CancelReason: protocol.Option(uint8(packet.ModalFormCancelReasonUserClosed))})
	select {
	case <-sent:
		t.Fatal("reopened after intentional close")
	case <-time.After(30 * time.Millisecond):
	}
}

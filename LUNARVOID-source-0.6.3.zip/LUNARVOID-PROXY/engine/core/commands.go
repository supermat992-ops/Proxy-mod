package core

import (
	"github.com/sandertv/gophertunnel/minecraft/protocol/packet"
	"strings"
)

var moduleCommands = map[string]string{
	"afkclicker":     "AutoClicker / AFKClicker",
	"anticrystal":    "AntiCrystal",
	"antivanish":     "AntiVanish",
	"armorhud":       "ArmorHUD / InventoryHUD",
	"arraylist":      "ArrayList",
	"autoarmor":      "AutoArmor",
	"autocart":       "AutoCart",
	"autoclicker":    "AutoClicker / AFKClicker",
	"autocrit":       "AutoCrit",
	"autocrystal":    "AutoCrystal",
	"autoeat":        "AutoEat",
	"autojumpreset":  "AutoJumpReset",
	"automine":       "AutoMine",
	"autopotion":     "AutoPotion",
	"autoswitch":     "AutoSwitch",
	"autototem":      "AutoTotem",
	"autoweb":        "AutoWeb",
	"backtrack":      "Backtrack",
	"blocktracers":   "Tracers / BlockTracers",
	"chunkfinder":    "ChunkFinder",
	"doubleclick":    "DoubleClick",
	"fakerain":       "FakeRain",
	"fastbreak":      "FastBreak",
	"fastplace":      "FastPlace",
	"fly":            "Fly",
	"freecam":        "FreeCam",
	"freelook":       "FreeLook",
	"hitbox":         "HitBox",
	"holeesp":        "HoleESP",
	"inventoryhud":   "ArmorHUD / InventoryHUD",
	"jesus":          "Jesus",
	"killaura":       "KillAura",
	"knockback":      "Knockback",
	"knockbackdelay": "Knockback Delay",
	"maceswap":       "MaceSwap",
	"nofall":         "NoFall",
	"nuke":           "Nuke",
	"playeroutline":  "Player Outline",
	"reach":          "Reach",
	"scaffold":       "Scaffold",
	"schematic":      "Schematic",
	"speed":          "Speed",
	"spider":         "Spider",
	"targethud":      "TargetHUD",
	"tpaura":         "TPAura",
	"tracers":        "Tracers / BlockTracers",
	"triggerbot":     "TriggerBot",
	"xray":           "Xray",
}

// Local shortcuts report availability rather than enabling placeholders.
func (m *menu) command(line string) (bool, error) {
	line = strings.TrimSpace(line)
	if !strings.HasPrefix(line, "/.") {
		return false, nil
	}
	fields := strings.Fields(strings.TrimPrefix(line, "/."))
	if len(fields) == 0 || len(line) > 256 {
		return true, m.message("Use /.menu to open LUNARVOID, or /.help for commands.")
	}
	name := strings.ToLower(fields[0])
	if name == "menu" {
		if m.retryTimer != nil {
			m.retryTimer.Stop()
		}
		m.retryCount = 0
		if len(m.retired)+len(m.pending) > 1024 {
			return true, m.message("Too many unanswered menus. Reconnect to reset the menu session.")
		}
		for id := range m.pending {
			m.retired[id] = true
		}
		m.pending = map[uint32]string{}
		return true, m.home()
	}
	if name == "help" {
		return true, m.message("/.menu opens LUNARVOID. Module shortcuts such as /.xray, /.fly and /.automine report availability. Gameplay modules are not implemented in this build.")
	}
	if module, ok := moduleCommands[name]; ok {
		return true, m.message(module + ": Unavailable. This build does not implement this gameplay module. Preview its preferences in the app.")
	}
	return true, m.message("Unknown LUNARVOID command. Use /.menu or /.help.")
}
func (m *menu) message(text string) error {
	return m.write(&packet.Text{TextType: packet.TextTypeRaw, Message: "§bLUNARVOID §r" + text})
}

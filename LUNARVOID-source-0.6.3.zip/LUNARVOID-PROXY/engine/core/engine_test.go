package core

import (
	"context"
	"encoding/json"
	"fmt"
	"github.com/sandertv/gophertunnel/minecraft"
	"github.com/sandertv/gophertunnel/minecraft/protocol"
	"github.com/sandertv/gophertunnel/minecraft/protocol/packet"
	"net"
	"testing"
	"time"
)

func TestEngineEncryptedLoopbackEmoteAndStop(t *testing.T) {
	ctx, cancel := context.WithTimeout(context.Background(), 20*time.Second)
	defer cancel()
	upstream, err := (minecraft.ListenConfig{AuthenticationDisabled: true}).Listen("raknet", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	defer upstream.Close()
	received := make(chan packet.Packet, 16)
	go func() {
		c, err := upstream.Accept()
		if err != nil {
			return
		}
		conn := c.(*minecraft.Conn)
		defer conn.Close()
		if conn.StartGameContext(ctx, minecraft.GameData{EntityRuntimeID: 42, EntityUniqueID: 42, WorldName: "Synthetic fixture"}) != nil {
			return
		}
		for {
			pk, err := conn.ReadPacket()
			if err != nil {
				return
			}
			received <- pk
			if emote, ok := pk.(*packet.Emote); ok {
				conn.WritePacket(&packet.Text{TextType: packet.TextTypeRaw, Message: "emote-forwarded:" + emote.EmoteID})
			}
		}
	}()
	engine := New()
	engine.offlineTest = true
	defer engine.Stop()
	if err := engine.Start(Request{Host: "127.0.0.1", Port: upstream.Addr().(*net.UDPAddr).Port}); err != nil {
		t.Fatal(err)
	}
	var status struct{ Port int }
	json.Unmarshal([]byte(engine.Status()), &status)
	conn, err := (minecraft.Dialer{}).DialContext(ctx, "raknet", fmt.Sprintf("127.0.0.1:%d", status.Port))
	if err != nil {
		t.Fatal(err)
	}
	defer conn.Close()
	if err := conn.DoSpawnContext(ctx); err != nil {
		t.Fatal(err)
	}
	conn.SetReadDeadline(time.Now().Add(5 * time.Second))
	if err := conn.WritePacket(&packet.Emote{EntityRuntimeID: 42, EmoteID: "fixture-emote"}); err != nil {
		t.Fatal(err)
	}
	sawForm, sawEcho := false, false
	for !sawForm || !sawEcho {
		pk, err := conn.ReadPacket()
		if err != nil {
			t.Fatal("expected encrypted form+forwarded animation", err)
		}
		switch p := pk.(type) {
		case *packet.ModalFormRequest:
			sawForm = true
			conn.WritePacket(&packet.ModalFormResponse{FormID: p.FormID, ResponseData: protocol.Option([]byte("null"))})
		case *packet.Text:
			if p.Message == "emote-forwarded:fixture-emote" {
				sawEcho = true
			}
		}
	}
	engine.Stop()
	deadline := time.After(200 * time.Millisecond)
	for {
		select {
		case pk := <-received:
			if _, ok := pk.(*packet.ModalFormResponse); ok {
				t.Fatal("proxy form leaked to upstream")
			}
		case <-deadline:
			goto done
		}
	}
done:
	sock, err := net.ListenPacket("udp", fmt.Sprintf("127.0.0.1:%d", status.Port))
	if err != nil {
		t.Fatal("listener not released", err)
	}
	sock.Close()
}
func TestUnauthenticatedStartRejectedAndStatusHasNoSecrets(t *testing.T) {
	e := New()
	defer e.Stop()
	if err := e.Start(Request{Host: "example.org", Port: 19132}); err == nil {
		t.Fatal("unauthenticated start accepted")
	}
	var status map[string]any
	if json.Unmarshal([]byte(e.Status()), &status) != nil {
		t.Fatal("invalid status")
	}
	if status["signedIn"] != false || status["protocol"] != float64(protocol.CurrentProtocol) {
		t.Fatal(status)
	}
	for _, key := range []string{"token", "access_token", "refresh_token"} {
		if _, ok := status[key]; ok {
			t.Fatal("secret exposed")
		}
	}
	if err := e.Start(Request{Host: "http://bad", Port: 19132}); err == nil {
		t.Fatal("invalid host accepted")
	}
}

func TestOwnerCheckRejectsEmptyAndDifferentIdentities(t *testing.T) {
	for _, pair := range [][2]string{{"", ""}, {"owner", ""}, {"", "owner"}, {"neighbor", "owner"}} {
		if sameOwner(pair[0], pair[1]) {
			t.Fatal("accepted a different/unauthenticated local player")
		}
	}
	if !sameOwner("owner", "owner") {
		t.Fatal("rejected authenticated owner")
	}
}

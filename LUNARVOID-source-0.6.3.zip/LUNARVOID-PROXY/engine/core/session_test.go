package core

import (
	"context"
	"golang.org/x/oauth2"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func TestEncryptedSessionRestoreRotateAndSignOut(t *testing.T) {
	path := filepath.Join(t.TempDir(), "session.bin")
	key := make([]byte, 32)
	e := New()
	if err := e.ConfigureEncryptedStore(path, key); err != nil {
		t.Fatal(err)
	}
	token := &oauth2.Token{AccessToken: "synthetic-access", RefreshToken: "synthetic-refresh", Expiry: time.Now().Add(time.Hour)}
	s := &liveSource{ctx: context.Background(), token: token, save: e.saveSession}
	s.persist()
	if s.persistenceError != "" {
		t.Fatal(s.persistenceError)
	}
	data, err := os.ReadFile(path)
	if err != nil || strings.Contains(string(data), "synthetic") {
		t.Fatal("session not protected", err)
	}
	restored := New()
	if err := restored.ConfigureEncryptedStore(path, key); err != nil {
		t.Fatal(err)
	}
	if !strings.Contains(restored.Status(), `"signedIn":true`) || strings.Contains(restored.Status(), "synthetic") {
		t.Fatal("restore/status")
	}
	src := restored.source.(*liveSource)
	src.token.RefreshToken = "rotated-synthetic"
	src.persist()
	restored.Call(`{"action":"suspend"}`)
	next := New()
	next.ConfigureEncryptedStore(path, key)
	if next.source.(*liveSource).token.RefreshToken != "rotated-synthetic" {
		t.Fatal("rotation not persisted")
	}
	next.Call(`{"action":"signout"}`)
	if _, err := os.Stat(path); !os.IsNotExist(err) {
		t.Fatal("signout retained token", err)
	}
	if _, err := src.Token(); err == nil {
		t.Fatal("suspended source still usable")
	}
}
func TestCorruptSavedSessionNeverSignsIn(t *testing.T) {
	path := filepath.Join(t.TempDir(), "session.bin")
	os.WriteFile(path, []byte("broken"), 0600)
	e := New()
	e.ConfigureEncryptedStore(path, make([]byte, 32))
	if e.source != nil || !strings.Contains(e.Status(), "could not be restored") {
		t.Fatal("corrupt storage accepted")
	}
	e.Call(`{"action":"signout"}`)
	if _, err := os.Stat(path); !os.IsNotExist(err) {
		t.Fatal("corrupt session not removed")
	}
}

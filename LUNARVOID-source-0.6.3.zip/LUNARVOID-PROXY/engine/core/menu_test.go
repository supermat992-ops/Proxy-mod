package core

import (
	"encoding/json"
	"github.com/sandertv/gophertunnel/minecraft/protocol"
	"github.com/sandertv/gophertunnel/minecraft/protocol/packet"
	"strings"
	"testing"
	"time"
)

func TestEmoteMenuProfileAndIsolation(t *testing.T) {
	var sent []*packet.ModalFormRequest
	name := ""
	events := 0
	m := newMenu(func(pk packet.Packet) error { sent = append(sent, pk.(*packet.ModalFormRequest)); return nil }, func() string { return name }, func(n string) { name = n }, func() { events++ }, 42)
	consumed, err := m.Client(&packet.Emote{EntityRuntimeID: 42, EmoteID: "synthetic-emote"})
	if err != nil || consumed || len(sent) != 1 {
		t.Fatal("emote not forwarded/menu absent", consumed, err, len(sent))
	}
	if !strings.Contains(string(sent[0].FormData), "Profile") {
		t.Fatal("missing profile")
	}
	m.Client(&packet.Emote{EntityRuntimeID: 42})
	if len(sent) != 1 {
		t.Fatal("duplicate menu")
	}
	m.Client(&packet.Emote{EntityRuntimeID: 999})
	if events != 2 {
		t.Fatal("foreign entity opened menu")
	}
	response := func(id uint32, data string) bool {
		ok, err := m.Client(&packet.ModalFormResponse{FormID: id, ResponseData: protocol.Option([]byte(data))})
		if err != nil {
			t.Fatal(err)
		}
		return ok
	}
	if !response(sent[0].FormID, "0") || len(sent) != 2 {
		t.Fatal("profile not opened")
	}
	if !response(sent[1].FormID, `[null,"Test Player"]`) || name != "Test Player" {
		t.Fatal("nickname not saved")
	}
	if response(1234, "0") {
		t.Fatal("ate destination form")
	}
	current := sent[len(sent)-1].FormID
	m.Server(&packet.ModalFormRequest{FormID: current, FormData: []byte(`{}`)})
	if response(current, "1") {
		t.Fatal("destination collision consumed")
	}
	if _, ok := cleanNickname("§cBad\nName"); ok {
		t.Fatal("accepted format/control characters")
	}
	if _, ok := cleanNickname(strings.Repeat("a", 33)); ok {
		t.Fatal("accepted long nickname")
	}
}
func TestMenuMalformedCancelAndSettings(t *testing.T) {
	var sent []*packet.ModalFormRequest
	m := newMenu(func(pk packet.Packet) error { sent = append(sent, pk.(*packet.ModalFormRequest)); return nil }, func() string { return "" }, func(string) { t.Fatal("malformed profile saved") }, func() {}, 7)
	m.Client(&packet.Emote{EntityRuntimeID: 7})
	m.Client(&packet.ModalFormResponse{FormID: sent[0].FormID, ResponseData: protocol.Option([]byte("1"))})
	m.Client(&packet.ModalFormResponse{FormID: sent[1].FormID, ResponseData: protocol.Option([]byte(`[null,5]`))})
	if m.cooldown != 5*time.Second {
		t.Fatal("cooldown not applied")
	}
	last := sent[len(sent)-1].FormID
	consumed, err := m.Client(&packet.ModalFormResponse{FormID: last, ResponseData: protocol.Option([]byte("null"))})
	if !consumed || err != nil || len(m.pending) != 0 {
		t.Fatal("cancel not consumed")
	}
	m.last = time.Time{}
	m.Client(&packet.Emote{EntityRuntimeID: 7})
	consumed, err = m.Client(&packet.ModalFormResponse{FormID: sent[len(sent)-1].FormID, ResponseData: protocol.Option([]byte(`{bad`))})
	if !consumed || err != nil {
		t.Fatal("malformed response")
	}
	for _, pk := range sent {
		var body map[string]any
		if json.Unmarshal(pk.FormData, &body) != nil {
			t.Fatal("invalid form JSON")
		}
	}
}

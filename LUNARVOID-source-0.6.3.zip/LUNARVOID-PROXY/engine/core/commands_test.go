package core

import (
	"github.com/sandertv/gophertunnel/minecraft/protocol/packet"
	"strings"
	"testing"
)

func TestLocalCommandsAreConsumedAndServerCommandsForward(t *testing.T) {
	var sent []packet.Packet
	m := newMenu(func(p packet.Packet) error { sent = append(sent, p); return nil }, func() string { return "" }, func(string) {}, func() {}, 1)
	for _, p := range []packet.Packet{&packet.CommandRequest{CommandLine: "/spawn"}, &packet.Text{TextType: packet.TextTypeChat, Message: "hello"}} {
		consumed, err := m.Client(p)
		if consumed || err != nil {
			t.Fatal("intercepted server traffic", err)
		}
	}
	for alias := range moduleCommands {
		consumed, err := m.Client(&packet.CommandRequest{CommandLine: "/." + alias + " on"})
		if !consumed || err != nil {
			t.Fatal(alias, err)
		}
		msg, ok := sent[len(sent)-1].(*packet.Text)
		if !ok || !strings.Contains(msg.Message, "Unavailable") {
			t.Fatal("false module activation", alias)
		}
	}
	for _, command := range []string{"/.help", "/.unknown", "/."} {
		consumed, err := m.Client(&packet.Text{TextType: packet.TextTypeChat, Message: command})
		if !consumed || err != nil {
			t.Fatal(command, err)
		}
	}
	var oldID uint32
	for i := 0; i < 2; i++ {
		consumed, err := m.Client(&packet.CommandRequest{CommandLine: "/.menu"})
		if !consumed || err != nil {
			t.Fatal("menu command", err)
		}
		if _, ok := sent[len(sent)-1].(*packet.ModalFormRequest); !ok {
			t.Fatal("missing menu")
		}
		if i == 0 {
			oldID = sent[len(sent)-1].(*packet.ModalFormRequest).FormID
		}
		if len(m.pending) != 1 {
			t.Fatal("pending forms grow unbounded")
		}
	}
	consumed, err := m.Client(&packet.ModalFormResponse{FormID: oldID})
	if !consumed || err != nil {
		t.Fatal("stale local form leaked upstream", err)
	}
}

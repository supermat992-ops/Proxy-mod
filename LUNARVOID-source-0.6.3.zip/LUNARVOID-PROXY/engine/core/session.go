package core

import (
	"context"
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"encoding/json"
	"errors"
	"golang.org/x/oauth2"
	"os"
	"path/filepath"
)

type sessionStore interface {
	Read() ([]byte, error)
	Write([]byte) error
	Delete() error
}
type protectedFile struct {
	path       string
	seal, open func([]byte) ([]byte, error)
}

func (s *protectedFile) Read() ([]byte, error) {
	b, e := os.ReadFile(s.path)
	if e != nil {
		return nil, e
	}
	if len(b) > 65536 {
		return nil, errors.New("invalid session")
	}
	return s.open(b)
}
func (s *protectedFile) Write(b []byte) error {
	b, e := s.seal(b)
	if e != nil {
		return e
	}
	if e = os.MkdirAll(filepath.Dir(s.path), 0700); e != nil {
		return e
	}
	f, e := os.CreateTemp(filepath.Dir(s.path), ".session-*")
	if e != nil {
		return e
	}
	defer os.Remove(f.Name())
	if e = f.Chmod(0600); e == nil {
		_, e = f.Write(b)
	}
	if e == nil {
		e = f.Sync()
	}
	closeErr := f.Close()
	if e != nil {
		return e
	}
	if closeErr != nil {
		return closeErr
	}
	return os.Rename(f.Name(), s.path)
}
func (s *protectedFile) Delete() error {
	e := os.Remove(s.path)
	if os.IsNotExist(e) {
		return nil
	}
	return e
}

// ConfigureEncryptedStore is called only through a private native entry point.
// The key is wrapped by Android Keystore, never exposed to JavaScript or status.
func (e *Engine) ConfigureEncryptedStore(path string, key []byte) error {
	if !filepath.IsAbs(path) || len(key) != 32 {
		return errors.New("invalid store configuration")
	}
	block, err := aes.NewCipher(key)
	if err != nil {
		return err
	}
	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return err
	}
	e.configureStore(&protectedFile{path: path, seal: func(b []byte) ([]byte, error) {
		n := make([]byte, gcm.NonceSize())
		if _, err := rand.Read(n); err != nil {
			return nil, err
		}
		return gcm.Seal(n, n, b, nil), nil
	}, open: func(b []byte) ([]byte, error) {
		if len(b) < gcm.NonceSize() {
			return nil, errors.New("invalid session")
		}
		return gcm.Open(nil, b[:gcm.NonceSize()], b[gcm.NonceSize():], nil)
	}})
	return nil
}
func (e *Engine) saveSession(t *oauth2.Token) error {
	if e.store == nil {
		return errors.New("protected storage unavailable")
	}
	if t == nil {
		return e.store.Delete()
	}
	b, err := json.Marshal(t)
	if err != nil {
		return err
	}
	return e.store.Write(b)
}
func (e *Engine) configureStore(store sessionStore) {
	e.mu.Lock()
	defer e.mu.Unlock()
	if e.tokenCancel != nil {
		e.tokenCancel()
	}
	if source, ok := e.source.(*liveSource); ok {
		source.mu.Lock()
		source.revoked = true
		source.mu.Unlock()
	}
	e.source = nil
	e.authState = "idle"
	e.store = store
	if store == nil {
		return
	}
	raw, err := store.Read()
	if os.IsNotExist(err) {
		return
	}
	var token oauth2.Token
	if err != nil || json.Unmarshal(raw, &token) != nil || token.RefreshToken == "" {
		e.authError = "Saved sign-in could not be restored. Sign in again."
		return
	}
	ctx, cancel := context.WithCancel(context.Background())
	e.tokenCancel = cancel
	e.source = &liveSource{ctx: ctx, token: &token, save: e.saveSession}
	e.authState = "ready"
}
func (e *Engine) clearSession(remove bool) {
	e.Stop()
	e.mu.Lock()
	defer e.mu.Unlock()
	e.authGeneration++
	if e.authCancel != nil {
		e.authCancel()
	}
	if e.tokenCancel != nil {
		e.tokenCancel()
	}
	if source, ok := e.source.(*liveSource); ok {
		source.mu.Lock()
		source.revoked = true
		source.mu.Unlock()
	}
	e.source = nil
	e.authState = "idle"
	e.authCode = ""
	e.authURL = ""
	e.authError = ""
	if remove && e.store != nil {
		if e.store.Delete() != nil {
			e.authError = "Signed out, but saved sign-in could not be deleted. Clear the app data before sharing this device."
		}
	}
}

package core

import (
	"crypto/rand"
	"encoding/binary"
	"encoding/json"
	"github.com/sandertv/gophertunnel/minecraft/protocol/packet"
	"strings"
	"sync"
	"time"
	"unicode/utf8"
)

type menu struct {
	retryTimer *time.Timer
	retryCount int
	retryDelay time.Duration
	closed     bool
	mu         sync.Mutex
	write      func(packet.Packet) error
	nickname   func() string
	save       func(string)
	emote      func()
	owner      uint64
	pending    map[uint32]string
	retired    map[uint32]bool
	serverIDs  map[uint32]bool
	last       time.Time
	cooldown   time.Duration
}

func newMenu(w func(packet.Packet) error, n func() string, s func(string), e func(), owner uint64) *menu {
	return &menu{write: w, nickname: n, save: s, emote: e, owner: owner, pending: map[uint32]string{}, retired: map[uint32]bool{}, serverIDs: map[uint32]bool{}, retryDelay: 750 * time.Millisecond, cooldown: 2 * time.Second}
}
func (m *menu) Server(pk packet.Packet) {
	m.mu.Lock()
	defer m.mu.Unlock()
	if p, ok := pk.(*packet.ModalFormRequest); ok {
		if len(m.serverIDs) > 1024 {
			m.serverIDs = map[uint32]bool{}
		}
		m.serverIDs[p.FormID] = true
		delete(m.pending, p.FormID)
		delete(m.retired, p.FormID)
	}
}
func (m *menu) send(kind string, body any) error {
	var bytes [4]byte
	for {
		if _, err := rand.Read(bytes[:]); err != nil {
			return err
		}
		id := binary.LittleEndian.Uint32(bytes[:])
		if m.serverIDs[id] || m.retired[id] || m.pending[id] != "" {
			continue
		}
		data, err := json.Marshal(body)
		if err != nil {
			return err
		}
		m.pending[id] = kind
		if err = m.write(&packet.ModalFormRequest{FormID: id, FormData: data}); err != nil {
			delete(m.pending, id)
			return err
		}
		return nil
	}
}
func (m *menu) home() error {
	return m.send("home", map[string]any{"type": "form", "title": "§bLUNARVOID", "content": "Profile, settings and HUD. Gameplay modules remain unavailable.", "buttons": []any{map[string]string{"text": "§bProfile"}, map[string]string{"text": "Settings"}, map[string]string{"text": "Edit HUD"}}})
}
func (m *menu) Client(pk packet.Packet) (bool, error) {
	m.mu.Lock()
	defer m.mu.Unlock()
	switch p := pk.(type) {
	case *packet.CommandRequest:
		return m.command(p.CommandLine)
	case *packet.Text:
		if p.TextType == packet.TextTypeChat {
			return m.command(p.Message)
		}

	case *packet.Emote:
		if p.EntityRuntimeID != m.owner {
			return false, nil
		}
		m.emote()
		if time.Since(m.last) < m.cooldown || len(m.pending) > 0 {
			return false, nil
		}
		m.retryCount = 0
		m.last = time.Now()
		return false, m.home()
	case *packet.ModalFormResponse:
		if m.retired[p.FormID] {
			delete(m.retired, p.FormID)
			return true, nil
		}
		kind, ours := m.pending[p.FormID]
		if !ours {
			return false, nil
		}
		delete(m.pending, p.FormID)
		if reason, ok := p.CancelReason.Value(); ok && reason == packet.ModalFormCancelReasonUserBusy && kind == "home" && m.retryCount < 3 {
			m.retryCount++
			if m.retryTimer != nil {
				m.retryTimer.Stop()
			}
			m.retryTimer = time.AfterFunc(m.retryDelay, func() {
				m.mu.Lock()
				defer m.mu.Unlock()
				if !m.closed && len(m.pending) == 0 {
					_ = m.home()
				}
			})
			return true, nil
		}
		raw, ok := p.ResponseData.Value()
		if !ok || len(raw) > 2048 || string(raw) == "null" {
			return true, nil
		}
		switch kind {
		case "home":
			var choice int
			if json.Unmarshal(raw, &choice) != nil {
				return true, nil
			}
			switch choice {
			case 0:
				return true, m.send("profile", map[string]any{"type": "custom_form", "title": "§bLUNARVOID · Profile", "content": []any{map[string]string{"type": "label", "text": "Nickname is a local LUNARVOID preference. Servers control your public name."}, map[string]string{"type": "input", "text": "Nickname (up to 32 characters)", "default": m.nickname()}}})
			case 1:
				return true, m.send("settings", map[string]any{"type": "custom_form", "title": "§bLUNARVOID · Settings", "content": []any{map[string]string{"type": "label", "text": "Play an emote to open this menu. Reconnect to reset session settings."}, map[string]any{"type": "slider", "text": "Menu cooldown (seconds)", "min": 1, "max": 10, "step": 1, "default": m.cooldown.Seconds()}}})
			case 2:
				return true, m.send("hud", map[string]any{"type": "form", "title": "§bLUNARVOID · Edit HUD", "content": "HUD editing and replay recording are not implemented. This menu uses Minecraft forms; the custom blue overlay is not included.", "buttons": []any{map[string]string{"text": "Back"}}})
			}
		case "profile":
			var values []json.RawMessage
			if json.Unmarshal(raw, &values) != nil || len(values) != 2 {
				return true, nil
			}
			var name string
			if json.Unmarshal(values[1], &name) == nil {
				if clean, ok := cleanNickname(name); ok {
					m.save(clean)
				}
			}
			return true, m.home()
		case "settings":
			var values []json.RawMessage
			if json.Unmarshal(raw, &values) != nil || len(values) != 2 {
				return true, nil
			}
			var seconds float64
			if json.Unmarshal(values[1], &seconds) == nil && seconds >= 1 && seconds <= 10 {
				m.cooldown = time.Duration(seconds * float64(time.Second))
			}
			return true, m.home()
		case "hud":
			return true, m.home()
		}
		return true, nil
	}
	return false, nil
}
func cleanNickname(name string) (string, bool) {
	name = strings.TrimSpace(name)
	if !utf8.ValidString(name) || utf8.RuneCountInString(name) > 32 || strings.ContainsAny(name, "\r\n\x00§") {
		return "", false
	}
	for _, r := range name {
		if r < 32 || r == 127 {
			return "", false
		}
	}
	return name, true
}

func (m *menu) Close() {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.closed = true
	if m.retryTimer != nil {
		m.retryTimer.Stop()
	}
}

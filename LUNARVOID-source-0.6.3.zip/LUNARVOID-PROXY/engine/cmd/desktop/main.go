package main

import (
	"bufio"
	"fmt"
	"lunarvoid/engine/core"
	"os"
)

func main() {
	e := core.New()
	defer e.Stop()
	scanner := bufio.NewScanner(os.Stdin)
	scanner.Buffer(make([]byte, 4096), 8192)
	for scanner.Scan() {
		fmt.Println(e.Call(scanner.Text()))
	}
	e.Call(`{"action":"suspend"}`)
}

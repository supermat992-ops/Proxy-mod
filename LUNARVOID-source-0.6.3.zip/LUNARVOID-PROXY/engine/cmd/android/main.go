//go:build android || jnitest

package main

import "lunarvoid/engine/core"

var engine = core.New()

func main() {}

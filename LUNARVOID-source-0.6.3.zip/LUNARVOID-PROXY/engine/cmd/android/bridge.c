#include <jni.h>
#include <string.h>
#if defined(LV_VERSION_50)
#define LVCall LVCall50
#define LVFree LVFree50
#define LVStore LVStore50
#define LV_JNI Java_com_lunarvoid_proxy_GameEngine50_callNative
#define LV_STORE_JNI Java_com_lunarvoid_proxy_GameEngine50_configureNative
#elif defined(LV_VERSION_40)
#define LVCall LVCall40
#define LVFree LVFree40
#define LVStore LVStore40
#define LV_JNI Java_com_lunarvoid_proxy_GameEngine40_callNative
#define LV_STORE_JNI Java_com_lunarvoid_proxy_GameEngine40_configureNative
#else
#define LVCall LVCall30
#define LVFree LVFree30
#define LVStore LVStore30
#define LV_JNI Java_com_lunarvoid_proxy_GameEngine30_callNative
#define LV_STORE_JNI Java_com_lunarvoid_proxy_GameEngine30_configureNative
#endif
extern char *LVCall(char *);
extern void LVFree(char *);
extern int LVStore(char *,char *);
JNIEXPORT jboolean JNICALL LV_STORE_JNI(JNIEnv *env,jclass cls,jstring path,jstring key) {
 if(path==NULL||key==NULL)return JNI_FALSE;
 const char *p=(*env)->GetStringUTFChars(env,path,NULL);if(p==NULL)return JNI_FALSE;
 const char *k=(*env)->GetStringUTFChars(env,key,NULL);if(k==NULL){(*env)->ReleaseStringUTFChars(env,path,p);return JNI_FALSE;}
 int ok=LVStore((char*)p,(char*)k);
 (*env)->ReleaseStringUTFChars(env,path,p);(*env)->ReleaseStringUTFChars(env,key,k);
 return ok?JNI_TRUE:JNI_FALSE;
}
JNIEXPORT jstring JNICALL LV_JNI(JNIEnv *env, jclass cls, jstring raw) {
    if (raw == NULL) return (*env)->NewStringUTF(env, "{\"error\":\"Missing request\"}");
    const char *input = (*env)->GetStringUTFChars(env, raw, NULL);
    if (input == NULL) return NULL;
    char *result = LVCall((char *)input);
    (*env)->ReleaseStringUTFChars(env, raw, input);
    jbyteArray bytes = (*env)->NewByteArray(env, (jsize)strlen(result));
    if (bytes == NULL) { LVFree(result); return NULL; }
    (*env)->SetByteArrayRegion(env, bytes, 0, (jsize)strlen(result), (const jbyte *)result);
    jclass stringClass = (*env)->FindClass(env, "java/lang/String");
    jmethodID constructor = (*env)->GetMethodID(env, stringClass, "<init>", "([BLjava/lang/String;)V");
    jstring encoding = (*env)->NewStringUTF(env, "UTF-8");
    jstring reply = (jstring)(*env)->NewObject(env, stringClass, constructor, bytes, encoding);
    LVFree(result);
    return reply;
}

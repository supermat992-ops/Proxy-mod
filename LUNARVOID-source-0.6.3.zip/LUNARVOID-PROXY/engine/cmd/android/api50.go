//go:build lv50

package main

/*
#include <stdlib.h>
*/
import "C"
import (
	"encoding/hex"
	"unsafe"
)

//export LVCall50
func LVCall50(request *C.char) *C.char { return C.CString(engine.Call(C.GoString(request))) }

//export LVFree50
func LVFree50(value *C.char) { C.free(unsafe.Pointer(value)) }

//export LVStore50
func LVStore50(path, key *C.char) C.int {
	b, err := hex.DecodeString(C.GoString(key))
	if err != nil {
		return 0
	}
	if engine.ConfigureEncryptedStore(C.GoString(path), b) != nil {
		return 0
	}
	return 1
}

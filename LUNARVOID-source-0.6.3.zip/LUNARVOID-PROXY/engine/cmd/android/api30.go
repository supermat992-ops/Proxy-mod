//go:build !lv40 && !lv50

package main

/*
#include <stdlib.h>
*/
import "C"
import (
	"encoding/hex"
	"unsafe"
)

//export LVCall30
func LVCall30(request *C.char) *C.char { return C.CString(engine.Call(C.GoString(request))) }

//export LVFree30
func LVFree30(value *C.char) { C.free(unsafe.Pointer(value)) }

//export LVStore30
func LVStore30(path, key *C.char) C.int {
	b, err := hex.DecodeString(C.GoString(key))
	if err != nil {
		return 0
	}
	if engine.ConfigureEncryptedStore(C.GoString(path), b) != nil {
		return 0
	}
	return 1
}

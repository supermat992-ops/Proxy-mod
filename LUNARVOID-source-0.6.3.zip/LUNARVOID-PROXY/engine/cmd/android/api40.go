//go:build lv40

package main

/*
#include <stdlib.h>
*/
import "C"
import (
	"encoding/hex"
	"unsafe"
)

//export LVCall40
func LVCall40(request *C.char) *C.char { return C.CString(engine.Call(C.GoString(request))) }

//export LVFree40
func LVFree40(value *C.char) { C.free(unsafe.Pointer(value)) }

//export LVStore40
func LVStore40(path, key *C.char) C.int {
	b, err := hex.DecodeString(C.GoString(key))
	if err != nil {
		return 0
	}
	if engine.ConfigureEncryptedStore(C.GoString(path), b) != nil {
		return 0
	}
	return 1
}

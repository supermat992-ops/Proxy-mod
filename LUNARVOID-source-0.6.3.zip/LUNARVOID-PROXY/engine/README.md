0.6.3 UPDATE — current behavior
Settings supports26.30(default),26.40 and26.50 matching engines. Saved sign-in is encrypted using Android Keystore-wrapped AES-GCM or Windows user DPAPI, restored on app reopen/version switch, refreshed when required, and removed by Sign out. Proxy connections do not restart automatically. Microsoft can require reauthentication. The browser never receives stored tokens. An explicit Minecraft UserBusy form cancellation now retries the home menu up to3 times; intentionally closing it does not reopen it. Real Quest/Windows testing is still required. This is not protocol translation: the destination must support the selected client protocol. Via-style26.30→26.40 translation is not implemented.

# Experimental Bedrock engine

Pinned gophertunnel v1.57.1 for Bedrock1.26.30/protocol1001 and v1.62.0 for
Bedrock1.26.50/protocol2193. Go dependencies are pinned in each mod/sum pair
listed below. Build with `python3 tools/build_engine.py` from the repo
root (Go1.26.1 via mise, NDK27.2.12479018). Android ARM64 library uses JNI;
Windows/Linux use a private line-delimited JSON pipe owned by the launcher.
The Android NDK library anet requires its documented `-checklinkname=0` flag.

Production verifies incoming Minecraft authentication and requires its XUID to
match the authenticated upstream account before spawning. Single player per
proxy. Bind is loopback by default; Android LAN mode uses19132 and accepts only
local/private addresses. The test-only offline mode is not exposed in the API.
Microsoft tokens are never returned by status or persisted to disk.

A local encrypted RakNet/Bedrock fixture tests spawning, emote interception,
form injection, original animation forwarding, response isolation and cleanup.
This does not test real Microsoft/Xbox/PlayFab login or a real Minecraft client.
No version translation, custom overlay, gameplay modules or replay recording.
Destination resource packs are rejected. Test on a real compatible client before
calling this supported. Android process death requires a new sign-in.

Dual engine builds use go.mod/go.sum for26.30(gophertunnelv1.57.1) and
go-26.50.mod/go-26.50.sum for26.50(gophertunnelv1.62.0). No protocol
translation occurs; the host chooses one independent engine. Switching stops
and signs out of the previous engine. Settings defaults to26.30.


0.6.2 connection update: Sign in from Settings, then select a server in Play and press Start Proxy. The primary control now uses the native emote engine; the separate game-mode start/stop panel is removed. Starting stops any legacy forwarding-only relay first. Join the displayed endpoint, select and play an actual emote, or use /.menu. The connection description displays the received emote count. /.help and module aliases (for example /.xray, /.fly, /.automine) are local commands; module aliases report Unavailable because gameplay modules are unfinished. Other server commands pass through. Real-device verification remains pending.

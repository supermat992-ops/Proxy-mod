0.6.3 UPDATE — current behavior
Settings supports26.30(default),26.40 and26.50 matching engines. Saved sign-in is encrypted using Android Keystore-wrapped AES-GCM or Windows user DPAPI, restored on app reopen/version switch, refreshed when required, and removed by Sign out. Proxy connections do not restart automatically. Microsoft can require reauthentication. The browser never receives stored tokens. An explicit Minecraft UserBusy form cancellation now retries the home menu up to3 times; intentionally closing it does not reopen it. Real Quest/Windows testing is still required. This is not protocol translation: the destination must support the selected client protocol. Via-style26.30→26.40 translation is not implemented.

# LUNARVOID PROXY

## 0.6.2 experimental game mode

The Android ARM64 and Windows apps bundle independent native engines for Bedrock
26.30 (protocol1001) and26.50 (protocol2193). Settings > Bedrock version defaults
to26.30. Select the version matching your game and destination; switching signs
out and requires game mode to be stopped. This does not translate versions or
update Minecraft. Sign in from Settings with the same Microsoft account as Minecraft. In Play,
select a matching server, then press **Start Proxy**.
Join the displayed address and play an actual emote to request the LUNARVOID
Minecraft form menu. Use **/.menu** in Minecraft chat as an alternative trigger. The primary
connection control now uses the native menu engine. The website previews the controls and provides
the app downloads; it does not run a UDP engine in the browser.

Encrypted synthetic client/proxy/server tests are available under engine/core.
Real Microsoft login completion, Quest/Minecraft form rendering and Windows
execution remain unverified. Other Bedrock versions/resource-pack destinations
are not supported by this experimental engine. Custom overlay, gameplay modules,
HUD editing and world replay recording are unfinished. Tokens stay in process
memory; Android process death requires sign-in again.

Build the native engine with `python3 tools/build_engine.py`, then build Android,
run `python3 tools/build_desktop.py`, then `python3 tools/package.py`. See
[engine documentation](engine/README.md) for dependencies and boundaries.

## Earlier companion and relay documentation

A responsive Bedrock relay controller with a local Android relay and a Python relay host for web users.

## Run the website and relay locally

Requirements: Python 3.10+; no third-party Python packages.

```sh
python3 V15/build.py
python3 relay/server.py
```

Open `http://127.0.0.1:3000`. Add a destination server, select it, then press **Start Proxy**. The listening address and UDP port appear beside **Proxy started**. Add those details in Minecraft Bedrock on the same computer. Use **Stop Proxy** when finished.

The default host accepts public IPv4 destinations. For your own LAN server, use `python3 relay/server.py --allow-lan`. IPv6 destinations are not implemented. Ports default to 19140–19155. Each relay expires after ten minutes with no forwarded packets or eight hours total. A port supports up to eight client endpoints; this is not a public hosting service with user accounts or billing.

Opening `V15/dist/index.html` directly provides the interface; browser files cannot open UDP sockets. Use the running Python host or the Android APK for real forwarding.

## Android

The Android app bundles the same interface and a native UDP relay in a foreground service. It does not need a hosted backend. Start the relay in LUNARVOID, then switch to Minecraft on that Android device and add `127.0.0.1` with the displayed port. The service has a persistent notification with a Stop action. Android 8.0+ is required. Android may stop background work under battery restrictions; verify on the target device.

To connect another device on the same Wi-Fi, enable **Allow devices on the same Wi-Fi** before pressing Start Proxy. The APK binds IPv4 UDP port 19132, displays the Android device's Wi-Fi address, and forwards Minecraft LAN discovery pings to the selected server. The response is labeled LUNARVOID and advertises the local relay port. Use that Wi-Fi address/port in Minecraft on another device, or check LAN Games where supported. The same Android device can still use 127.0.0.1:19132. If 19132 is occupied, the app reports an error rather than silently choosing an undiscoverable port. Wi-Fi network changes stop the LAN relay so an old address is not advertised.

LAN discovery requires an online Bedrock destination and a router that permits device-to-device UDP broadcasts. Guest-network isolation and platform restrictions can prevent discovery. LAN/console discovery and real Minecraft login still need physical-device testing; the current socket tests use synthetic packets. The app accepts local IPv4 client addresses in LAN mode. No Falix host is needed for either native APK mode.

See [connection architecture](docs/CONNECTION_ARCHITECTURE.md) for how this relates to the supplied proxy design.

Build with JDK 17, Android SDK platform 35, and Python 3:

```sh
cd android
./gradlew :app:assembleDebug :app:lintDebug
```

The build regenerates and packages the web interface. The APK is at `android/app/build/outputs/apk/debug/app-debug.apk`. This is a debug-signed test APK, not a Play Store release. Release signing and store submission are separate work. Never commit private signing keys.

## Features and limits

- Real transparent UDP forwarding, displayed listening address/port, packet counters, explicit start/stop, and active web session recovery within the same browser tab.
- Local nickname preference and unlocked Profile, General, and Performance settings. **Server nickname automation is pending**: a server must provide a compatible plugin and grant the player permission. The relay does not change authenticated Xbox identity or inject `/nick` commands.
- Camera-path points have accessible × removal buttons, saved deletion, and an empty state. Replay recording/playback/export remains unimplemented.
- Phone, tablet, and desktop browser layouts; Android APK. iPhone/iPad can use a relay hosted by an Android device on the same Wi-Fi, or a hosted relay controlled by the website; APKs do not install on iOS.
- Existing skin preview and local resource-pack selection. Applying packs in Minecraft, in-game menus/mods, and Hide Mod remain future work.
- **Bedrock-only target: 26.30 and later updates.** This range has not been verified with real clients. Each update needs a connection test before it can be called supported.
- **No protocol translation:** use a Bedrock client version that the destination server supports. Forwarding arbitrary binary packets does not establish compatibility with every Bedrock version.
- **Normal server authentication still applies.** Minecraft handles its existing login; this app does not bypass Xbox login, ownership, permissions, bans, or server access policies.

`Proxy started` means the UDP socket is listening. `Server packets received` means responses have been forwarded. Neither message proves a successful game login.

## Deploy and test

For the user’s spare Falix server, first read [Falix prerequisites](docs/FALIX.md). See [deployment instructions](docs/DEPLOYMENT.md) for `https://LunarVoidProxy.com` and public UDP hosting. Domain ownership, DNS and a suitable host are still required; the project does not register or deploy a domain automatically.

```sh
python3 -m unittest discover -s tests -v
mkdir -p /tmp/lunarvoid-java-tests
javac -d /tmp/lunarvoid-java-tests android/app/src/main/java/com/lunarvoid/proxy/{UdpRelay,LanDiscovery}.java tests/{UdpRelayTest,LanDiscoveryTest}.java
java -cp /tmp/lunarvoid-java-tests com.lunarvoid.proxy.UdpRelayTest
java -cp /tmp/lunarvoid-java-tests com.lunarvoid.proxy.LanDiscoveryTest
```

These tests use synthetic local UDP fixtures. See [project status](docs/PROJECT_STATUS.md) for verified behavior and remaining device/game checks.

## Blue companion menu (0.4.0 preview)

Open **Client menu** from Home or Play. The sidebar contains Profile, Settings and Edit HUD. The main view lists the requested modules; the LUNARVOID logo returns to that catalog. Search and categories filter the list. Settings saves the player-outline color, ore palette and AutoMine target locally, and Profile shares the app's nickname preference.

All gameplay switches and replay Start/Stop buttons are visibly unavailable. These UI preferences currently change only the companion preview. In-game rendering, world replay recording/editing, cross-device replay sync and the gameplay modules require additional Minecraft integration. Edit HUD is reserved for later work. The transparent relay does not provide these capabilities or bypass a server's identity/permissions. Bedrock26.30/26.50+ is the requested target, not verified compatibility.

The downloadable website can be opened as `index.html` for the interface. Actual browser-controlled connections require running the included Python relay host; a browser alone cannot listen for Bedrock UDP traffic. Use the APK for an Android-hosted local connection. The download is not a public hosted website or an owned domain.

## 0.5.0 changes

Change `version.json` for each release: web version labels and Android metadata are generated from the same value. General and Performance settings now save locally. Turn off **Player → Settings → Show selected skin in3D** to see the PNG texture.

**Client menu → Settings → AutoMine** lists19 ore variants. **Visual → Schematic settings** accepts .mcstructure and .litematic uploads for a local outline preview, rotation and color. The importer is limited to8MB files/16MB expanded data/100,000 cells; the preview draws up to12,000 non-air blocks. It does not place outlines in Minecraft. Emote activation, actual game modules and world replay recording are still unavailable.

Android LAN mode now has no idle/lifetime timer and can continue after the app window is closed. Android may recreate the foreground service using its saved LAN destination; explicit Stop clears that state. Wi-Fi changes trigger reopening, which can interrupt existing game sessions. Force-stop, shutdown and device restrictions can stop it. Physical background/restart behavior still needs testing. Same-device mode retains its existing idle limits.

## Windows PC app

The portable desktop package uses this same website in an Edge/Chrome app window and bundles the official Python runtime plus local relay. On Windows10/11 x64, extract the entire ZIP and double-click **LUNARVOID.exe**. No separate Python install is needed. Add/select a destination and use the displayed localhost port from Minecraft on that PC. **Exit PC app** stops the relay. This desktop package uses same-PC connections; Android LAN discovery is not included.

Browser preferences live in a dedicated `%LOCALAPPDATA%\\LunarVoidProxy\\BrowserProfile`, separate from normal browser/APK storage. A fixed localhost port45321 keeps that storage origin stable. In-game modules retain the website's existing unavailable status. The unsigned Windows executable is cross-compiled; launch and browser process behavior still need a real Windows test.

Build on Linux with Python3 and MinGW-w64 (`gcc-mingw-w64-x86-64` on Ubuntu): `python3 tools/build_desktop.py`. It downloads/checksums the pinned official Python3.14.4 embedded runtime, bundles current HTML/relay and produces the ZIP in release/. Run `python3 -m unittest discover -s tests -p test_desktop.py -v` for desktop HTTP/UDP/lifecycle checks. `python3 desktop/launcher.py --serve` previews only the desktop web host on Linux.


0.6.2 connection update: Sign in from Settings, then select a server in Play and press Start Proxy. The primary control now uses the native emote engine; the separate game-mode start/stop panel is removed. Starting stops any legacy forwarding-only relay first. Join the displayed endpoint, select and play an actual emote, or use /.menu. The connection description displays the received emote count. /.help and module aliases (for example /.xray, /.fly, /.automine) are local commands; module aliases report Unavailable because gameplay modules are unfinished. Other server commands pass through. Real-device verification remains pending.

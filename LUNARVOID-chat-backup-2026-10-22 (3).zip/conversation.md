# LUNARVOID chat backup

Exported2026-10-22 from task f5523444-1c22-4bd7-b4e8-c7bd829f2f57.

Contains all 48 accessible stored user/assistant messages through sequence1568, and24 uploaded attachments. Created before the current delivery reply. Tool logs, internal instructions/reasoning, and app/website binaries are excluded. Stored-conversation scope; no claim to inaccessible history.

## You — 2026-10-21T20:18:04.434Z

Can you see my proxy i am working on https://github.com/dragonboi7667-svg/LUNARVOID-PROXY

## CodeRabbit — 2026-10-21T20:19:23.335Z

Yes, I can access your [LUNARVOID-PROXY repository](https://github.com/dragonboi7667-svg/LUNARVOID-PROXY). It currently contains a README and `LUNARVOID_PROXY_V15 (1).zip`.

I haven’t unpacked or run it yet. What would you like help with?

## You — 2026-10-21T20:20:26.788Z

Read the zip file it has everything about the new proxy mod soon to be apk

## CodeRabbit — 2026-10-21T20:21:05.556Z

I’ve read the V15 ZIP’s source and README. It contains:

- **Interface:** Home, server management, Player, Replay Mod, and Settings.
- **3D skin viewer:** Steve by default, uploaded skins, rotation controls, and saved skin selection.
- **Server list:** locally saved addresses, selection, deletion, and duplicate checks.
- **Microsoft sign-in prototype:** device-code flow; the client ID is currently empty.
- **Build script:** bundles everything into one HTML file for Android/Quest browsers.

**The APK work is still ahead:** this archive contains the web interface, with no Android project or real Bedrock UDP proxy yet. Replay recording/export, resource-pack installation, and Hide Mod are placeholders. Microsoft sign-in also needs the Xbox/Minecraft authentication chain.

The ZIP passed its integrity check. I haven’t run the interface or changed anything.

## You — 2026-10-21T20:25:04.692Z

Don't send code but remove the link account thing in settings and give full access to settings because the link account takes Microsoft payment that i don't got we make it a user name changer instant and here is all pictures of full GUI for the website

## CodeRabbit — 2026-10-21T20:28:14.152Z

Done—removed Microsoft linking, unlocked every Settings tab, and added an instant username changer that saves locally. Your blue GUI is preserved.

Verified saving, reloading, settings controls, and mobile layout. This changes your LUNARVOID name only.

[Open updated website](outputs/LUNARVOID-PROXY.html) · [Download updated ZIP](outputs/LUNARVOID-PROXY-updated.zip)

## You — 2026-10-21T20:39:41.229Z

And don't send code until i say so and the username setting will put your Nickname in any server to that name with a Nickname plugin and in replay add point you can add them but cant remove them fix the just like key keyframes add a x to it Ok there is no menu GUI yet in game or mods but last make that but first lets make it so you can connect to servers ok so when you add a server it will look like picture 1 then you click start proxy on picture 2 and it should give you a new ip and port but that isn't there yet it should be next to the proxy started text and you should be able to join though any bedrock ver if you cant code this back up this chat if you can make it a zip and apk and make the website GUI go on all dives like phone ipad table and for pc make this the URL Https://LunarVoidProxy.com

## CodeRabbit — 2026-10-21T20:53:43.342Z

Implemented and saved locally:

- **× buttons** to remove replay camera points.
- Real UDP forwarding with **IP and port beside “Proxy started.”**
- Responsive phone, tablet, and PC layouts.
- A source ZIP and debug APK—held until you ask for them.

Packet-forwarding and browser tests passed. The APK builds, but Android device testing and actual Minecraft login remain unverified.

**Still pending:** automatic nicknames need the server’s plugin and permissions; Bedrock versions must match what the destination supports; `LunarVoidProxy.com` needs domain ownership and UDP hosting.

Your requirements and remaining work are saved in a project handoff.

## You — 2026-10-21T20:53:52.946Z

Neither this is a bedrock only mod ad and i want it to work with 26.30+ updates i do use falix i have one server that is not being used and nickname is for anyserver

## CodeRabbit — 2026-10-21T20:56:08.321Z

Got it—**Bedrock only, targeting 26.30 and later updates**. Each update will need testing against a compatible destination server.

Your spare Falix server may work, but [Falix lists Python hosting as Premium](https://kb.falixnodes.net/falix/dashboard/setup/supported-software). I need its plan, software, and allocated ports before configuring it. The Android relay can run locally without hosting.

**Nicknames on every server aren’t possible universally.** Other players see names controlled by that server; changing them requires its nickname support and permission.

I’ve saved these requirements. Code and downloads remain held until you ask.

## You — 2026-10-21T21:02:07.229Z

I have the free plan and here is ip and port voidproxy.falix.gg bedrock port 20489 java port 23196

## CodeRabbit — 2026-10-21T21:03:01.919Z

Saved: **Falix Free**, `voidproxy.falix.gg`, Bedrock port **20489**, Java port **23196**.

The Bedrock check received **connection refused**, so I couldn’t confirm it’s running.

Please start the server and send a screenshot of its **Software** page. That will show whether we can adapt this to your Free server. No code or downloads sent.

## You — 2026-10-21T21:03:43.938Z

Paper 26.3 do i need the server stuff cant we just use the apk and website or nah

## CodeRabbit — 2026-10-21T21:04:03.815Z

**Yes—the APK can work without your Falix server.** It runs the relay on your Android device, and Minecraft on that same device joins through the displayed local address and port. Actual Minecraft login still needs testing.

**The website needs a running relay host** to provide connections for PC, iPhone, or iPad. A browser can’t handle Bedrock’s UDP traffic itself.

We can focus on the APK first and leave Falix setup for later. Your Paper server would need Geyser to accept Bedrock players.

## You — 2026-10-21T21:07:36.580Z

Yes i want it like lunar here is how it works

## CodeRabbit — 2026-10-21T21:19:33.899Z

I read your file and added optional **same-Wi-Fi mode** to the APK:

- Start Proxy shows the IP and port.
- Other devices can join through that address, with LAN discovery support.
- This mode doesn’t need Falix.

The APK build, local networking tests and GUI checks passed. **Real Minecraft login and Bedrock 26.30+ gameplay still need device testing.** Packet-changing mods and seamless server switching aren’t implemented yet.

The ZIP and APK are prepared locally. I’ll hold the code and downloads until you ask.

## You — 2026-10-21T21:31:10.554Z

Neither this is a bedrock only mod ad and i want it to work with 26.30+ updates i do use falix i have one server that is not being used and nickname is for anyserver and this is the in game menu this is what is should look like but blue just like the website and the only option should be profile to change settings like nickname everything else remove and keep edit HUD and settings we will get more into that later so nothing else should be there the text that says alpine client add our text from are website and in settings there would be a start replay butten to start and stop replays the flies will then go right to the replay files in the website and app then you can edit it and more and the proxy gos off you wi fi just like lunar so you can see it in your friends tab and join there or there add server and send apk and website === LUNAR PROXY MODULES ===

[COMBAT]
- Reach
- KillAura
- TPAura
- HitBox
- Knockback
- Knockback Delay
- Backtrack
- TriggerBot
- AutoClicker / AFKClicker
- DoubleClick
- AutoTotem
- AutoPotion
- AutoCrystal
- AntiCrystal
- AutoCart
- AutoWeb
- AutoJumpReset
- AutoCrit
- AutoSwitch
- MaceSwap

[MOVEMENT]
- Fly
- Speed
- Jesus
- Spider
- NoFall

[VISUAL]
- Xray
- FreeLook
- FreeCam
- Tracers / BlockTracers
- HoleESP
- ChunkFinder
- ArrayList
- ArmorHUD / InventoryHUD
- TargetHUD
- Schematic
- Player OutLine
[PLAYER]
- AutoEat
- AutoArmor
- FastPlace

[WORLD]
- Nuke
- Scaffold
- FastBreak

[MISC & TOGGLES]
- FakeRain
- AntiVanish
and xray should look like this with the color of the ore and auto mine should mine to players and you can change the color of player out line in settings and every mod that has settings that go to settings

## CodeRabbit — 2026-10-21T21:37:15.257Z

### Downloads — preview build

- [Android APK](outputs/LUNARVOID-0.4.0-preview.apk)
- [Website HTML](outputs/LUNARVOID-website-0.4.0.html)
- [Website ZIP with relay and instructions](outputs/LUNARVOID-website-0.4.0.zip)

Added the blue LUNARVOID menu, **Profile / Settings / Edit HUD**, all 45 module entries, and saved outline/ore-color preferences.

**The menu currently opens inside the companion app, not Minecraft.** Gameplay modules and replay recording remain unavailable. Nicknames cannot override every server’s identity rules.

For LAN joining, enable **Allow devices on the same Wi-Fi**, then start the proxy and use its displayed address or try Friends → LAN Games.

Build, signature and browser checks passed. Actual Minecraft gameplay and **26.30+ compatibility remain unverified**. The website is a download, not a live LunarVoidProxy.com site.

## You — 2026-10-21T22:32:16.685Z

Make it so auto mine has all ores in settings and Make it so when your in game to get the menu you do a Emote and add this mod in Visuals and in settings you can upload a build and it give a out line when on https://youtu.be/pHa_GBLHulw?si=XtkBqKeDcYPKGjxt and make it so if your on lan/ wi fi mode the proxy always stays on and even if the app closed and give the website version a real url i can send to people that isn't long  and make everything Available to use only in game you can preview the mod and change settings but they will say Unavailable on the menu and the apk works fr and remove that your world your way text  and make it show if show selected skin is off it shows the png not the 3d player and make the settings in picture 3 and 4 better and in picture 5 make the version text update every new update and make the apk and website link and a back up of this chat and the apk is Amazing 😁

## CodeRabbit — 2026-10-21T22:42:58.401Z

### Updated downloads — 0.5.0

- [Android APK](outputs/LUNARVOID-0.5.0-preview.apk)
- [Website HTML](outputs/LUNARVOID-website-0.5.0.html)
- [Website ZIP](outputs/LUNARVOID-website-0.5.0.zip)
- [Chat backup with 18 attachments](outputs/LUNARVOID-chat-backup-2026-10-21.zip)

**Added:** 19 AutoMine ore choices, build uploads with outline previews, PNG/3D skin switching, improved saved settings, consistent version labels, and slogan removal.

**LAN:** removed inactivity limits and added foreground-service recovery. Force-stop, shutdown, and Android restrictions can still stop it; background behavior needs device testing.

Build, signature, parser, browser, and local relay checks passed.

**Still unfinished:** emote-triggered menus and actual in-game modules/outlines. They remain unavailable. A short public website URL is blocked until hosting access is connected—the links above are downloads.

## You — 2026-10-21T22:46:09.143Z

Can you make a pc ver like a app for pc but it is the website ver

## CodeRabbit — 2026-10-21T22:53:09.032Z

Yes—here’s the **Windows PC app**, using your website interface:

[Download LUNARVOID for Windows](outputs/LUNARVOID-PC-Windows-x64-0.5.0-preview.zip)

1. Extract the entire ZIP.
2. Open **LUNARVOID.exe**.
3. Add your server and press **Start Proxy**.

Requires **Windows 10/11 64-bit** and Edge or Chrome. Python is bundled.

Seven desktop tests and package checks passed. Actual Windows launch still needs testing on your PC. The website’s existing in-game feature limitations remain.

## You — 2026-10-21T22:54:48.634Z

add this to the website so people can download it but make it the them of the mod and for the discord when you click it it sends you to here https://discord.gg/BTwZVvmdE and dashboard takes you to the website and remove apple download and make a will link to this like .net like in the picture

## CodeRabbit — 2026-10-21T22:58:27.287Z

Added the blue LUNARVOID download page with:

- Windows and Android downloads; no Apple download.
- Your Discord invite.
- Dashboard button opening the existing interface.
- Phone, tablet, and desktop layouts.

[Download the complete website ZIP](outputs/LUNARVOID-download-website-0.5.0.zip)

All 16 relevant tests passed, plus browser layout checks. Apps remain preview builds.

**The `.net` URL isn’t live yet:** it requires a registered domain and hosting access.

## You — 2026-10-21T23:11:16.120Z

The menu still isn't there i did a emote to but nothing add the menu in game then update website fix the url to and add the icon to it then send link not download like a real link

## CodeRabbit — 2026-10-21T23:15:49.694Z

Added and verified the blue website tab icon.

**The in-game menu is still missing.** The APK needs Minecraft integration to detect emotes and display it; the current relay cannot do that.

**There’s no public link yet.** Connect a hosting account to publish the site. A free hosting address can work; a custom `.net` requires registering that domain. The `content://` address in your screenshot is a local file.

## You — 2026-10-21T23:35:02.767Z

now what i mean i wanted it to be it shoud be https://LUNARVOIDPROXY.net/ but if you know a way tell me

## CodeRabbit — 2026-10-21T23:35:26.525Z

Yes—you can use **`https://lunarvoidproxy.net/`**, but you must register that domain first, if it’s available. Domains usually have a yearly fee.

The easiest setup:

1. Register **lunarvoidproxy.net** with a domain registrar.
2. Host the website free on **Cloudflare Pages**.
3. Connect your domain to Pages and enable HTTPS.

Your screenshot shows an **ngrok free address**. That doesn’t give you ownership of `lunarvoidproxy.net`.

If you want **completely free**, you can use a provider address such as `lunarvoidproxy.pages.dev`, if available. You don’t need ngrok for that.

## You — 2026-10-21T23:49:27.310Z

Use this it has everything you need to know about the emote and make the apk and pc download with website

## CodeRabbit — 2026-10-21T23:51:29.139Z

I read the guide. It explains wheel controls, but lacks the Minecraft integration needed to detect emotes. **The in-game menu is still unfinished.**

Prepared the current companion downloads:

- [Android APK](outputs/LUNARVOID-0.5.0-preview.apk)
- [Windows PC app](outputs/LUNARVOID-PC-Windows-x64-0.5.0-preview.zip)
- [Website with both downloads](outputs/LUNARVOID-download-website-0.5.0.zip)

Build, APK signature, and website download checks passed. A public `.net` link still requires domain registration and hosting.

## You — 2026-10-21T23:51:47.953Z

Don't send code but how to get the emote stuff

## CodeRabbit — 2026-10-21T23:52:05.539Z

To make **an emote open your menu**, we need a connection to Minecraft itself.

Two ways:

- **Your own server:** install a compatible server plugin that detects Bedrock emotes and opens a menu. This only works on servers running that plugin.
- **Other people’s servers:** build a full Bedrock proxy that can read game packets, detect the emote, and send a supported menu back. Our current relay doesn’t have that system.

The guide you sent explains drawing an emote wheel, but doesn’t supply either integration.

**The easiest first step is your own test server.** A custom blue overlay on arbitrary servers needs considerably more client/proxy development. You don’t need to buy an emote to solve this.

## You — 2026-10-21T23:55:10.106Z

But the server uses wi fi to connect not server

## CodeRabbit — 2026-10-21T23:55:25.769Z

Yes—you mean Minecraft connects to the **proxy on your Wi-Fi**, through Friends/LAN. You don’t need to own the destination server.

The connection is:

**Minecraft → your Wi-Fi proxy → chosen server**

That setup can support an emote-triggered menu, but the proxy must understand Minecraft’s game packets. The current app only forwards them, so it cannot detect the emote or send a menu back.

We need to develop that Bedrock packet system inside the proxy. **Wi-Fi discovery already provides the connection; it doesn’t provide the menu integration.**

## You — 2026-10-21T23:56:35.965Z

Are you able to make that right into the app

## CodeRabbit — 2026-10-21T23:56:49.874Z

Yes—I can work on building that into the app.

It needs a full Bedrock connection engine to read emote events and open a supported Minecraft menu. The exact blue overlay needs additional client or resource-pack support.

This is a substantial upgrade, and it needs testing with Minecraft on your Android/Quest. **The current APK doesn’t have it yet.**

## You — 2026-10-22T00:00:13.418Z

Can you add it don't send code this is a question

## CodeRabbit — 2026-10-22T00:00:29.298Z

Yes, I can develop it into the app. It requires a substantial Bedrock protocol upgrade and testing on your Android/Quest before I can call it working.

I haven’t started changes—you said this is a question.

## You — 2026-10-22T00:01:36.114Z

OK make it pls and the pc one and website and back up chat

## CodeRabbit — 2026-10-22T00:14:51.689Z

Microsoft’s sign-in service successfully returned a device code, and signing out cleared it. I also checked the new controls on phone and desktop layouts.

The downloads will be marked **0.6.0 experimental**. They target Bedrock 26.30 and use Minecraft forms. Completing sign-in, joining a real server, and rendering the menu on Quest remain unverified.

## You — 2026-10-22T00:17:30.434Z

I want it to be a version changer in settings that goes from 26.30 to 26:50 i use 26:30 make sure to back up chat

## CodeRabbit — 2026-10-22T00:25:22.079Z

The selector now saves your choice, defaults to 26.30, and fits phone and tablet screens. The chat backup includes your latest request and all 23 attachments. The website package needs two ZIP files to fit the download limit; extract both into the same folder. The public `.net` address still needs a domain and hosting.

## You — 2026-10-22T00:31:42.101Z

Don't forget to back up and i use 26.30 but what about players on new versions so make a version changer in settings make the apk pc download and website and any bugs and thing wrong fix it

## CodeRabbit — 2026-10-22T00:32:35.046Z

Added **Settings → Bedrock version**, with **26.30 as default** and **26.50 available**. Future versions need additional updates; this selector doesn’t translate incompatible game/server versions.

### Downloads

- [Android APK](outputs/LUNARVOID-0.6.1-experimental.apk)
- [Windows PC app](outputs/LUNARVOID-PC-Windows-x64-0.6.1-experimental.zip)
- Website: [Part 1](outputs/LUNARVOID-website-0.6.1-part1.zip) + [Part 2](outputs/LUNARVOID-website-0.6.1-part2.zip) — extract both into the same folder.
- [Updated chat backup with attachments](outputs/LUNARVOID-chat-backup-2026-10-22.zip)

Builds, version-switching tests, simulated encrypted connections, and interface checks passed. **These are experimental builds:** real Quest gameplay and Windows execution remain unverified.

The website is packaged; **LUNARVOIDPROXY.net isn’t live yet** because domain and hosting setup are still needed.

## You — 2026-10-22T01:01:42.188Z

OK i think i know why it isn't working the menu even you emote you click a emote it opens and add commands to all mods like /.xray and stuff and keep the signing in thing but put it in settings and remove the start proxy mods and stuff o and i tried both versions it didn't work come on you got this here i will send you lunar proxy use that to see how to do it just look at everything but zip https://github.com/dragonboi7667-svg/LUNARVOID-PROXY

## CodeRabbit — 2026-10-22T01:07:30.671Z

Updated **0.6.2**:

- Microsoft sign-in is now in **Settings**.
- One **Start Proxy** button uses the menu-capable connection.
- Select and play an emote, or type **`/.menu`**.
- Commands such as `/.xray` are recognized, but report **Unavailable** while those mods remain unfinished.

### Downloads

- [Android APK](outputs/LUNARVOID-0.6.2-experimental.apk)
- [Windows PC app](outputs/LUNARVOID-PC-Windows-x64-0.6.2-experimental.zip)
- Website: [Part 1](outputs/LUNARVOID-website-0.6.2-part1.zip) + [Part 2](outputs/LUNARVOID-website-0.6.2-part2.zip) — extract together.
- [Chat backup](outputs/LUNARVOID-chat-backup-2026-10-22.zip)

**Try:** Settings → sign in → Play → select server → Start Proxy → join the displayed address → `/.menu`.

Builds and automated checks passed; **the menu still needs testing on your Quest**. Lunar’s uploaded files contain only resource splits. Please upload its **base.apk or source** so I can inspect the actual implementation.

## You — 2026-10-22T01:31:51.154Z

Back everything up OK now fix all of this and make it so you stay sign in and the menu works come on you got this and make it so the mod has something like Via so you can play old updates on servers no problem because i can but the mod cant and just fix the menu all you have to do is make it work with 26.30 26.40

## CodeRabbit — 2026-10-22T01:35:51.164Z

The saved-session tests passed: encrypted sign-in can be restored, refreshed credentials are saved, and Sign out removes the saved session.

I also found a menu case we weren’t handling: Minecraft can reject a form with **UserBusy** while another screen, such as the emote wheel, is open. The menu now retries that response up to three times. That test passes, but I still need your `/.menu` result to tell whether this explains the failure on your Quest.

## Attachments

- [077eab33-22b8-45f4-834a-5201a0d3ca84-com.oculus.vrshell-20261021-191010.jpg](attachments/077eab33-22b8-45f4-834a-5201a0d3ca84-com.oculus.vrshell-20261021-191010.jpg)
- [21cd094f-0e84-41ee-9d9b-6cde987a6bda-com.oculus.vrshell-20261021-205311.jpg](attachments/21cd094f-0e84-41ee-9d9b-6cde987a6bda-com.oculus.vrshell-20261021-205311.jpg)
- [2389bd89-9377-42a4-b848-24bd671613e4-com.oculus.vrshell-20261021-182936.jpg](attachments/2389bd89-9377-42a4-b848-24bd671613e4-com.oculus.vrshell-20261021-182936.jpg)
- [39e66a5b-61ce-4d39-9e06-6000db4cb341-com.oculus.vrshell-20261021-161852.jpg](attachments/39e66a5b-61ce-4d39-9e06-6000db4cb341-com.oculus.vrshell-20261021-161852.jpg)
- [538c13af-e99c-4bb8-8739-e0ced97733e2-com.oculus.vrshell-20261021-182226.jpg](attachments/538c13af-e99c-4bb8-8739-e0ced97733e2-com.oculus.vrshell-20261021-182226.jpg)
- [5fabac48-4b3a-44a7-8349-b4f50eca0ecf-com.oculus.vrshell-20261021-155728.jpg](attachments/5fabac48-4b3a-44a7-8349-b4f50eca0ecf-com.oculus.vrshell-20261021-155728.jpg)
- [68400720-137f-4ada-b036-452771fff0e0-image-7_-_Copy.png](attachments/68400720-137f-4ada-b036-452771fff0e0-image-7_-_Copy.png)
- [6b4c8bc9-d4c8-4c83-a79b-b77f5f50c9af-com.oculus.vrshell-20261021-190505.jpg](attachments/6b4c8bc9-d4c8-4c83-a79b-b77f5f50c9af-com.oculus.vrshell-20261021-190505.jpg)
- [6d1dd0c4-885a-461d-abd0-86f7914d75dd-com.oculus.vrshell-20261021-182837.jpg](attachments/6d1dd0c4-885a-461d-abd0-86f7914d75dd-com.oculus.vrshell-20261021-182837.jpg)
- [7319c2bf-1a72-48ea-b48d-7212b0aa3fa8-com.oculus.vrshell-20261021-182501.jpg](attachments/7319c2bf-1a72-48ea-b48d-7212b0aa3fa8-com.oculus.vrshell-20261021-182501.jpg)
- [825ff0c1-8a57-4d11-af35-282833e946f0-proxy_connection_system.txt](attachments/825ff0c1-8a57-4d11-af35-282833e946f0-proxy_connection_system.txt)
- [94c05b75-5402-408a-802d-c13954d1c7cb-emote_wheel_implementation_guide.md](attachments/94c05b75-5402-408a-802d-c13954d1c7cb-emote_wheel_implementation_guide.md)
- [9cb858d8-4bd5-4027-9312-e135dd52a9de-com.oculus.vrshell-20261021-161827.jpg](attachments/9cb858d8-4bd5-4027-9312-e135dd52a9de-com.oculus.vrshell-20261021-161827.jpg)
- [a43d0959-a33a-4550-8c62-7b7ba9a7ca19-com.oculus.vrshell-20261021-155841.jpg](attachments/a43d0959-a33a-4550-8c62-7b7ba9a7ca19-com.oculus.vrshell-20261021-155841.jpg)
- [aec68d34-8176-4f43-8fdd-f4a97d0f335b-com.oculus.vrshell-20261021-161844.jpg](attachments/aec68d34-8176-4f43-8fdd-f4a97d0f335b-com.oculus.vrshell-20261021-161844.jpg)
- [b3e003cc-0273-4486-9e7c-d481897faf35-com.oculus.vrshell-20261021-155728.jpg](attachments/b3e003cc-0273-4486-9e7c-d481897faf35-com.oculus.vrshell-20261021-155728.jpg)
- [b8d7d088-cde2-4212-a031-1e72732fb110-com.oculus.vrshell-20261021-161859.jpg](attachments/b8d7d088-cde2-4212-a031-1e72732fb110-com.oculus.vrshell-20261021-161859.jpg)
- [bddfc4c3-fd5b-4274-b4ec-25d5bab1e265-description_4a3215ed-9a1c-4192-b89a-5704bf718584_-_Copy.png](attachments/bddfc4c3-fd5b-4274-b4ec-25d5bab1e265-description_4a3215ed-9a1c-4192-b89a-5704bf718584_-_Copy.png)
- [bea69316-060b-4532-9d84-cb004275b022-alpine_gui_6484ddc907.png](attachments/bea69316-060b-4532-9d84-cb004275b022-alpine_gui_6484ddc907.png)
- [d8d98c38-40a5-4251-a3c3-7ba871e50313-com.oculus.vrshell-20261021-185020.jpg](attachments/d8d98c38-40a5-4251-a3c3-7ba871e50313-com.oculus.vrshell-20261021-185020.jpg)
- [db581c2f-597c-4e53-9c90-3fbc748389ff-653975614-d913d5ad-ac7f-40b3-82d8-042a460ba059-1.png](attachments/db581c2f-597c-4e53-9c90-3fbc748389ff-653975614-d913d5ad-ac7f-40b3-82d8-042a460ba059-1.png)
- [de75d398-28ad-4200-a238-4d9fb0d83c1e-com.oculus.vrshell-20261021-161836.jpg](attachments/de75d398-28ad-4200-a238-4d9fb0d83c1e-com.oculus.vrshell-20261021-161836.jpg)
- [edfbc77c-6b62-42e4-8eb5-61938410bc9d-com.oculus.vrshell-20261021-182925.jpg](attachments/edfbc77c-6b62-42e4-8eb5-61938410bc9d-com.oculus.vrshell-20261021-182925.jpg)
- [ef1e6639-6e32-445e-984e-c5a1251aa747-com.oculus.vrshell-20261021-193348.jpg](attachments/ef1e6639-6e32-445e-984e-c5a1251aa747-com.oculus.vrshell-20261021-193348.jpg)
